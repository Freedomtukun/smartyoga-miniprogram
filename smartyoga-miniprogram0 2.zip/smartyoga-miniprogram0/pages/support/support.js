import { createPayOrder, getPayOrderStatus } from '../../utils/pay';

const generateOutTradeNo = () => `SYSP${Date.now()}${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;

Page({
  data: {
    presetAmounts: ['0.99', '6.99', '9.99'],
    selectedAmount: '0.99',
    customAmount: '',
    loading: false,
    payStatus: null,
    payStatusError: '',
    statusLoading: false
  },

  onShow() {
    this.refreshPayStatus();
  },

  onPullDownRefresh() {
    this.refreshPayStatus().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  handlePresetAmountTap(event) {
    const { value } = event.currentTarget.dataset;
    this.setData({ selectedAmount: value, customAmount: '' });
  },

  handleCustomAmountTap() {
    this.setData({ selectedAmount: 'custom' });
  },

  handleCustomAmountInput(event) {
    const sanitized = event.detail.value.replace(/[^0-9.]/g, '');
    this.setData({ customAmount: sanitized });
  },

  async handleSupportSubmit() {
    if (this.data.loading) {
      return;
    }

    if (this.data.statusLoading) {
      wx.showToast({ title: '正在检查支付配置…', icon: 'none' });
      return;
    }

    const status = this.data.payStatus;
    if (status) {
      if (status.smokeMode) {
        wx.showModal({
          title: '尚未开启支付',
          content: '云函数仍在模拟模式，请先在 pay-order 云函数中关闭 WECHAT_PAY_SMOKE_MODE。',
          showCancel: false
        });
        return;
      }
      if (!status.configReady) {
        wx.showModal({
          title: '支付配置缺失',
          content: '支付参数未配置完整，请在云函数环境变量中补全信息后再试。',
          showCancel: false
        });
        return;
      }
    }

    const { selectedAmount, customAmount } = this.data;
    let amountToPay = selectedAmount;

    if (selectedAmount === 'custom') {
      amountToPay = (customAmount || '').trim();
      if (!amountToPay) {
        wx.showToast({ title: '请输入自定义金额', icon: 'none' });
        return;
      }
    }

    const numericAmount = Number(amountToPay);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      wx.showToast({ title: '金额需大于0', icon: 'none' });
      return;
    }

    const totalFee = Math.round(numericAmount * 100);

    if (totalFee < 1) {
      wx.showToast({ title: '金额需不少于 ¥0.01', icon: 'none' });
      return;
    }

    this.setData({ loading: true });

    try {
      const payload = {
        description: `支持Smartyoga ¥${numericAmount.toFixed(2)}`,
        outTradeNo: generateOutTradeNo(),
        totalFee
      };

      const result = await createPayOrder(payload);
      const payment = result && result.payment;

      if (!payment || typeof payment !== 'object') {
        throw new Error('支付参数缺失');
      }

      await this.invokePayment(payment);
    } catch (err) {
      this.handlePaymentError(err);
    } finally {
      this.setData({ loading: false });
    }
  },

  invokePayment(payment) {
    return new Promise((resolve) => {
      let handled = false;

      wx.requestPayment({
        ...payment,
        success: () => {
          handled = true;
          wx.showToast({ title: '感谢支持' });
        },
        fail: (err) => {
          handled = true;
          const isCancel = typeof err?.errMsg === 'string' && err.errMsg.includes('cancel');
          wx.showToast({
            icon: 'none',
            title: isCancel ? '已取消支付' : '支付失败'
          });
        },
        complete: () => {
          if (!handled) {
            wx.showToast({ icon: 'none', title: '支付已中断' });
          }
          resolve();
        }
      });
    });
  },

  handlePaymentError(err) {
    const error = err || {};
    const message = error.message || '下单失败';
    const code = error.code;

    console.error('[support] payment error', error);

    if (code === 'SMOKE_MODE') {
      wx.showModal({
        title: '支付未开启',
        content: 'pay-order 云函数仍在模拟模式，请关闭 SMOKE_MODE 后再次测试。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    if (code === 'NO_OPENID') {
      wx.showModal({
        title: '缺少 OPENID',
        content: '请确认通过 wx.cloud.callFunction 调用云函数，或联系后端支持 openid 透传。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    if (code === 'FUNCTION_NOT_FOUND') {
      wx.showModal({
        title: '云函数未部署',
        content: '未找到 pay-order 云函数，请确认已上传并与当前环境匹配。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    wx.showToast({ icon: 'none', title: message });
    this.refreshPayStatus();
  },

  async refreshPayStatus() {
    this.setData({ statusLoading: true, payStatusError: '' });
    try {
      const status = await getPayOrderStatus();
      this.setData({ payStatus: status, statusLoading: false });
    } catch (err) {
      const message = (err && err.message) || '支付状态获取失败';
      this.setData({ payStatus: null, payStatusError: message, statusLoading: false });
    }
  }
});
