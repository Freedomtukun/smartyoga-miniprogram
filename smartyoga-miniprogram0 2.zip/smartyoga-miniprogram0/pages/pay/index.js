import { createPayOrder, getPayOrderStatus } from '../../utils/pay';

Page({
  data: {
    description: '测试订单',
    amount: '1',
    loading: false,
    payStatus: null,
    payStatusError: '',
    statusLoading: false
  },

  onShow() {
    this.refreshPayStatus();
  },

  onPullDownRefresh() {
    this.refreshPayStatus().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  onDescriptionChange(e) {
    this.setData({ description: e.detail.value });
  },

  onAmountChange(e) {
    this.setData({ amount: e.detail.value });
  },

  async handlePay() {
    if (this.data.loading) {
      return;
    }

    if (this.data.statusLoading) {
      wx.showToast({ icon: 'none', title: '正在检查支付配置…' });
      return;
    }

    const status = this.data.payStatus;
    if (status) {
      if (status.smokeMode) {
        wx.showModal({
          title: '尚未开启支付',
          content: '云函数仍在模拟模式，请先在 pay-order 云函数中关闭 WECHAT_PAY_SMOKE_MODE。',
          showCancel: false
        });
        return;
      }
      if (!status.configReady) {
        wx.showModal({
          title: '支付配置缺失',
          content: '支付参数未配置完整，请在云函数环境变量中补全信息后再试。',
          showCancel: false
        });
        return;
      }
    }

    const description = (this.data.description || '').trim() || '测试订单';
    const amountValue = Number((this.data.amount || '').trim());

    if (!Number.isFinite(amountValue) || amountValue <= 0) {
      wx.showToast({ icon: 'none', title: '请输入正确金额' });
      return;
    }

    const totalFee = Math.round(amountValue);

    this.setData({ loading: true, description, amount: String(totalFee) });

    try {
      const orderPayload = {
        description,
        outTradeNo: `SY${Date.now()}`,
        totalFee
      };

      const result = await createPayOrder(orderPayload);
      const payment = result && result.payment;

      if (!payment || typeof payment !== 'object') {
        throw new Error('支付参数缺失');
      }

      await this.invokePayment(payment);
    } catch (err) {
      this.handlePayError(err);
    } finally {
      this.setData({ loading: false });
    }
  },

  invokePayment(payment) {
    return new Promise((resolve) => {
      let handled = false;

      wx.requestPayment({
        ...payment,
        success: () => {
          handled = true;
          wx.showToast({ title: '支付成功' });
        },
        fail: (err) => {
          handled = true;
          const isCancel = typeof err?.errMsg === 'string' && err.errMsg.includes('cancel');
          wx.showToast({
            icon: 'none',
            title: isCancel ? '已取消支付' : '支付失败'
          });
        },
        complete: () => {
          if (!handled) {
            wx.showToast({ icon: 'none', title: '支付已中断' });
          }
          resolve();
        }
      });
    });
  },

  handlePayError(err) {
    const error = err || {};
    const message = error.message || '下单失败';
    const code = error.code;

    console.error('[pay] handlePay error', error);

    if (code === 'SMOKE_MODE') {
      wx.showModal({
        title: '支付未开启',
        content: 'pay-order 云函数仍在模拟模式，请关闭 SMOKE_MODE 后再次测试。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    if (code === 'NO_OPENID') {
      wx.showModal({
        title: '缺少 OPENID',
        content: '请确认使用 wx.cloud.callFunction 调用云函数，或在请求中显式传入 openid。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    if (code === 'FUNCTION_NOT_FOUND') {
      wx.showModal({
        title: '云函数未部署',
        content: '未找到 pay-order 云函数，请确认已上传并与当前环境匹配。',
        showCancel: false
      });
      this.refreshPayStatus();
      return;
    }

    wx.showToast({ icon: 'none', title: message });
    this.refreshPayStatus();
  },

  async refreshPayStatus() {
    this.setData({ statusLoading: true, payStatusError: '' });
    try {
      const status = await getPayOrderStatus();
      this.setData({ payStatus: status, statusLoading: false });
    } catch (err) {
      const message = (err && err.message) || '支付状态获取失败';
      this.setData({ payStatus: null, payStatusError: message, statusLoading: false });
    }
  }
});
