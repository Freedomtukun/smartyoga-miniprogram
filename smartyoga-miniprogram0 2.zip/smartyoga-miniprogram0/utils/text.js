const ELLIPSIS = '…';

function getUtf8Bytes(charCode) {
  if (charCode <= 0x7f) return 1;
  if (charCode <= 0x7ff) return 2;
  if (charCode >= 0xd800 && charCode <= 0xdbff) return 4; // surrogate pair
  return 3;
}

export function computeByteLength(text) {
  if (!text) return 0;
  const str = String(text);
  let bytes = 0;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    bytes += getUtf8Bytes(code);
    if (code >= 0xd800 && code <= 0xdbff) i++; // skip low surrogate
  }
  return bytes;
}

export function truncateByBytes(text, maxBytes = 1024, suffix = ELLIPSIS) {
  if (!text) return '';
  const str = String(text);
  if (computeByteLength(str) <= maxBytes) {
    return str;
  }

  const suffixBytes = computeByteLength(suffix);
  const targetBytes = Math.max(0, maxBytes - suffixBytes);

  let bytes = 0;
  let index = 0;
  while (index < str.length) {
    const code = str.charCodeAt(index);
    const charBytes = getUtf8Bytes(code);
    if (bytes + charBytes > targetBytes) {
      break;
    }
    bytes += charBytes;
    index += (code >= 0xd800 && code <= 0xdbff) ? 2 : 1;
  }

  return str.slice(0, index) + suffix;
}

export function truncateByLength(text, maxLength = 512, suffix = ELLIPSIS) {
  if (!text) return '';
  const str = String(text);
  if (str.length <= maxLength) return str;
  return str.slice(0, Math.max(0, maxLength - suffix.length)) + suffix;
}

export default {
  truncateByBytes,
  truncateByLength,
  computeByteLength
};
