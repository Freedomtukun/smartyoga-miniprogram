const PAY_FUNCTION_NAME = 'pay-order';

function createError(message, code, detail) {
  const error = new Error(message || '支付异常');
  if (code) error.code = code;
  if (detail !== undefined) error.detail = detail;
  return error;
}

async function callPayFunction(payload) {
  if (!wx.cloud || typeof wx.cloud.callFunction !== 'function') {
    throw createError('当前基础库暂不支持云函数，请升级微信版本后再试', 'NO_CLOUD_SUPPORT');
  }

  try {
    const res = await wx.cloud.callFunction({
      name: PAY_FUNCTION_NAME,
      data: payload
    });
    return res && res.result ? res.result : res;
  } catch (err) {
    const errMsg = (err && err.errMsg) || (err && err.message) || '';
    if (typeof errMsg === 'string' && errMsg.includes('function not found')) {
      throw createError('未找到 pay-order 云函数，请确认已部署并与小程序环境一致', 'FUNCTION_NOT_FOUND', err);
    }
    if (typeof errMsg === 'string' && errMsg.includes('cloud callFunction:fail')) {
      throw createError('云函数调用失败，请检查网络或云环境配置', err && err.errCode ? err.errCode : 'CALL_FUNCTION_FAIL', err);
    }
    throw createError('云函数调用失败，请稍后重试', (err && err.errCode) || 'NETWORK_ERROR', err);
  }
}

export async function createPayOrder({
  description,
  outTradeNo,
  totalFee,
  currency = 'CNY',
  attach = '',
  expireInSeconds = 0,
  sceneInfo = null
} = {}) {
  if (!description) {
    throw createError('缺少订单描述', 'INVALID_DESCRIPTION');
  }
  if (!outTradeNo) {
    throw createError('缺少订单号', 'INVALID_OUT_TRADE_NO');
  }
  if (!Number.isInteger(totalFee) || totalFee <= 0) {
    throw createError('支付金额异常', 'INVALID_TOTAL_FEE');
  }

  const payload = {
    description,
    outTradeNo,
    totalFee,
    currency,
    attach,
    expireInSeconds,
    sceneInfo
  };

  const result = await callPayFunction(payload);

  if (result && result.code === 0 && result.data && result.data.payment) {
    return result.data;
  }

  if (result && result.code === 'SMOKE_MODE') {
    throw createError('云函数处于 SMOKE 测试模式，尚未开启真实微信支付', 'SMOKE_MODE', result);
  }

  if (result && result.code === 'NO_OPENID') {
    throw createError('云函数未获取到用户 OPENID，请从小程序端通过 wx.cloud.callFunction 调用或显式传入 openid', 'NO_OPENID', result);
  }

  const message = (result && (result.message || result.msg)) || '下单失败，请稍后再试';
  const errorCode = (result && result.code) || 'CALL_FAILED';
  throw createError(message, errorCode, result);
}

export async function getPayOrderStatus() {
  const result = await callPayFunction({ action: 'status' });

  if (result && result.code === 0 && result.data) {
    return result.data;
  }

  const message = (result && (result.message || result.msg)) || '无法获取支付状态';
  const errorCode = (result && result.code) || 'STATUS_FAIL';
  throw createError(message, errorCode, result);
}

export default {
  createPayOrder,
  getPayOrderStatus
};
