import { FN } from './yoga-api';

function extractResult(res) {
  const d = res?.result || {};
  return {
    text: d.text || d.reply || '',
    audioUrl: d.audioUrl || d.voiceUrl || ''
  };
}

async function callGuide(data) {
  const res = await wx.cloud.callFunction({ name: FN.GUIDE_TTS, data });
  return extractResult(res);
}

export async function fetchGuideByPose({ poseId, step }) {
  if (!poseId && step == null) return { text: '', audioUrl: '' };
  return callGuide({ action: 'guide', poseId, step });
}

export async function fetchGuideByPrompt(prompt) {
  const content = (prompt || '').trim();
  if (!content) return { text: '', audioUrl: '' };
  return callGuide({ action: 'prompt', prompt: content });
}

export async function fetchGuideByVoice(audioBase64, format = 'mp3') {
  if (!audioBase64) return { text: '', audioUrl: '' };
  return callGuide({ action: 'voice', audioBase64, format });
}
