import { FN } from './yoga-api';
export async function fetchMeditation({ theme='breath', duration=300 }) {
  const res = await wx.cloud.callFunction({ name: FN.MEDITATION_TTS, data: { action:'meditation', theme, duration } });
  const d = res?.result || {};
  return { text: d.text || '', audioUrl: d.audioUrl || '' };
}
