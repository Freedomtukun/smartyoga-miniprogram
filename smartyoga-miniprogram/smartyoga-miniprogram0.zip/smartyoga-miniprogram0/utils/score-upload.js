import { ENDPOINTS, normalizeFeedbackPayload, FN } from './yoga-api';

async function ttsFallback(text) {
  if (!text) return '';
  const res = await wx.cloud.callFunction({
    name: FN.GUIDE_TTS,
    data: { action: 'tts_feedback', text }
  });
  return res?.result?.audioUrl || '';
}

export async function uploadAndScore(filePath, extra = {}) {
  const res = await wx.uploadFile({
    url: ENDPOINTS.DETECT_POSE_FILE,
    name: 'file',
    filePath,
    formData: extra,
    timeout: 20000
  });
  const payload = normalizeFeedbackPayload(res.data);
  if (!payload.ok) throw new Error('评分失败');
  if (!payload.audioUrl) {
    try {
      payload.audioUrl = await ttsFallback(payload.advice || payload.summary || '请根据建议微调体式');
    } catch {}
  }
  return payload; // { ok, score, advice, summary?, skeletonUrl?, audioUrl? }
}
