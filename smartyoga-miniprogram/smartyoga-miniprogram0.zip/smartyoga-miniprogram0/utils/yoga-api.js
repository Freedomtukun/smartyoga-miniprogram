import { RUNTIME } from './config/env';

export const ENDPOINTS = {
  DETECT_POSE:      `${RUNTIME.API_BASE_URL}/api/feedback`,
  DETECT_POSE_FILE: `${RUNTIME.API_BASE_URL}/api/feedback/file`,   // 主通道：multipart
  GUIDE_TTS:        `${RUNTIME.API_BASE_URL}/api/tts/guide`,
  MEDI_TTS:         `${RUNTIME.API_BASE_URL}/api/tts/meditation`,
  MAP_RECOMMEND:    `${RUNTIME.API_BASE_URL}/api/map/recommend`,
  HEALTH:           `${RUNTIME.API_BASE_URL}/api/feedback/health`
};

export const FN = RUNTIME.CLOUD_FUNCTIONS;

// 归一化“最小可见输出”
export function normalizeFeedbackPayload(raw) {
  try {
    const r = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
    const score = Number(r.score ?? r.data?.score ?? 0);
    const ok    = Boolean(r.ok || r.code === 0 || r.success === true);
    return {
      ok,
      score,
      advice:      r.advice       || r.data?.advice       || '',
      summary:     r.summary      || r.data?.summary      || '',
      skeletonUrl: r.skeletonUrl  || r.data?.skeletonUrl  || '',
      audioUrl:    r.audioUrl     || r.data?.audioUrl     || ''
    };
  } catch {
    return { ok:false, score:0, advice:'', summary:'', skeletonUrl:'', audioUrl:'' };
  }
}
