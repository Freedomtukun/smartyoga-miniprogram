import { FN } from './yoga-api';
export async function fetchNearby({ lat, lng, keyword='瑜伽|咖啡', radius=3000 }) {
  const res = await wx.cloud.callFunction({ name: FN.MAP_RECOMMEND, data: { action:'nearby', lat, lng, keyword, radius } });
  const d = res?.result || {};
  return Array.isArray(d.items) ? d.items : [];
}
