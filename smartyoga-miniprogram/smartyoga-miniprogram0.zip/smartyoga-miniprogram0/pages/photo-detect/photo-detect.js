import { uploadAndScore } from '../../utils/score-upload';

Page({
  data: {
    uploading: false,
    error: '',
    preview: '',
    tips: [
      '确保相机光线充足，身体轮廓清晰可见',
      '尽量让全身出现在画面中，保持单人拍摄',
      '建议选择正面或侧面角度，便于算法识别'
    ]
  },

  async chooseAndScore() {
    if (this.data.uploading) return;
    try {
      const pick = await wx.chooseImage({ count: 1, sizeType: ['compressed'] });
      const filePath = pick.tempFilePaths?.[0];
      if (!filePath) throw new Error('未选择图片');
      this.setData({ uploading: true, error: '', preview: filePath });
      const r = await uploadAndScore(filePath);
      wx.navigateTo({
        url:
          `/pages/result/result?` +
          `score=${r.score}` +
          `&advice=${encodeURIComponent(r.advice || '')}` +
          `&summary=${encodeURIComponent(r.summary || '')}` +
          `&img=${encodeURIComponent(filePath)}` +
          `&skeleton=${encodeURIComponent(r.skeletonUrl || '')}` +
          `&audio=${encodeURIComponent(r.audioUrl || '')}`
      });
    } catch (e) {
      const msg = e?.message || '上传或评分失败';
      this.setData({ error: msg });
      wx.showToast({ title: msg, icon: 'none' });
    } finally {
      this.setData({ uploading: false });
    }
  }
});
