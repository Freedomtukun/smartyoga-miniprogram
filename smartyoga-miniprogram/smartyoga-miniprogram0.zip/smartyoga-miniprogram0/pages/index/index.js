Page({
  handleGuidePress() {
    wx.navigateTo({ url: '/pages/sequence/sequence' });
  },

  handleMeditationPress() {
    wx.navigateTo({ url: '/pages/meditation/meditation' });
  },

  handleDetectPress() {
    wx.navigateTo({ url: '/pages/photo-detect/photo-detect' });
  },

  handleNearbyPress() {
    wx.navigateTo({ url: '/pages/nearby/nearby' });
  }
});
