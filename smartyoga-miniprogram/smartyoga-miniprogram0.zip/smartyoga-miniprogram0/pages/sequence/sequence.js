import { fetchGuideByPrompt, fetchGuideByVoice } from '../../utils/guide.js';

let audioCtx;
const recorder = wx.getRecorderManager();
const fs = wx.getFileSystemManager ? wx.getFileSystemManager() : null;

function readFileAsBase64(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs) {
      reject(new Error('文件系统不可用'));
      return;
    }
    fs.readFile({
      filePath,
      encoding: 'base64',
      success: ({ data }) => resolve(data),
      fail: reject
    });
  });
}

Page({
  data: {
    inputText: '',
    guideText: '',
    audio: '',
    loading: false,
    playing: false,
    recording: false,
    recordHint: '按住说话'
  },

  onLoad() {
    this.initRecorder();
  },

  onUnload() {
    this.stopAudio();
    if (audioCtx && audioCtx.destroy) {
      audioCtx.destroy();
    }
    audioCtx = null;
    try {
      recorder.stop();
    } catch (_) {}
  },

  onInput(e) {
    this.setData({ inputText: e.detail.value });
  },

  async sendText() {
    const prompt = (this.data.inputText || '').trim();
    if (!prompt) {
      wx.showToast({ title: '请先输入内容', icon: 'none' });
      return;
    }
    await this.requestGuide(() => fetchGuideByPrompt(prompt));
  },

  initRecorder() {
    this.recordCanceled = false;
    recorder.onStart(() => {
      this.setData({ recording: true, recordHint: '松开即可发送' });
    });
    recorder.onStop(async (res) => {
      this.setData({ recording: false, recordHint: '按住说话' });
      if (this.recordCanceled) {
        this.recordCanceled = false;
        return;
      }
      if (res?.tempFilePath) {
        await this.handleVoice(res.tempFilePath);
      }
    });
    recorder.onError((err) => {
      console.error('[sequence] record error', err);
      this.setData({ recording: false, recordHint: '按住说话' });
      wx.showToast({ title: '录音失败，请重试', icon: 'none' });
    });
  },

  ensureRecordAuth() {
    return new Promise((resolve) => {
      wx.getSetting({
        success: ({ authSetting }) => {
          if (authSetting['scope.record']) {
            resolve(true);
          } else {
            wx.authorize({
              scope: 'scope.record',
              success: () => resolve(true),
              fail: () => {
                wx.showToast({ title: '请开启录音权限', icon: 'none' });
                resolve(false);
              }
            });
          }
        },
        fail: () => resolve(false)
      });
    });
  },

  async startRecord() {
    if (this.data.loading) return;
    const ok = await this.ensureRecordAuth();
    if (!ok) return;
    this.recordCanceled = false;
    recorder.start({
      duration: 60000,
      sampleRate: 44100,
      numberOfChannels: 1,
      encodeBitRate: 96000,
      format: 'mp3'
    });
  },

  stopRecord() {
    if (!this.data.recording) return;
    recorder.stop();
  },

  cancelRecord() {
    if (!this.data.recording) return;
    this.recordCanceled = true;
    recorder.stop();
    wx.showToast({ title: '已取消', icon: 'none' });
  },

  async handleVoice(filePath) {
    await this.requestGuide(async () => {
      const base64 = await readFileAsBase64(filePath);
      return fetchGuideByVoice(base64);
    });
  },

  async requestGuide(fetcher) {
    if (this.data.loading) return;
    this.stopAudio();
    this.setData({ loading: true });
    try {
      const result = await fetcher();
      this.applyGuideResult(result);
    } catch (err) {
      console.error('[sequence] guide request failed', err);
      wx.showToast({ title: '获取引导失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  applyGuideResult(result) {
    const text = result?.text || '';
    const audio = result?.audioUrl || result?.audio || '';
    if (!text) {
      wx.showToast({ title: '暂无有效建议', icon: 'none' });
      return;
    }
    this.setData({ guideText: text, audio, playing: false });
    if (audio) {
      this.ensureAudioCtx();
      audioCtx.src = audio;
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[sequence] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  togglePlay() {
    if (!this.data.audio) {
      wx.showToast({ title: '暂无语音', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audio) {
        audioCtx.src = this.data.audio;
      }
      audioCtx.play();
    }
  },

  stopAudio(pauseOnly = false) {
    if (!audioCtx) return;
    if (pauseOnly) {
      audioCtx.pause();
    } else {
      audioCtx.stop();
    }
    this.setData({ playing: false });
  }
});
