// pages/meditation/index.js
// 冥想页面 - 增强版（含语音合成、地图推荐）

import { MEDI_TTS_URL, MEDI_GEN_URL } from '../../utils/yoga-api';
import { playTTS, stopTTS, pauseTTS, resumeTTS, onTTSEnd } from '../../utils/tts-player';
import { fetchNearbyPOIs, navigateToPOI } from '../../utils/map-recommend';

const meditationSessions = require('../../assets/meditation_sessions.js');

Page({
  data: {
    // 原有音频播放状态
    isPlaying: false,
    meditationList: [],
    currentIndex: 0,
    currentMeditation: {},
    
    // 新增：AI生成内容
    generatedText: '',
    isGenerating: false,
    
    // 新增：TTS状态
    audioUrl: '',
    isTTSPlaying: false,
    
    // 新增：地图推荐
    nearbyPOIs: [],
    isLoadingPOI: false,
    showPOISection: false
  },

  /**
   * 页面加载时初始化
   */
  onLoad: function () {
    this.initMeditationData();
    this.initAudioContext();
    
    // 监听TTS播放结束
    onTTSEnd(() => {
      this.setData({ isTTSPlaying: false });
    });
  },
  
  /**
   * 页面显示时加载附近推荐
   */
  onShow: function() {
    this.loadNearby();
  },

  /**
   * 初始化冥想数据
   */
  initMeditationData: function () {
    const meditationList = meditationSessions || [];
    const currentMeditation = meditationList[0] || {};
    
    this.setData({
      meditationList: meditationList,
      currentMeditation: currentMeditation,
      currentIndex: 0
    });
    
    console.log('冥想数据加载完成:', meditationList);
  },

  /**
   * 初始化音频上下文（原有音频）
   */
  initAudioContext: function () {
    if (this.innerAudioContext) {
      this.innerAudioContext.destroy();
    }

    this.innerAudioContext = wx.createInnerAudioContext({
      useWebAudioImplement: false
    });

    if (this.data.currentMeditation.audioUrl) {
      this.innerAudioContext.src = this.data.currentMeditation.audioUrl;
    }

    this.bindAudioEvents();
  },

  /**
   * 绑定音频事件监听
   */
  bindAudioEvents: function () {
    this.innerAudioContext.onPlay(() => {
      console.log('音频开始播放');
      this.setData({ isPlaying: true });
    });

    this.innerAudioContext.onPause(() => {
      console.log('音频暂停');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onStop(() => {
      console.log('音频停止');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onEnded(() => {
      console.log('音频播放结束');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onError((res) => {
      console.error('音频播放错误:', res.errMsg, '错误代码:', res.errCode);
      wx.showToast({
        title: '音频播放失败',
        icon: 'none',
        duration: 2000
      });
      this.setData({ isPlaying: false });
    });
  },

  /**
   * === 新增：生成冥想文本 ===
   */
  async generateMeditationText() {
    if (this.data.isGenerating) return;
    
    this.setData({ isGenerating: true });
    wx.showLoading({ title: '生成中...' });
    
    const themes = ['呼吸', '正念', '身体扫描', '慈悲', '放松'];
    const theme = themes[Math.floor(Math.random() * themes.length)];
    
    wx.request({
      url: MEDI_GEN_URL,
      method: 'POST',
      data: {
        theme: theme,
        duration: this.data.currentMeditation.duration || 60,
        style: 'gentle'
      },
      success: ({ data }) => {
        wx.hideLoading();
        if (data?.data?.text || data?.text) {
          const text = data.data?.text || data.text;
          this.setData({ 
            generatedText: text,
            isGenerating: false 
          });
          
          // 自动播放生成的文本
          this.playGeneratedVoice();
        } else {
          wx.showToast({ title: '生成失败', icon: 'none' });
          this.setData({ isGenerating: false });
        }
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '网络错误', icon: 'none' });
        this.setData({ isGenerating: false });
      }
    });
  },

  /**
   * === 新增：播放生成的语音 ===
   */
  async playGeneratedVoice() {
    const text = this.data.generatedText || this.data.currentMeditation.desc;
    
    if (!text) {
      wx.showToast({ title: '请先生成冥想文本', icon: 'none' });
      return;
    }
    
    // 如果正在播放原音频，先停止
    if (this.data.isPlaying) {
      this.innerAudioContext.pause();
    }
    
    // 如果正在播放TTS，则暂停/继续
    if (this.data.isTTSPlaying) {
      pauseTTS();
      this.setData({ isTTSPlaying: false });
      return;
    }
    
    wx.showLoading({ title: '合成语音...' });
    
    wx.request({
      url: MEDI_TTS_URL,
      method: 'POST',
      data: {
        text: text,
        voice: 'gentle_female', // 轻柔女声
        speed: 0.9 // 稍慢语速
      },
      success: ({ data }) => {
        wx.hideLoading();
        const url = data?.data?.url || data?.url;
        if (url) {
          this.setData({ 
            audioUrl: url,
            isTTSPlaying: true 
          });
          
          playTTS({ 
            url: url, 
            title: this.data.currentMeditation.name || '冥想语音',
            coverImgUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
          });
        } else {
          wx.showToast({ title: '语音合成失败', icon: 'none' });
        }
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '网络错误', icon: 'none' });
      }
    });
  },

  /**
   * === 新增：加载附近冥想/瑜伽空间 ===
   */
  loadNearby() {
    this.setData({ isLoadingPOI: true });
    
    wx.getLocation({
      type: 'gcj02',
      success: async ({ latitude, longitude }) => {
        try {
          const pois = await fetchNearbyPOIs({
            lat: latitude,
            lng: longitude,
            bizType: 'meditation',
            userIntent: '冥想静修',
            radius: 5000,
            enableReasons: true
          });
          
          this.setData({ 
            nearbyPOIs: pois.slice(0, 5),
            isLoadingPOI: false,
            showPOISection: false // 默认收起
          });
        } catch (err) {
          console.error('[POI] 获取推荐失败:', err);
          this.setData({ isLoadingPOI: false });
        }
      },
      fail: () => {
        this.setData({ isLoadingPOI: false });
        console.log('[POI] 用户拒绝位置授权');
      }
    });
  },
  
  // 打开POI详情
  openPOI(e) {
    const poi = e.currentTarget.dataset.poi;
    if (poi) {
      navigateToPOI(poi);
    }
  },
  
  // 切换POI区域显示
  togglePOISection() {
    this.setData({ 
      showPOISection: !this.data.showPOISection 
    });
  },

  /**
   * 切换冥想类型
   */
  switchMeditation: function (e) {
    const index = e.currentTarget.dataset.index;
    const newMeditation = this.data.meditationList[index];
    
    if (!newMeditation || index === this.data.currentIndex) {
      return;
    }

    console.log('切换冥想类型:', newMeditation.name);

    // 停止所有播放
    if (this.innerAudioContext && this.data.isPlaying) {
      this.innerAudioContext.stop();
    }
    if (this.data.isTTSPlaying) {
      stopTTS();
    }

    // 更新数据
    this.setData({
      currentIndex: index,
      currentMeditation: newMeditation,
      isPlaying: false,
      isTTSPlaying: false,
      generatedText: '' // 清空生成的文本
    });

    // 切换音频源
    if (this.innerAudioContext) {
      this.innerAudioContext.src = newMeditation.audioUrl;
    }

    wx.showToast({
      title: `已切换到${newMeditation.name}`,
      icon: 'none',
      duration: 1500
    });
  },

  /**
   * 播放/暂停原始冥想音频
   */
  toggleMeditation: function () {
    if (!this.innerAudioContext) {
      console.error('音频上下文未初始化');
      return;
    }

    if (!this.data.currentMeditation.audioUrl) {
      wx.showToast({
        title: '音频链接无效',
        icon: 'none'
      });
      return;
    }
    
    // 如果正在播放TTS，先停止
    if (this.data.isTTSPlaying) {
      stopTTS();
      this.setData({ isTTSPlaying: false });
    }

    try {
      if (this.data.isPlaying) {
        this.innerAudioContext.pause();
        console.log('暂停冥想音频');
      } else {
        this.innerAudioContext.play();
        console.log('开始播放冥想音频');
      }
    } catch (error) {
      console.error('音频播放控制出错:', error);
      wx.showToast({
        title: '音频控制失败',
        icon: 'none'
      });
    }
  },

  /**
   * 返回上一页
   */
  handleBack: function () {
    // 停止所有音频
    if (this.innerAudioContext) {
      this.innerAudioContext.stop();
    }
    stopTTS();
    wx.navigateBack();
  },

  /**
   * 格式化时长显示
   */
  formatDuration: function (duration) {
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}分${seconds}秒`;
  },

  /**
   * 页面卸载时清理资源
   */
  onUnload: function () {
    if (this.innerAudioContext) {
      this.innerAudioContext.destroy();
      console.log('音频上下文已销毁');
    }
    stopTTS();
  },

  /**
   * 页面隐藏时暂停音频
   */
  onHide: function () {
    if (this.innerAudioContext && this.data.isPlaying) {
      this.innerAudioContext.pause();
    }
    if (this.data.isTTSPlaying) {
      pauseTTS();
    }
  },
  
  /**
   * 分享配置
   */
  onShareAppMessage() {
    return {
      title: '1分钟冥想放松 | 附近静修空间推荐',
      path: '/pages/meditation/index',
      imageUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
    };
  }
});