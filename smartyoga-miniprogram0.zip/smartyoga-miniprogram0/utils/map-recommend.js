// utils/map-recommend.js
// 地图推荐功能增强版

import { requestMapRecommend } from './yoga-api';

// 缓存管理
const poiCache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5分钟缓存

// 获取缓存key
function getCacheKey(lng, lat, bizType, radius) {
  return `${lng}_${lat}_${bizType}_${radius}`;
}

// 获取用户位置
export function getUserLocation() {
  return new Promise((resolve, reject) => {
    wx.getFuzzyLocation({
      type: 'gcj02',
      success: resolve,
      fail: (error) => {
        console.warn('[Location] 获取位置失败:', error);
        // 返回默认位置（上海市中心）
        resolve({
          latitude: 31.2304,
          longitude: 121.4737,
          isDefault: true
        });
      }
    });
  });
}

// 获取附近POI（带缓存和降级）
export async function fetchNearbyPOIs(options = {}) {
  const {
    bizType = 'yoga',
    radius = 3000,
    userIntent = '',
    useCache = true,
    maxResults = 10,
    lat: overrideLat,
    lng: overrideLng
  } = options;

  try {
    // 获取位置
    let location;
    if (overrideLat != null && overrideLng != null) {
      location = {
        latitude: Number(overrideLat),
        longitude: Number(overrideLng),
        isDefault: false
      };
    } else {
      location = await getUserLocation();
    }
    let { longitude: lng, latitude: lat, isDefault } = location;

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      throw new Error('定位信息无效');
    }

    const inMainlandChina = lat >= 3 && lat <= 54 && lng >= 73 && lng <= 136;
    if (!inMainlandChina) {
      console.warn('[POI] 非国内定位，使用默认推荐');
      const fallback = getDefaultPOIs(bizType).slice(0, maxResults);
      fallback.meta = {
        fromCache: false,
        isDefaultLocation: true,
        reason: 'OUT_OF_COVERAGE'
      };
      return fallback;
    }

    // 检查缓存
    const cacheKey = getCacheKey(lng, lat, bizType, radius);
    if (useCache && poiCache.has(cacheKey)) {
      const cached = poiCache.get(cacheKey);
      if (Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log('[POI] 使用缓存数据');
        const cachedList = [...cached.pois];
        cachedList.meta = {
          fromCache: true,
          isDefaultLocation: isDefault
        };
        return cachedList;
      }
    }

    // 请求推荐
    const pois = await requestMapRecommend({
      lng,
      lat,
      bizType,
      radius,
      userIntent
    });

    // 去重和排序
    const processedPois = processPOIs(pois, maxResults);

    // 更新缓存
    if (processedPois.length > 0) {
      poiCache.set(cacheKey, {
        pois: processedPois,
        timestamp: Date.now()
      });
    }

    const resultList = [...processedPois];
    resultList.meta = {
      fromCache: false,
      isDefaultLocation: isDefault
    };
    return resultList;

  } catch (error) {
    console.error('[POI] 获取失败:', error);

    // 降级方案：返回静态推荐
    const defaults = getDefaultPOIs(bizType);
    const list = Array.isArray(defaults) ? [...defaults] : [];
    list.meta = {
      fromCache: false,
      isDefaultLocation: true,
      error: true
    };
    return list;
  }
}

// POI去重和排序
function processPOIs(pois, maxResults) {
  if (!Array.isArray(pois)) return [];
  
  // 去重（按ID）
  const uniqueMap = new Map();
  pois.forEach(poi => {
    if (poi.id && !uniqueMap.has(poi.id)) {
      uniqueMap.set(poi.id, poi);
    }
  });
  
  // 转换为数组并排序
  const uniquePois = Array.from(uniqueMap.values());
  
  // 综合评分排序（距离30% + 评分50% + 理由20%）
  uniquePois.sort((a, b) => {
    const scoreA = calculatePOIScore(a);
    const scoreB = calculatePOIScore(b);
    return scoreB - scoreA;
  });
  
  return uniquePois.slice(0, maxResults);
}

// 计算POI综合得分
function calculatePOIScore(poi) {
  let score = 0;
  
  // 距离分（越近越高，最高30分）
  if (poi.distance !== null && poi.distance !== undefined) {
    const distScore = Math.max(0, 30 - poi.distance / 100);
    score += distScore;
  }
  
  // 评分（最高50分）
  if (poi.rating) {
    score += parseFloat(poi.rating) * 10;
  }
  
  // 推荐理由（每个理由5分，最高20分）
  if (poi.reasons && poi.reasons.length > 0) {
    score += Math.min(20, poi.reasons.length * 5);
  }
  
  return score;
}

// 导航到POI
export function navigateToPOI(poi) {
  if (!poi || !poi.location) {
    wx.showToast({
      title: '位置信息不完整',
      icon: 'none'
    });
    return;
  }
  
  const [lng, lat] = String(poi.location).split(',').map(Number);
  
  if (!isFinite(lng) || !isFinite(lat)) {
    wx.showToast({
      title: '坐标格式错误',
      icon: 'none'
    });
    return;
  }
  
  wx.openLocation({
    latitude: lat,
    longitude: lng,
    scale: 16,
    name: poi.name || '目的地',
    address: poi.address || ''
  });
}

// 拨打电话
export function callPOI(poi) {
  if (!poi.tel) {
    wx.showToast({
      title: '暂无电话信息',
      icon: 'none'
    });
    return;
  }
  
  wx.makePhoneCall({
    phoneNumber: poi.tel,
    fail: () => {
      wx.showToast({
        title: '拨号失败',
        icon: 'none'
      });
    }
  });
}

// 获取默认推荐（降级方案）
function getDefaultPOIs(bizType) {
  const defaults = {
    yoga: [
      {
        id: 'default_1',
        name: '梵音瑜伽（静安寺店）',
        address: '上海市静安区南京西路1266号',
        distance: null,
        rating: '4.8',
        reasons: ['专业瑜伽馆', '优质师资', '环境优雅'],
        tel: '021-62881234'
      },
      {
        id: 'default_2',
        name: 'Pure Yoga',
        address: '上海市黄浦区淮海中路999号',
        distance: null,
        rating: '4.7',
        reasons: ['国际连锁', '设施完善', '课程丰富'],
        tel: '021-63351234'
      }
    ],
    meditation: [
      {
        id: 'default_3',
        name: '静心禅院',
        address: '上海市徐汇区衡山路88号',
        distance: null,
        rating: '4.9',
        reasons: ['专业冥想', '环境清幽', '名师指导'],
        tel: '021-64881234'
      }
    ],
    pilates: [
      {
        id: 'default_4',
        name: '普拉提工作室',
        address: '上海市长宁区虹桥路1665号',
        distance: null,
        rating: '4.6',
        reasons: ['小班教学', '器械齐全', '专业认证'],
        tel: '021-62701234'
      }
    ]
  };
  
  return defaults[bizType] || defaults.yoga;
}

// 清理缓存
export function clearPOICache() {
  poiCache.clear();
  console.log('[POI] 缓存已清理');
}

// 预加载推荐（应用启动时调用）
export async function preloadRecommendations() {
  try {
    const types = ['yoga', 'meditation', 'pilates'];
    const location = await getUserLocation();
    
    for (const bizType of types) {
      requestMapRecommend({
        lng: location.longitude,
        lat: location.latitude,
        bizType,
        radius: 3000
      }).catch(e => {
        console.warn(`[POI] 预加载 ${bizType} 失败:`, e);
      });
    }
  } catch (e) {
    console.warn('[POI] 预加载失败:', e);
  }
}
