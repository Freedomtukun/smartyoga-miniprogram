const BASE64_PATTERN = /^[A-Za-z0-9+/=_-\s]+$/;

function isBase64Likely(value) {
  if (!value || typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) return false;
  if (!BASE64_PATTERN.test(trimmed)) return false;

  const normalized = trimmed.replace(/\s+/g, '');
  if (normalized.length < 8) return false;

  // Base64 length modulo 4 can be 0 or produce padding requirement (2 or 3 when padding missing)
  const remainder = normalized.length % 4;
  if (remainder === 1) {
    return false;
  }

  return true;
}

function arrayBufferToUtf8(buffer) {
  if (!buffer) return '';
  try {
    const view = buffer instanceof ArrayBuffer
      ? new Uint8Array(buffer)
      : ArrayBuffer.isView(buffer)
        ? new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength)
        : new Uint8Array(buffer);

    if (typeof TextDecoder !== 'undefined') {
      const decoder = new TextDecoder('utf-8');
      return decoder.decode(view);
    }

    let result = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < view.length; i += chunkSize) {
      const chunk = view.subarray(i, i + chunkSize);
      result += String.fromCharCode.apply(null, chunk);
    }
    try {
      return decodeURIComponent(escape(result));
    } catch (decodeErr) {
      console.warn('[json] decodeURIComponent fallback failed', decodeErr);
      return result;
    }
  } catch (err) {
    console.warn('[json] Failed to convert ArrayBuffer to UTF-8 string', err);
    return '';
  }
}

function decodeBase64ToUtf8(base64) {
  if (!base64 || typeof base64 !== 'string') return '';
  let normalized = base64.replace(/\s+/g, '');

  if (!normalized) {
    return '';
  }

  // Support base64url variants
  normalized = normalized.replace(/-/g, '+').replace(/_/g, '/');

  const remainder = normalized.length % 4;
  if (remainder === 1) {
    console.warn('[json] invalid base64 length, abort decoding');
    return '';
  }
  if (remainder > 0) {
    normalized = normalized.padEnd(normalized.length + (4 - remainder), '=');
  }
  try {
    if (typeof wx !== 'undefined' && typeof wx.base64ToArrayBuffer === 'function') {
      const buffer = wx.base64ToArrayBuffer(normalized);
      return arrayBufferToUtf8(buffer);
    }
  } catch (err) {
    console.warn('[json] wx.base64ToArrayBuffer failed', err);
  }

  try {
    if (typeof atob === 'function') {
      const binary = atob(normalized);
      try {
        return decodeURIComponent(escape(binary));
      } catch (decodeErr) {
        console.warn('[json] decodeURIComponent fallback for atob failed', decodeErr);
        return binary;
      }
    }
  } catch (err) {
    console.warn('[json] atob failed', err);
  }

  // Manual decode fallback
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let output = '';
  let buffer = 0;
  let bitsCollected = 0;

  for (let i = 0; i < normalized.length; i++) {
    const ch = normalized.charAt(i);
    if (ch === '=') {
      break;
    }
    const idx = chars.indexOf(ch);
    if (idx === -1) continue;

    buffer = (buffer << 6) | idx;
    bitsCollected += 6;
    if (bitsCollected >= 8) {
      bitsCollected -= 8;
      const code = (buffer >> bitsCollected) & 0xff;
      output += String.fromCharCode(code);
    }
  }

  try {
    return decodeURIComponent(escape(output));
  } catch (err) {
    console.warn('[json] decodeURIComponent fallback after manual decode failed', err);
    return output;
  }
}

export function safeParseJSON(value, defaultValue = null) {
  if (value == null) {
    return defaultValue;
  }

  if (typeof value === 'object') {
    return value;
  }

  if (typeof value !== 'string') {
    return defaultValue;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return defaultValue;
  }

  try {
    return JSON.parse(trimmed);
  } catch (err) {
    if (isBase64Likely(trimmed)) {
      try {
        const decoded = decodeBase64ToUtf8(trimmed);
        if (decoded) {
          return JSON.parse(decoded);
        }
      } catch (decodeErr) {
        console.warn('[json] Failed to parse base64 JSON', decodeErr);
      }
    }
  }

  return defaultValue;
}

export function parseCloudFunctionBody(result) {
  if (!result) return {};
  const body = typeof result.body === 'string' ? result.body : '';
  const parsedBody = safeParseJSON(body, null);
  if (parsedBody) {
    return parsedBody;
  }
  if (result.result && typeof result.result === 'object') {
    return result.result;
  }
  return result;
}

export { decodeBase64ToUtf8 };
export default {
  safeParseJSON,
  parseCloudFunctionBody,
  decodeBase64ToUtf8
};
