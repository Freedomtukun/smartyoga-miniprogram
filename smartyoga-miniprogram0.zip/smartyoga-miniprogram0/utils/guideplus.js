import { FUNCTION_GATEWAY_ENDPOINTS } from './config/env';
import { resolveAudioSource } from './yoga-api';
import { safeParseJSON } from './json';

const poseLibrary = require('../assets/poses');

const POSE_LIST = Array.isArray(poseLibrary) ? poseLibrary : [];

const POSE_LOOKUP = POSE_LIST.reduce((map, pose) => {
  if (pose && pose.id) {
    map[pose.id] = pose;
  }
  return map;
}, {});

const POSE_NAME_LOOKUP = POSE_LIST.reduce((map, pose) => {
  if (!pose) return map;
  const candidates = [pose.name, pose.en, pose.zh, pose.title];
  candidates.forEach((value) => {
    if (typeof value === 'string' && value.trim()) {
      map[value.trim().toLowerCase()] = pose;
    }
  });
  return map;
}, {});

function buildPoseSuggestion(poseId, reasonZh, { reasonEn, tags = [] } = {}) {
  const info = POSE_LOOKUP[poseId] || {};
  const zhName = info.name || info.zh || info.title || poseId;
  const enName = info.en || info.name_en || zhName;
  return {
    poseId,
    id: poseId,
    name: { zh: zhName, en: enName },
    reason: { zh: reasonZh, en: reasonEn || reasonZh },
    displayName: zhName || enName,
    reasonText: reasonZh,
    tags
  };
}

const DEFAULT_TOPIC_POSES = {
  beginner_safety: [
    buildPoseSuggestion('mountain_pose', '脚底稳扎，建立呼吸节奏'),
    buildPoseSuggestion('cat_cow_pose', '温和唤醒脊柱，感受身体反馈')
  ],
  stress_release: [
    buildPoseSuggestion('child_pose', '放松腰背与肩颈，安心沉静'),
    buildPoseSuggestion('legs_up_wall', '倒箭式缓解疲惫，舒展下肢')
  ],
  office_reset: [
    buildPoseSuggestion('seated_twist', '坐姿扭转释放肩背紧绷'),
    buildPoseSuggestion('bridge_pose', '轻度后弯激活臀腿与腰背')
  ],
  prenatal_breath: [
    buildPoseSuggestion('seated_forward_bend', '柔和延展背部，辅助横膈呼吸'),
    buildPoseSuggestion('cat_cow_pose', '猫牛式保持脊柱灵活与骨盆稳定')
  ],
  prenatal_lower_back: [
    buildPoseSuggestion('bridge_pose', '臀腿带动骨盆，减轻腰背压力'),
    buildPoseSuggestion('child_pose', '借助辅助枕头放松腰背')
  ],
  prenatal_relax: [
    buildPoseSuggestion('legs_up_wall', '倒箭式促进下肢回流'),
    buildPoseSuggestion('corpse_pose', '挺尸式呼吸冥想帮助入睡')
  ],
  rehab_lower_back: [
    buildPoseSuggestion('cat_cow_pose', '小幅度猫牛式觉察疼痛边界'),
    buildPoseSuggestion('child_pose', '抱枕支撑下舒缓腰背')
  ],
  rehab_knee_care: [
    buildPoseSuggestion('chair_pose', '髋膝同向缓缓屈伸，强化股四头'),
    buildPoseSuggestion('bridge_pose', '臀桥激活臀肌，减轻膝承压')
  ],
  gentle_mobility: [
    buildPoseSuggestion('mountain_pose', '站姿找回身体排列，保持稳定'),
    buildPoseSuggestion('seated_twist', '坐姿扭转维持柔韧度')
  ],
  teen_focus: [
    buildPoseSuggestion('tree_pose', '树式训练专注与单脚平衡'),
    buildPoseSuggestion('warrior_ii', '战士二式稳固下肢增强信心')
  ],
  teen_strength: [
    buildPoseSuggestion('warrior_i', '战士一式激活核心与腿部力量'),
    buildPoseSuggestion('chair_pose', '幻椅式强化大腿与背部肌群')
  ],
  teen_relax: [
    buildPoseSuggestion('happy_baby_pose', '快乐婴儿式释放腰背，放松心情'),
    buildPoseSuggestion('child_pose', '婴儿式安抚情绪，缓解压力')
  ]
};

function getFallbackPoses(topicId) {
  const list = DEFAULT_TOPIC_POSES[topicId];
  if (!list || !Array.isArray(list)) return [];
  return list.map((item) => ({ ...item }));
}

function matchLibraryPose(item = {}) {
  const rawId = (item.poseId || item.id || '').trim();
  const rawZh = (item.name && item.name.zh) || item.displayName || '';
  const rawEn = (item.name && item.name.en) || item.en || '';

  let target = null;
  if (rawId && POSE_LOOKUP[rawId]) {
    target = POSE_LOOKUP[rawId];
  } else {
    const candidates = [rawZh, rawEn, rawId];
    for (const candidate of candidates) {
      if (!candidate) continue;
      const key = candidate.trim().toLowerCase();
      if (!key) continue;
      if (POSE_NAME_LOOKUP[key]) {
        target = POSE_NAME_LOOKUP[key];
        break;
      }
    }
  }

  if (!target) return null;

  const zhName = target.name || target.zh || rawZh || rawEn || target.en || target.id;
  const enName = target.en || rawEn || target.name_en || zhName;
  const reasonZh = (item.reason && item.reason.zh) || item.reasonText || (item.reason && item.reason.en) || '';
  const reasonEn = (item.reason && item.reason.en) || reasonZh;

  return {
    ...item,
    poseId: target.id,
    id: target.id,
    name: { zh: zhName, en: enName },
    displayName: zhName || enName,
    reason: { zh: reasonZh, en: reasonEn },
    reasonText: reasonZh,
    tags: Array.isArray(item.tags) ? item.tags : []
  };
}

function buildRecommendedPoses(rawList, topicId) {
  const fallbackQueue = getFallbackPoses(topicId);
  const usedKeys = new Set();
  const resolved = [];
  let usedFallback = false;

  const pushPose = (pose, markFallback = false) => {
    if (!pose) return;
    const key = (pose.poseId || pose.id || pose.displayName || '').trim();
    if (!key || usedKeys.has(key)) return;
    usedKeys.add(key);
    if (markFallback) usedFallback = true;
    resolved.push(pose);
  };

  rawList.forEach((item) => {
    const normalized = matchLibraryPose(item);
    if (normalized) {
      pushPose(normalized, false);
    } else if (fallbackQueue.length) {
      pushPose(fallbackQueue.shift(), true);
    }
  });

  if (!resolved.length && fallbackQueue.length) {
    fallbackQueue.forEach((pose) => pushPose(pose, true));
  }

  return { poses: resolved, usedFallback };
}

export const GUIDEPLUS_GROUPS = [
  {
    id: 'general',
    name: '通用人群',
    brief: '建立安全基础，循序渐进练习',
    topics: [
      { id: 'beginner_safety', name: '初学安全', desc: '基础热身与止损信号' },
      { id: 'stress_release', name: '舒缓压力', desc: '释放紧张，调匀呼吸' },
      { id: 'office_reset', name: '久坐舒展', desc: '唤醒脊柱与肩颈活力' }
    ]
  },
  {
    id: 'pregnant',
    name: '孕期人群',
    brief: '安全支撑与呼吸陪伴',
    topics: [
      { id: 'prenatal_breath', name: '孕期呼吸', desc: '稳定坐姿与横膈呼吸' },
      { id: 'prenatal_lower_back', name: '孕期腰背舒缓', desc: '靠墙支撑与温柔波动' },
      { id: 'prenatal_relax', name: '孕期放松', desc: '睡前安抚与情绪调节' }
    ]
  },
  {
    id: 'rehab',
    name: '康复人群',
    brief: '缓慢激活与风险提醒',
    topics: [
      { id: 'rehab_lower_back', name: '腰背康复辅助', desc: '核心唤醒与痛感监测' },
      { id: 'rehab_knee_care', name: '膝关节呵护', desc: '墙面辅助与轨迹控制' },
      { id: 'gentle_mobility', name: '温和灵活度', desc: '小幅度灵活与循序探索' }
    ]
  },
  {
    id: 'teen',
    name: '青少年群体',
    brief: '建立自信与稳定节奏',
    topics: [
      { id: 'teen_focus', name: '专注力训练', desc: '稳定目光与呼吸节奏' },
      { id: 'teen_strength', name: '体态力量', desc: '核心激活与平衡训练' },
      { id: 'teen_relax', name: '舒缓释放', desc: '短时放松与情绪梳理' }
    ]
  },
  {
    id: 'kids',
    name: '少儿',
    brief: '趣味引导与安全陪伴',
    topics: [
      { id: 'kids_bedtime', name: '睡前放松', desc: '故事式放松，助眠准备' },
      { id: 'kids_energy', name: '快乐唤醒', desc: '晨间活力与节奏感' },
      { id: 'kids_balance', name: '趣味平衡', desc: '游戏化平衡与想象力' }
    ]
  }
];

export const GUIDEPLUS_LANG_OPTIONS = [
  { id: 'zh', label: '中文' },
  { id: 'en', label: 'English' }
];

const REQUEST_TIMEOUT = 25000;
const DEFAULT_RETRY_COUNT = 1;
const RETRY_DELAY_MS = 1200;
const RETRYABLE_HTTP_STATUS = new Set([429, 500, 502, 503, 504]);

function normalizeArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  return [value];
}

function ensureStringArray(list = []) {
  return list
    .map((item) => {
      if (item == null) return '';
      if (typeof item === 'string') return item.trim();
      return String(item).trim();
    })
    .filter(Boolean);
}

async function resolveAudioCandidate(candidate) {
  if (!candidate) return '';
  try {
    const playable = await resolveAudioSource(candidate, { prefix: 'guideplus' });
    if (playable) return playable;
  } catch (err) {
    console.warn('[guideplus] resolve audio failed', err);
  }
  if (typeof candidate === 'string') {
    return candidate.trim();
  }
  return '';
}

function unwrapPayload(data) {
  if (!data) return {};
  if (typeof data === 'string') {
    const parsed = safeParseJSON(data, null);
    return parsed || {};
  }
  return data;
}

export function findGroup(groupId) {
  return GUIDEPLUS_GROUPS.find((item) => item.id === groupId) || GUIDEPLUS_GROUPS[0];
}

export function findTopic(groupId, topicId) {
  const group = findGroup(groupId);
  return group.topics.find((item) => item.id === topicId) || group.topics[0];
}

function delay(ms = 0) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function shouldRetry(error) {
  if (!error) return false;
  if (typeof error.statusCode === 'number' && RETRYABLE_HTTP_STATUS.has(error.statusCode)) {
    return true;
  }
  const message = (error.errMsg || error.message || '').toLowerCase();
  if (!message) return false;
  if (message.includes('timeout')) return true;
  if (message.includes('fail system error')) return true;
  if (message.includes('fail net::')) return true;
  if (message.includes('request:fail')) return true;
  return false;
}

function mergeMetadata(baseMeta, incomingMeta) {
  if (!baseMeta) return incomingMeta || {};
  if (!incomingMeta) return { ...baseMeta };
  return { ...baseMeta, ...incomingMeta };
}

function requestGuideplus(payload) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.GUIDEPLUS,
      method: 'POST',
      data: payload,
      header: { 'Content-Type': 'application/json' },
      timeout: REQUEST_TIMEOUT,
      success: async ({ statusCode, data }) => {
        if (statusCode < 200 || statusCode >= 300) {
          const httpError = new Error(`GUIDEPLUS_HTTP_${statusCode}`);
          httpError.statusCode = statusCode;
          httpError.code = 'GUIDEPLUS_HTTP_ERROR';
          httpError.response = data;
          reject(httpError);
          return;
        }

        const body = unwrapPayload(data);
        const ok = body?.success !== false;
        if (!ok) {
          const err = new Error(body?.error?.message || body?.error || 'GUIDEPLUS_FAILED');
          err.code = 'GUIDEPLUS_REMOTE_ERROR';
          err.response = body;
          reject(err);
          return;
        }

        const result = unwrapPayload(body.data) || {};
        const metadata = unwrapPayload(body.metadata) || {};

        const summary = typeof result.summary === 'string' ? result.summary.trim() : '';
        const advice = ensureStringArray(result.advice);
        const oneline = typeof result.oneline === 'string'
          ? result.oneline.trim()
          : (typeof result.oneLine === 'string' ? result.oneLine.trim() : '');

        const basePoses = normalizeArray(result.recommendedPoses).filter((item) => item && typeof item === 'object');
        const { poses: recommendedPoses, usedFallback } = buildRecommendedPoses(basePoses, payload.topic);
        if (usedFallback) {
          metadata.usedFallbackPoses = true;
          metadata.usedFallback = true;
        }

        const audioCandidate = result.audioUrl || result.audio || result.audio_base64;
        const audioUrl = await resolveAudioCandidate(audioCandidate);

        resolve({
          summary,
          advice,
          oneline,
          audioUrl,
          recommendedPoses,
          metadata,
          raw: body
        });
      },
      fail: (err) => {
        if (err instanceof Error) {
          reject(err);
          return;
        }
        const error = new Error((err && err.errMsg) || 'request:fail');
        error.errMsg = err && err.errMsg;
        error.code = 'GUIDEPLUS_REQUEST_FAIL';
        error.raw = err;
        reject(error);
      }
    });
  });
}

export async function fetchGuideplusSuggest({ groupType, topic, lang = 'zh', tts = true } = {}, options = {}) {
  const payload = {
    action: 'guideplus_suggest',
    groupType: groupType || GUIDEPLUS_GROUPS[0].id,
    topic: topic || GUIDEPLUS_GROUPS[0].topics[0].id,
    lang,
    tts
  };

  const maxRetries = typeof options.retries === 'number' ? Math.max(0, options.retries) : DEFAULT_RETRY_COUNT;
  const retryDelay = typeof options.retryDelay === 'number' ? Math.max(0, options.retryDelay) : RETRY_DELAY_MS;

  let attempt = 0;
  let lastError;

  while (attempt <= maxRetries) {
    try {
      const result = await requestGuideplus(payload);
      if (attempt > 0) {
        result.metadata = mergeMetadata(result.metadata, { retryAttempts: attempt + 1 });
      }
      return result;
    } catch (err) {
      lastError = err;
      const canRetry = attempt < maxRetries && shouldRetry(err);
      if (!canRetry) {
        if (err && typeof err === 'object') {
          err.attempts = attempt + 1;
        }
        throw err;
      }
      attempt += 1;
      await delay(retryDelay);
    }
  }

  throw lastError;
}

export default {
  GUIDEPLUS_GROUPS,
  GUIDEPLUS_LANG_OPTIONS,
  fetchGuideplusSuggest,
  findGroup,
  findTopic
};
