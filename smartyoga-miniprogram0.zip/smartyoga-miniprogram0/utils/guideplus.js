import { FUNCTION_GATEWAY_ENDPOINTS } from './config/env';
import { resolveAudioSource } from './yoga-api';
import { safeParseJSON } from './json';

export const GUIDEPLUS_GROUPS = [
  {
    id: 'general',
    name: '通用人群',
    brief: '建立安全基础，循序渐进练习',
    topics: [
      { id: 'beginner_safety', name: '初学安全', desc: '基础热身与止损信号' },
      { id: 'stress_release', name: '舒缓压力', desc: '释放紧张，调匀呼吸' },
      { id: 'office_reset', name: '久坐舒展', desc: '唤醒脊柱与肩颈活力' }
    ]
  },
  {
    id: 'pregnant',
    name: '孕期人群',
    brief: '安全支撑与呼吸陪伴',
    topics: [
      { id: 'prenatal_breath', name: '孕期呼吸', desc: '稳定坐姿与横膈呼吸' },
      { id: 'prenatal_lower_back', name: '孕期腰背舒缓', desc: '靠墙支撑与温柔波动' },
      { id: 'prenatal_relax', name: '孕期放松', desc: '睡前安抚与情绪调节' }
    ]
  },
  {
    id: 'rehab',
    name: '康复人群',
    brief: '缓慢激活与风险提醒',
    topics: [
      { id: 'rehab_lower_back', name: '腰背康复辅助', desc: '核心唤醒与痛感监测' },
      { id: 'rehab_knee_care', name: '膝关节呵护', desc: '墙面辅助与轨迹控制' },
      { id: 'gentle_mobility', name: '温和灵活度', desc: '小幅度灵活与循序探索' }
    ]
  },
  {
    id: 'teen_female',
    name: '青少年（女）',
    brief: '建立自信，保持趣味',
    topics: [
      { id: 'teen_focus', name: '专注力训练', desc: '稳定目光与呼吸节奏' },
      { id: 'teen_confidence', name: '自信体态', desc: '扩胸挺背，感受力量' },
      { id: 'stress_release', name: '舒缓压力', desc: '短时放松与情绪梳理' }
    ]
  },
  {
    id: 'kids',
    name: '少儿',
    brief: '趣味引导与安全陪伴',
    topics: [
      { id: 'kids_bedtime', name: '睡前放松', desc: '故事式放松，助眠准备' },
      { id: 'kids_energy', name: '快乐唤醒', desc: '晨间活力与节奏感' },
      { id: 'kids_balance', name: '趣味平衡', desc: '游戏化平衡与想象力' }
    ]
  }
];

export const GUIDEPLUS_LANG_OPTIONS = [
  { id: 'zh', label: '中文' },
  { id: 'en', label: 'English' }
];

const REQUEST_TIMEOUT = 22000;

function normalizeArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  return [value];
}

function ensureStringArray(list = []) {
  return list
    .map((item) => {
      if (item == null) return '';
      if (typeof item === 'string') return item.trim();
      return String(item).trim();
    })
    .filter(Boolean);
}

async function resolveAudioCandidate(candidate) {
  if (!candidate) return '';
  try {
    const playable = await resolveAudioSource(candidate, { prefix: 'guideplus' });
    if (playable) return playable;
  } catch (err) {
    console.warn('[guideplus] resolve audio failed', err);
  }
  if (typeof candidate === 'string') {
    return candidate.trim();
  }
  return '';
}

function unwrapPayload(data) {
  if (!data) return {};
  if (typeof data === 'string') {
    const parsed = safeParseJSON(data, null);
    return parsed || {};
  }
  return data;
}

export function findGroup(groupId) {
  return GUIDEPLUS_GROUPS.find((item) => item.id === groupId) || GUIDEPLUS_GROUPS[0];
}

export function findTopic(groupId, topicId) {
  const group = findGroup(groupId);
  return group.topics.find((item) => item.id === topicId) || group.topics[0];
}

export async function fetchGuideplusSuggest({ groupType, topic, lang = 'zh', tts = true } = {}) {
  const payload = {
    action: 'guideplus_suggest',
    groupType: groupType || GUIDEPLUS_GROUPS[0].id,
    topic: topic || GUIDEPLUS_GROUPS[0].topics[0].id,
    lang,
    tts
  };

  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.GUIDEPLUS,
      method: 'POST',
      data: payload,
      header: { 'Content-Type': 'application/json' },
      timeout: REQUEST_TIMEOUT,
      success: async ({ statusCode, data }) => {
        if (statusCode < 200 || statusCode >= 300) {
          reject(new Error(`GUIDEPLUS_HTTP_${statusCode}`));
          return;
        }

        const body = unwrapPayload(data);
        const ok = body?.success !== false;
        if (!ok) {
          const err = new Error(body?.error?.message || body?.error || 'GUIDEPLUS_FAILED');
          err.response = body;
          reject(err);
          return;
        }

        const result = unwrapPayload(body.data) || {};
        const metadata = unwrapPayload(body.metadata) || {};

        const summary = typeof result.summary === 'string' ? result.summary.trim() : '';
        const advice = ensureStringArray(result.advice);
        const oneline = typeof result.oneline === 'string'
          ? result.oneline.trim()
          : (typeof result.oneLine === 'string' ? result.oneLine.trim() : '');

        const recommendedPoses = normalizeArray(result.recommendedPoses).map((item) => {
          if (!item || typeof item !== 'object') return {};
          const name = typeof item.name === 'string'
            ? { zh: item.name, en: item.name }
            : (item.name || {});
          const reason = typeof item.reason === 'string'
            ? { zh: item.reason, en: item.reason }
            : (item.reason || {});
          return {
            ...item,
            poseId: item.poseId || item.id || '',
            name,
            reason,
            tags: Array.isArray(item.tags) ? item.tags : []
          };
        });

        const audioCandidate = result.audioUrl || result.audio || result.audio_base64;
        const audioUrl = await resolveAudioCandidate(audioCandidate);

        resolve({
          summary,
          advice,
          oneline,
          audioUrl,
          recommendedPoses,
          metadata,
          raw: body
        });
      },
      fail: reject
    });
  });
}

export default {
  GUIDEPLUS_GROUPS,
  GUIDEPLUS_LANG_OPTIONS,
  fetchGuideplusSuggest,
  findGroup,
  findTopic
};
