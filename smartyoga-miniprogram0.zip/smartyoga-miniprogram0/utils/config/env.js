// 环境：develop / trial / release（由 __wxConfig.envVersion 提供）
const ENV = (typeof __wxConfig !== 'undefined' && __wxConfig.envVersion) || 'release';

// TODO: 替换为你的真实网关与 COS 域名（末尾不带 /）
const API_BASE_URL_MAP = {
  develop: 'https://<dev-gateway-domain>',
  trial:   'https://<staging-gateway-domain>',
  release: 'https://api.yogasmart.cn'
};
const COS_BASE_URL_MAP = {
  develop: 'https://<dev-cos>.cos.ap-shanghai.myqcloud.com',
  trial:   'https://<staging-cos>.cos.ap-shanghai.myqcloud.com',
  release: 'https://<prod-cos>.cos.ap-shanghai.myqcloud.com'
};

const FUNCTION_GATEWAY_BASE_MAP = {
  develop: 'https://fn.yogasmart.cn',
  trial:   'https://fn.yogasmart.cn',
  release: 'https://fn.yogasmart.cn'
};

// 云函数名称（与控制台完全一致）
const CLOUD_FUNCTIONS = {
  FEEDBACK: 'feedback-agent',
  GUIDE_TTS: 'guide-agent',
  MEDITATION_TTS: 'MeditationAgent',
  MAP_RECOMMEND: 'map-recommend'
};

export const RUNTIME = {
  ENV,
  API_BASE_URL: API_BASE_URL_MAP[ENV] || API_BASE_URL_MAP.release,
  COS_BASE_URL: COS_BASE_URL_MAP[ENV] || COS_BASE_URL_MAP.release,
  FUNCTION_GATEWAY_BASE: FUNCTION_GATEWAY_BASE_MAP[ENV] || FUNCTION_GATEWAY_BASE_MAP.release,
  CLOUD_FUNCTIONS
};
