import { FN, FUNCTION_GATEWAY_ENDPOINTS } from './yoga-api';
import { ensurePlayableAudio } from './audio';

async function normalizeMeditationResult(raw, options = {}) {
  const text = raw?.text || raw?.reply || '';
  const audioCandidate = raw?.audioUrl || raw?.audio || raw?.voiceUrl || raw?.audio_base64;
  const audioUrl = await ensurePlayableAudio(audioCandidate, { prefix: 'meditation' , ...options });
  return { text, audioUrl };
}

function requestMeditationViaGateway(payload) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
      method: 'POST',
      data: payload,
      success: ({ statusCode, data }) => {
        if (statusCode >= 200 && statusCode < 300) {
          const body = data?.data || data || {};
          normalizeMeditationResult(body).then(resolve).catch(reject);
        } else {
          reject(Object.assign(new Error(`meditation gateway failed (${statusCode})`), { statusCode, data }));
        }
      },
      fail: reject
    });
  });
}

export async function fetchMeditation({ theme='breath', duration=300 }) {
  const payload = { action:'meditation', theme, duration };
  try {
    const res = await wx.cloud.callFunction({ name: FN.MEDITATION_TTS, data: payload });
    const raw = res?.result || {};
    const body = typeof raw.body === 'string' ? raw.body : null;
    let parsed = raw.result || raw;
    if (body) {
      try {
        parsed = JSON.parse(body);
      } catch (err) {
        console.warn('[meditation] Failed to parse body JSON', err);
      }
    }
    if (parsed && (parsed.ok || parsed.text || parsed.audioUrl || parsed.audio_base64)) {
      return await normalizeMeditationResult(parsed);
    }
    throw new Error('EMPTY_MEDITATION_RESULT');
  } catch (err) {
    console.warn('[meditation] 云函数失败，使用网关降级', err);
    return requestMeditationViaGateway(payload);
  }
}
