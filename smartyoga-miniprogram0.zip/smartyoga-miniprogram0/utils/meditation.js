import { FN, FUNCTION_GATEWAY_ENDPOINTS, extractNestedString, resolveAudioSource } from './yoga-api';
import { safeParseJSON } from './json';

async function normalizeMeditationResult(raw, options = {}) {
  if (!raw) return { text: '', audioUrl: '' };

  if (typeof raw === 'string') {
    const parsed = safeParseJSON(raw, null);
    if (parsed) {
      return normalizeMeditationResult(parsed, options);
    }
  }

  if (raw && typeof raw.data === 'string') {
    const nested = safeParseJSON(raw.data, null);
    if (nested) {
      return normalizeMeditationResult({ ...raw, data: nested }, options);
    }
  }

  const text = extractNestedString(['text', 'reply', 'content', 'message'], raw, raw?.data, raw?.result, raw?.body);
  const audioCandidate = extractNestedString(
    ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
    raw,
    raw?.data,
    raw?.result,
    raw?.body
  );
  const audioUrl = await resolveAudioSource(audioCandidate, { prefix: 'meditation', ...options });
  if (!text && !audioUrl) {
    console.warn('[meditation] normalize result empty', raw);
  }
  return { text, audioUrl };
}

function requestMeditationViaGateway(payload) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
      method: 'POST',
      data: payload,
      success: ({ statusCode, data }) => {
        if (statusCode >= 200 && statusCode < 300) {
          let body = data;
          if (typeof data === 'string') {
            const parsed = safeParseJSON(data, null);
            if (parsed) body = parsed;
          }
          if (body && typeof body.data === 'string') {
            const nested = safeParseJSON(body.data, null);
            if (nested) {
              body = { ...body, data: nested };
            }
          }
          const normalized = body?.data || body || {};
          normalizeMeditationResult(normalized).then(resolve).catch(reject);
        } else {
          reject(Object.assign(new Error(`meditation gateway failed (${statusCode})`), { statusCode, data }));
        }
      },
      fail: reject
    });
  });
}

export async function fetchMeditation({ theme='breath', duration=300 }) {
  const payload = { action:'meditation', theme, duration };
  try {
    const res = await wx.cloud.callFunction({ name: FN.MEDITATION_TTS, data: payload });
    const raw = res?.result ?? res ?? {};
    let parsed = raw?.result || raw;

    if (raw && typeof raw.body === 'string') {
      const parsedBody = safeParseJSON(raw.body, null);
      if (parsedBody) {
        parsed = parsedBody;
      }
    } else if (raw && typeof raw.result === 'string') {
      const parsedResult = safeParseJSON(raw.result, null);
      if (parsedResult) {
        parsed = parsedResult;
      }
    } else if (typeof raw === 'string') {
      const parsedRaw = safeParseJSON(raw, null);
      if (parsedRaw) {
        parsed = parsedRaw;
      }
    }
    if (parsed && typeof parsed.data === 'string') {
      const nested = safeParseJSON(parsed.data, null);
      if (nested) {
        parsed = { ...parsed, data: nested };
      }
    }

    if (parsed && (parsed.ok || parsed.text || parsed.audioUrl || parsed.audio_base64 || parsed.data)) {
      return await normalizeMeditationResult(parsed);
    }
    console.warn('[meditation] unexpected meditation result shape', parsed);
    throw new Error('EMPTY_MEDITATION_RESULT');
  } catch (err) {
    console.warn('[meditation] 云函数失败，使用网关降级', err);
    return requestMeditationViaGateway(payload);
  }
}
