import { FN, FUNCTION_GATEWAY_ENDPOINTS, extractNestedString, resolveAudioSource } from './yoga-api';
import { safeParseJSON } from './json';

const TEXT_KEYS = ['text', 'script', 'content', 'reply', 'message', 'body', 'description'];
const AUDIO_KEYS = ['audio', 'audioUrl', 'audio_base64', 'voice', 'voiceUrl', 'ttsUrl'];
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isUUID(value) {
  return typeof value === 'string' && UUID_REGEX.test(value.trim());
}

function sanitizeAudioCandidate(candidate) {
  if (!candidate) return '';
  if (typeof candidate === 'string' && isUUID(candidate)) {
    return '';
  }
  return candidate;
}

function firstStringByKeys(source, keys = []) {
  if (!source || typeof source !== 'object') return '';
  for (const key of keys) {
    const value = source[key];
    if (typeof value === 'string' && value.trim()) {
      return value.trim();
    }
  }
  return '';
}

async function normalizeMeditationResult(raw, options = {}) {
  if (!raw) return { text: '', audioUrl: '' };

  if (typeof raw === 'string') {
    const parsed = safeParseJSON(raw, null);
    if (parsed) {
      return normalizeMeditationResult(parsed, options);
    }
  }

  if (raw && typeof raw.data === 'string') {
    const nested = safeParseJSON(raw.data, null);
    if (nested) {
      return normalizeMeditationResult({ ...raw, data: nested }, options);
    }
  }

  const text = extractNestedString(['text', 'reply', 'content', 'message'], raw, raw?.data, raw?.result, raw?.body);
  const audioCandidate = extractNestedString(
    ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
    raw,
    raw?.data,
    raw?.result,
    raw?.body
  );
  const sanitized = sanitizeAudioCandidate(audioCandidate);
  const audioUrl = sanitized
    ? await resolveAudioSource(sanitized, { prefix: 'meditation', ...options }).catch((err) => {
        console.warn('[meditation] resolve audio failed', err);
        return '';
      })
    : '';
  if (!text && !audioUrl) {
    console.warn('[meditation] normalize result empty', raw);
  }
  return { text, audioUrl };
}

async function synthesizeMeditationTts(text, { voice = 'gentle_female', lang = 'zh' } = {}) {
  if (!text) return '';
  return new Promise((resolve) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
      method: 'POST',
      data: { action: 'tts', text, voice, lang },
      header: { 'Content-Type': 'application/json' },
      timeout: 20000,
      success: async ({ statusCode = 200, data }) => {
        if (statusCode < 200 || statusCode >= 300) {
          console.warn('[meditation] tts gateway status', statusCode);
          resolve('');
          return;
        }
        const body = typeof data === 'string' ? safeParseJSON(data, {}) : (data || {});
        const payload = body?.data && typeof body.data === 'object' ? body.data : body;
        const candidate = sanitizeAudioCandidate(
          payload?.audioUrl || payload?.audio || payload?.voiceUrl || payload?.audio_base64 ||
          (payload?.voice && (payload.voice.audio || payload.voice.url || payload.voice.audioUrl || payload.voice.audio_base64))
        );
        if (!candidate) {
          resolve('');
          return;
        }
        try {
          const playable = await resolveAudioSource(candidate, { prefix: 'meditation-tts' });
          resolve(playable);
        } catch (err) {
          console.warn('[meditation] tts resolve failed', err);
          resolve('');
        }
      },
      fail: (err) => {
        console.warn('[meditation] tts request failed', err);
        resolve('');
      }
    });
  });
}

export async function startMeditation(options = {}) {
  const url = FUNCTION_GATEWAY_ENDPOINTS.MEDITATION;
  const requestBody = {
    topic: options.topic || options.theme || '放松与呼吸',
    ttsEnable: options.ttsEnable !== false,
    lang: options.lang || 'zh',
    voice: options.voice,
    fast: options.fast
  };

  return new Promise((resolve, reject) => {
    wx.request({
      url,
      method: 'POST',
      data: requestBody,
      header: { 'Content-Type': 'application/json' },
      timeout: options.timeout || 20000,
      success: async (res) => {
        try {
          const raw = typeof res?.data === 'string' ? safeParseJSON(res.data, {}) : (res?.data || {});
          const payload = raw?.data && typeof raw.data === 'object' ? raw.data : raw || {};
          const ok = raw?.success === true || !!(payload.text || payload.script || payload.content);
          if (!ok) {
            reject(new Error(payload?.error || 'MEDITATION_FAILED'));
            return;
          }

          const text =
            (typeof payload.text === 'string' && payload.text.trim()) ||
            (typeof payload.script === 'string' && payload.script.trim()) ||
            (typeof payload.content === 'string' && payload.content.trim()) ||
            extractNestedString(TEXT_KEYS, payload, raw) ||
            '';

          const audioCandidate =
            (typeof payload.audio === 'string' && payload.audio.trim()) ||
            (typeof payload.audioUrl === 'string' && payload.audioUrl.trim()) ||
            (typeof payload.audio_base64 === 'string' && payload.audio_base64.trim()) ||
            (payload.voice && typeof payload.voice === 'object' && (
              (typeof payload.voice.audio === 'string' && payload.voice.audio.trim()) ||
              (typeof payload.voice.url === 'string' && payload.voice.url.trim()) ||
              (typeof payload.voice.audioUrl === 'string' && payload.voice.audioUrl.trim()) ||
              (typeof payload.voice.audio_base64 === 'string' && payload.voice.audio_base64.trim())
            )) ||
            (typeof payload.voiceUrl === 'string' && payload.voiceUrl.trim()) ||
            extractNestedString(AUDIO_KEYS, payload, raw) ||
            '';

          const audioSummary = audioCandidate
            ? `${String(audioCandidate).slice(0, 48)}... (len=${String(audioCandidate).length})`
            : '';
          console.log('[meditation] start payload', {
            textLength: text.length,
            hasAudio: Boolean(audioCandidate),
            audioSummary,
            voiceKeys: payload.voice ? Object.keys(payload.voice) : []
          });

          const audioUrl = audioCandidate
            ? await resolveAudioSource(audioCandidate, { prefix: 'meditation' })
            : '';

          resolve({ ok: true, text: text || '', audioUrl });
        } catch (error) {
          reject(error);
        }
      },
      fail: reject
    });
  });
}

function requestMeditationViaGateway(payload) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
      method: 'POST',
      data: payload,
      success: ({ statusCode, data }) => {
        if (statusCode >= 200 && statusCode < 300) {
          let body = data;
          if (typeof data === 'string') {
            const parsed = safeParseJSON(data, null);
            if (parsed) body = parsed;
          }
          if (body && typeof body.data === 'string') {
            const nested = safeParseJSON(body.data, null);
            if (nested) {
              body = { ...body, data: nested };
            }
          }
          const normalized = body?.data || body || {};
          normalizeMeditationResult(normalized).then(resolve).catch(reject);
        } else {
          reject(Object.assign(new Error(`meditation gateway failed (${statusCode})`), { statusCode, data }));
        }
      },
      fail: reject
    });
  });
}

export async function fetchMeditation({ theme='breath', duration=300, voice='gentle_female' } = {}) {
  let result = null;
  let lastError = null;

  try {
    result = await startMeditation({
      topic: theme,
      theme,
      duration,
      voice,
      ttsEnable: true,
      lang: 'zh'
    });
  } catch (err) {
    console.warn('[meditation] startMeditation failed, fallback to legacy', err);
    lastError = err;
  }

  if (!result || (!result.text && !result.audioUrl)) {
    const payload = { action: 'meditation', theme, duration };
    try {
      const res = await wx.cloud.callFunction({ name: FN.MEDITATION_TTS, data: payload });
      const raw = res?.result ?? res ?? {};
      let parsed = raw?.result || raw;

      if (raw && typeof raw.body === 'string') {
        const parsedBody = safeParseJSON(raw.body, null);
        if (parsedBody) {
          parsed = parsedBody;
        }
      } else if (raw && typeof raw.result === 'string') {
        const parsedResult = safeParseJSON(raw.result, null);
        if (parsedResult) {
          parsed = parsedResult;
        }
      } else if (typeof raw === 'string') {
        const parsedRaw = safeParseJSON(raw, null);
        if (parsedRaw) {
          parsed = parsedRaw;
        }
      }
      if (parsed && typeof parsed.data === 'string') {
        const nested = safeParseJSON(parsed.data, null);
        if (nested) {
          parsed = { ...parsed, data: nested };
        }
      }

      if (parsed && (parsed.ok || parsed.text || parsed.audioUrl || parsed.audio_base64 || parsed.data)) {
        result = await normalizeMeditationResult(parsed, { prefix: 'meditation' });
      } else {
        console.warn('[meditation] unexpected meditation result shape', parsed);
      }
    } catch (fallbackError) {
      console.warn('[meditation] 云函数失败，使用网关降级', fallbackError);
      lastError = fallbackError;
    }

    if ((!result || (!result.text && !result.audioUrl))) {
      try {
        result = await requestMeditationViaGateway(payload);
      } catch (gatewayErr) {
        console.warn('[meditation] request via gateway failed', gatewayErr);
        lastError = gatewayErr;
      }
    }
  }

  if (!result) {
    throw lastError || new Error('MEDIATION_RESULT_EMPTY');
  }

  const text = (result.text || '').trim();
  let audioUrl = result.audioUrl || '';

  if (text && !audioUrl) {
    audioUrl = await synthesizeMeditationTts(text, { voice, lang: 'zh' });
  }

  return { text, audioUrl };
}
