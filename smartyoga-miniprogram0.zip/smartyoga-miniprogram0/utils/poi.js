import { requestMapRecommend } from './yoga-api';

export async function fetchNearby({ lat, lng, keyword='瑜伽|咖啡', radius=3000 }) {
  const pois = await requestMapRecommend({
    lat,
    lng,
    radius,
    bizType: keyword,
    userIntent: '附近推荐'
  });
  return Array.isArray(pois) ? pois : [];
}
