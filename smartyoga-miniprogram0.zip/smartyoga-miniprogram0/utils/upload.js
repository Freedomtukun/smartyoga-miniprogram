const fsm = wx.getFileSystemManager();

export function uploadToCos(localPath, cloudPath) {
  return new Promise((resolve, reject) => {
    wx.cloud.uploadFile({
      cloudPath,
      filePath: localPath,
      success: ({ fileID }) => resolve(fileID),
      fail: reject
    });
  });
}

export function base64ToTempFile(base64, ext = 'mp3') {
  return new Promise((resolve, reject) => {
    if (!base64) {
      reject(new Error('empty_base64'));
      return;
    }
    const data = /^data:/.test(base64)
      ? base64.replace(/^data:[^;]+;base64,/, '')
      : base64;
    const filePath = `${wx.env.USER_DATA_PATH}/tmp_${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
    fsm.writeFile({
      filePath,
      data,
      encoding: 'base64',
      success: () => resolve(filePath),
      fail: reject
    });
  });
}

export default {
  uploadToCos,
  base64ToTempFile
};
