// utils/tts-player.js
// TTS 播放器增强版（单例模式）

const bgm = wx.getBackgroundAudioManager();
let currentUrl = '';
let callbacks = [];

// 播放TTS
export function playTTS(options) {
  const { url, title = '语音播放', singer = '智能助手' } = options;
  
  if (!url) {
    console.error('[TTS] URL不能为空');
    return false;
  }
  
  try {
    // 如果正在播放同一个音频，不重复设置
    if (currentUrl === url && bgm.paused === false) {
      console.log('[TTS] 音频正在播放中');
      return true;
    }
    
    currentUrl = url;
    bgm.title = title;
    bgm.epname = title;
    bgm.singer = singer;
    bgm.src = url;
    
    console.log('[TTS] 开始播放:', url);
    return true;
  } catch (e) {
    console.error('[TTS] 播放失败:', e);
    handleError(e);
    return false;
  }
}

// 暂停TTS
export function pauseTTS() {
  try {
    if (!bgm.paused) {
      bgm.pause();
      console.log('[TTS] 已暂停');
    }
  } catch (e) {
    console.error('[TTS] 暂停失败:', e);
  }
}

// 继续播放TTS
export function resumeTTS() {
  try {
    if (bgm.paused && currentUrl) {
      bgm.play();
      console.log('[TTS] 继续播放');
    }
  } catch (e) {
    console.error('[TTS] 继续播放失败:', e);
  }
}

// 停止TTS
export function stopTTS() {
  try {
    bgm.stop();
    currentUrl = '';
    console.log('[TTS] 已停止');
  } catch (e) {
    console.error('[TTS] 停止失败:', e);
  }
}

// 设置播放速率
export function setPlaybackRate(rate = 1.0) {
  try {
    // 限制范围 0.5 - 2.0
    const validRate = Math.max(0.5, Math.min(2.0, rate));
    bgm.playbackRate = validRate;
    console.log('[TTS] 设置播放速率:', validRate);
  } catch (e) {
    console.error('[TTS] 设置播放速率失败:', e);
  }
}

// 监听TTS事件
export function onTTS(callback) {
  if (typeof callback === 'function') {
    callbacks.push(callback);
  }
}

// 移除监听
export function offTTS(callback) {
  const index = callbacks.indexOf(callback);
  if (index > -1) {
    callbacks.splice(index, 1);
  }
}

// 监听播放结束
export function onTTSEnd(callback) {
  if (typeof callback !== 'function') {
    return () => {};
  }
  const handler = (event, data) => {
    if (event === 'ended') {
      callback(data);
    }
  };
  onTTS(handler);
  return () => offTTS(handler);
}

// 触发回调
function triggerCallbacks(event, data) {
  callbacks.forEach(cb => {
    try {
      cb(event, data);
    } catch (e) {
      console.error('[TTS] 回调执行失败:', e);
    }
  });
}

// 处理错误
function handleError(error) {
  const errCode = error?.errCode || error?.code;
  let message = '播放失败';
  
  if (errCode === 10001) {
    message = '请关闭静音开关或调高音量';
  } else if (errCode === 10002) {
    message = '网络连接异常';
  } else if (errCode === 10003) {
    message = '音频格式不支持';
  } else if (errCode === 10004) {
    message = '音频文件不存在';
  }
  
  wx.showToast({
    title: message,
    icon: 'none',
    duration: 2500
  });
  
  triggerCallbacks('error', { code: errCode, message });
}

// 获取播放状态
export function getTTSStatus() {
  return {
    playing: !bgm.paused,
    currentTime: bgm.currentTime || 0,
    duration: bgm.duration || 0,
    buffered: bgm.buffered || 0,
    url: currentUrl
  };
}

// 跳转到指定时间
export function seekTTS(position) {
  try {
    if (position >= 0 && position <= bgm.duration) {
      bgm.seek(position);
      console.log('[TTS] 跳转到:', position);
    }
  } catch (e) {
    console.error('[TTS] 跳转失败:', e);
  }
}

// 初始化事件监听
function initEventListeners() {
  // 播放事件
  bgm.onPlay(() => {
    console.log('[TTS] 开始播放');
    triggerCallbacks('play');
  });
  
  // 暂停事件
  bgm.onPause(() => {
    console.log('[TTS] 暂停播放');
    triggerCallbacks('pause');
  });
  
  // 停止事件
  bgm.onStop(() => {
    console.log('[TTS] 停止播放');
    currentUrl = '';
    triggerCallbacks('stop');
  });
  
  // 播放结束
  bgm.onEnded(() => {
    console.log('[TTS] 播放结束');
    currentUrl = '';
    triggerCallbacks('ended');
  });
  
  // 错误事件
  bgm.onError((error) => {
    console.error('[TTS] 播放错误:', error);
    currentUrl = '';
    handleError(error);
  });
  
  // 加载中
  bgm.onWaiting(() => {
    console.log('[TTS] 音频加载中...');
    triggerCallbacks('waiting');
  });
  
  // 可以播放
  bgm.onCanplay(() => {
    console.log('[TTS] 音频就绪');
    triggerCallbacks('canplay');
  });
  
  // 时间更新
  bgm.onTimeUpdate(() => {
    triggerCallbacks('timeupdate', {
      currentTime: bgm.currentTime,
      duration: bgm.duration
    });
  });
}

// 初始化
initEventListeners();

// 导出所有方法
export default {
  playTTS,
  pauseTTS,
  resumeTTS,
  stopTTS,
  setPlaybackRate,
  onTTS,
  offTTS,
  onTTSEnd,
  getTTSStatus,
  seekTTS
};
