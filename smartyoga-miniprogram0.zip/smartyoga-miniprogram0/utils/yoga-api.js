import { RUNTIME } from './config/env';
import { call, ApiErrorCodes } from './api';
import { safeParseJSON } from './json';
import { ensurePlayableAudio } from './audio';

const DEFAULT_COS_BASE = 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com';
const DEFAULT_API_BASE = 'https://api.yogasmart.cn';

function trimTrailingSlash(url = '') {
  if (!url) return '';
  return url.endsWith('/') ? url.slice(0, -1) : url;
}

function resolveBaseUrl(runtimeValue, fallback) {
  const trimmed = trimTrailingSlash(runtimeValue);
  if (!trimmed || /<.*>/.test(trimmed)) {
    return fallback;
  }
  return trimmed;
}

function pickString(...candidates) {
  for (const value of candidates) {
    if (value == null) continue;
    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (trimmed) return trimmed;
      continue;
    }
    if (typeof value === 'object') {
      if (typeof value.url === 'string' && value.url.trim()) {
        return value.url.trim();
      }
      if (typeof value.data === 'string' && value.data.trim()) {
        return value.data.trim();
      }
      if (typeof value.value === 'string' && value.value.trim()) {
        return value.value.trim();
      }
      if (typeof value.zh === 'string' && value.zh.trim()) {
        return value.zh.trim();
      }
      if (typeof value.en === 'string' && value.en.trim()) {
        return value.en.trim();
      }
    }
  }
  return '';
}

function deepPickString(source, candidateKeys = []) {
  if (!source || typeof source !== 'object') return '';
  const targets = new Set(candidateKeys);
  const stack = [source];
  const visited = new Set();
  let fallback = '';

  while (stack.length) {
    const node = stack.pop();
    if (!node || typeof node !== 'object') continue;
    if (visited.has(node)) continue;
    visited.add(node);

    if (Array.isArray(node)) {
      for (let i = node.length - 1; i >= 0; i--) {
        stack.push(node[i]);
      }
      continue;
    }

    const entries = Object.entries(node);
    for (let i = entries.length - 1; i >= 0; i--) {
      const [key, value] = entries[i];
      if (value == null) continue;
      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) continue;
        if (targets.size === 0 || targets.has(key)) {
          return trimmed;
        }
        if (!fallback) {
          fallback = trimmed;
        }
      } else if (typeof value === 'object') {
        stack.push(value);
      }
    }
  }

  return fallback;
}

function extractNestedString(primaryCandidates = [], ...sources) {
  const result = pickString(...sources);
  if (result) return result;
  for (const source of sources) {
    const deep = deepPickString(source, primaryCandidates);
    if (deep) return deep;
  }
  return '';
}

export async function resolveAudioSource(source, options = {}) {
  if (!source) return '';
  let candidate = source;

  if (typeof candidate === 'object') {
    candidate = extractNestedString(['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice'], candidate);
  }

  if (typeof candidate === 'string') {
    const trimmed = candidate.trim();
    if (!trimmed) return '';
    if (trimmed.startsWith('cloud://')) {
      const temp = await resolveCloudFileUrl(trimmed);
      return ensurePlayableAudio(temp, options);
    }
    if (trimmed.startsWith('http://tmp/')) {
      // 解决开发者工具 http tmp 警告，替换为 wxfile 协议
      const normalized = trimmed.replace(/^http:\/\/tmp\//, 'wxfile://tmp/');
      return ensurePlayableAudio(normalized, options);
    }
    if (trimmed.startsWith('wxfile://')) {
      return trimmed;
    }
    if (!trimmed.includes('://') && /^tmp[_/]/i.test(trimmed)) {
      return `wxfile://${trimmed.replace(/^\/+/, '')}`;
    }
    if (!trimmed.includes('://') && /^[a-z0-9_-]{16,}$/i.test(trimmed) && !/\./.test(trimmed)) {
      console.warn('[audio] Unrecognized audio identifier, skipping playback', trimmed);
      return '';
    }
    return ensurePlayableAudio(trimmed, options);
  }

  return ensurePlayableAudio(candidate, options);
}

const API_BASE = resolveBaseUrl(RUNTIME.API_BASE_URL, DEFAULT_API_BASE);
const COS_BASE = resolveBaseUrl(RUNTIME.COS_BASE_URL, DEFAULT_COS_BASE);
const FUNCTION_GATEWAY_BASE = trimTrailingSlash(RUNTIME.FUNCTION_GATEWAY_BASE) || 'https://fn.yogasmart.cn';
const GATEWAY_HOSTS = ['fn.yogasmart.cn', 'api.yogasmart.cn'];

export const ENDPOINTS = {
  DETECT_POSE:      `${API_BASE}/api/feedback`,
  DETECT_POSE_FILE: `${API_BASE}/api/feedback/file`,   // 主通道：multipart（保留兼容）
  GUIDE_TTS:        `${API_BASE}/api/tts/guide`,
  MEDI_TTS:         `${API_BASE}/api/tts/meditation`,
  MEDI_GEN:         `${API_BASE}/api/meditation/generate`,
  MAP_RECOMMEND:    `${API_BASE}/api/map/recommend`,
  HEALTH:           `${API_BASE}/api/feedback/health`
};

export const FN = RUNTIME.CLOUD_FUNCTIONS;

export const DEFAULT_POSE_IMAGE = `${COS_BASE}/images/poses/default_pose.png`;
export const GUIDE_TTS_URL = ENDPOINTS.GUIDE_TTS;
export const MEDI_TTS_URL = ENDPOINTS.MEDI_TTS;
export const MEDI_GEN_URL = ENDPOINTS.MEDI_GEN;

export const FUNCTION_GATEWAY_ENDPOINTS = {
  FEEDBACK: `${FUNCTION_GATEWAY_BASE}/api/feedback`,
  MAP: `${FUNCTION_GATEWAY_BASE}/api/map`,
  MEDITATION: `${FUNCTION_GATEWAY_BASE}/api/meditation`,
  GUIDE: `${FUNCTION_GATEWAY_BASE}/api/pose/guide`
};

export function expandGatewayVariants(endpoint) {
  if (!endpoint) return [];
  const variants = new Set();
  try {
    const url = new URL(endpoint);
    const baseHosts = GATEWAY_HOSTS.includes(url.hostname)
      ? GATEWAY_HOSTS
      : [url.hostname, ...GATEWAY_HOSTS];
    baseHosts.forEach(host => {
      const clone = new URL(endpoint);
      clone.hostname = host;
      variants.add(clone.toString());
    });
  } catch (err) {
    variants.add(endpoint);
  }
  return Array.from(variants);
}

export function normalizeFeedbackPayload(raw) {
  try {
    let r = raw;
    if (r && typeof r.body === 'string') {
      const parsedBody = safeParseJSON(r.body, null);
      if (parsedBody) {
        r = parsedBody;
      }
    } else if (typeof r === 'string') {
      const parsedString = safeParseJSON(r, null);
      if (parsedString) {
        r = parsedString;
      } else {
        r = {};
      }
    } else {
      r = r || {};
    }

    if (r && typeof r.data === 'string') {
      const parsedData = safeParseJSON(r.data, null);
      if (parsedData) {
        r = { ...r, data: parsedData };
      }
    }

    if (r && typeof r.result === 'string') {
      const parsedResult = safeParseJSON(r.result, null);
      if (parsedResult) {
        r = { ...r, result: parsedResult };
      }
    }

    if (r?.result && typeof r.result.body === 'string') {
      const parsedBody = safeParseJSON(r.result.body, null);
      if (parsedBody) {
        r = { ...r, result: { ...r.result, body: parsedBody } };
      }
    }

    if (r?.body && typeof r.body === 'string') {
      const parsedBody = safeParseJSON(r.body, null);
      if (parsedBody) {
        r = { ...r, body: parsedBody };
      }
    }

    const base = r?.result && typeof r.result === 'object' ? r.result : r;
    const score = Number(base.score ?? base.data?.score ?? r.score ?? r.data?.score ?? 0);
    const ok = Boolean(
      base.ok || base.code === 0 || base.success === true ||
      r.ok || r.code === 0 || r.success === true
    );

    const audioCandidate = extractNestedString(
      ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
      base,
      base?.data,
      r,
      r?.data,
      r?.body
    );

    const skeletonCandidate = extractNestedString(
      ['skeletonUrl', 'skeleton', 'maskUrl', 'poseImage'],
      base,
      base?.data,
      r,
      r?.data,
      r?.body
    );

    const advice = extractNestedString(
      ['advice', 'tips', 'feedback'],
      base,
      base?.data,
      r,
      r?.data,
      r?.body
    );

    const summary = extractNestedString(
      ['summary', 'description', 'desc'],
      base,
      base?.data,
      r,
      r?.data,
      r?.body
    );

    return {
      ok,
      score,
      advice,
      summary,
      skeletonUrl: skeletonCandidate,
      audioUrl: audioCandidate,
      audio_base64:
        base.audio_base64 || base.data?.audio_base64 ||
        r.audio_base64 || r.data?.audio_base64 || ''
    };
  } catch {
    return { ok:false, score:0, advice:'', summary:'', skeletonUrl:'', audioUrl:'', audio_base64:'' };
  }
}

export function handleApiError(error, fallbackMessage = '服务暂时不可用，请稍后重试') {
  const message = error?.message || fallbackMessage;
  console.error('[API] 调用失败:', { error, fallbackMessage });
  if (typeof wx !== 'undefined' && wx.showToast) {
    wx.showToast({ title: message, icon: 'none' });
  }
  return message;
}

async function requestFunctionGateway(endpoint, data = {}, { method = 'POST', timeout = 20000 } = {}) {
  const variants = expandGatewayVariants(endpoint);
  let lastError = null;

  for (const url of variants) {
    try {
      const res = await new Promise((resolve, reject) => {
        wx.request({
          url,
          method,
          data,
          timeout,
          header: { 'content-type': 'application/json' },
          success: ({ statusCode, data: resData }) => {
            if (statusCode >= 200 && statusCode < 300) {
              resolve(resData);
            } else {
              reject(Object.assign(new Error(`网关调用失败(${statusCode})`), { statusCode, data: resData }));
            }
          },
          fail: reject
        });
      });
      return res;
    } catch (error) {
      lastError = error;
      console.warn('[API] 网关调用失败，尝试下一个地址', url, error);
    }
  }

  throw lastError || new Error('网关调用失败');
}

export async function requestMapRecommend({
  lng,
  lat,
  bizType = 'yoga',
  radius = 3000,
  userIntent = '',
  enableReasons = true,
  limit = 20
} = {}) {
  if (lng == null || lat == null) {
    throw new Error('缺少有效的经纬度用于地点推荐');
  }

  const payload = {
    type: 'recommend',
    lng: Number(lng),
    lat: Number(lat),
    bizType,
    radius,
    userIntent,
    enableReasons,
    limit
  };

  try {
    const data = await call(FN.MAP_RECOMMEND, payload);

    if (!data) return [];
    if (Array.isArray(data)) return data;
    if (Array.isArray(data.items)) return data.items;
    if (Array.isArray(data.pois)) return data.pois;

    return [];
  } catch (error) {
    console.warn('[API] map-recommend 云函数失败，尝试网关降级', error);
    try {
      const gatewayData = await requestFunctionGateway(FUNCTION_GATEWAY_ENDPOINTS.MAP, payload);
      if (!gatewayData) return [];
      if (Array.isArray(gatewayData)) return gatewayData;
      if (Array.isArray(gatewayData.items)) return gatewayData.items;
      if (Array.isArray(gatewayData.pois)) return gatewayData.pois;
      return [];
    } catch (gatewayError) {
      handleApiError(gatewayError, '获取附近推荐失败');
      throw gatewayError;
    }
  }
}

export async function resolveCloudFileUrl(fileIdOrUrl) {
  if (!fileIdOrUrl || typeof fileIdOrUrl !== 'string') {
    return fileIdOrUrl || '';
  }

  if (!fileIdOrUrl.startsWith('cloud://')) {
    return fileIdOrUrl;
  }

  try {
    const { fileList } = await wx.cloud.getTempFileURL({ fileList: [fileIdOrUrl] });
    const tempUrl = fileList?.[0]?.tempFileURL;
    return tempUrl || fileIdOrUrl;
  } catch (err) {
    console.warn('[API] 获取临时链接失败:', err);
    return fileIdOrUrl;
  }
}

export async function uploadFrameForScoring({
  frameBase64,
  poseId,
  frameIndex,
  skipAudio = true,
  meta = {}
} = {}) {
  if (!frameBase64) {
    throw new Error('frameBase64 is required for scoring');
  }

  try {
    const data = await call(FN.FEEDBACK, {
      type: 'poseFrame',
      frameBase64,
      poseId,
      frameIndex,
      skipAudio,
      ...meta
    });

    const payload = normalizeFeedbackPayload(data);
    return {
      ...payload,
      poseId,
      frameIndex
    };
  } catch (error) {
    handleApiError(error, '帧评分失败');
    throw error;
  }
}

export { extractNestedString };

export function processFrameScores(frameResults = []) {
  if (!Array.isArray(frameResults) || frameResults.length === 0) {
    return {
      averageScore: 0,
      bestFrame: null,
      topThreeFrames: [],
      maxScore: 0,
      minScore: 0,
      medianScore: 0
    };
  }

  const scoredFrames = frameResults
    .filter(item => item && typeof item.score === 'number')
    .map(item => ({ ...item, score: Number(item.score) }))
    .sort((a, b) => b.score - a.score);

  if (!scoredFrames.length) {
    return {
      averageScore: 0,
      bestFrame: null,
      topThreeFrames: [],
      maxScore: 0,
      minScore: 0,
      medianScore: 0
    };
  }

  const totalScore = scoredFrames.reduce((sum, item) => sum + item.score, 0);
  const averageScore = Number((totalScore / scoredFrames.length).toFixed(2));
  const topThreeFrames = scoredFrames.slice(0, 3);
  const bestFrame = topThreeFrames[0] || null;
  const maxScore = scoredFrames[0].score;
  const minScore = scoredFrames[scoredFrames.length - 1].score;
  const medianScore = scoredFrames[Math.floor(scoredFrames.length / 2)].score;

  return {
    averageScore,
    bestFrame,
    topThreeFrames,
    maxScore,
    minScore,
    medianScore
  };
}

export function mapApiErrorToMessage(error) {
  if (!error) return '服务暂时不可用';
  const code = error.code ?? error.errCode;
  switch (code) {
    case ApiErrorCodes.TIMEOUT:
      return '服务响应超时，请稍后重试';
    case ApiErrorCodes.NETWORK_ERROR:
      return '网络异常，请检查网络后重试';
    case ApiErrorCodes.FUNCTION_NOT_FOUND:
      return '云函数未部署，请联系管理员';
    case ApiErrorCodes.UNAUTHORIZED:
    case ApiErrorCodes.FORBIDDEN:
      return '权限不足，无法完成操作';
    default:
      return error.message || '服务暂时不可用';
  }
}
