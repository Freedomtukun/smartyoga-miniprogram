import { RUNTIME } from './config/env';
import { call, ApiErrorCodes } from './api';

const DEFAULT_COS_BASE = 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com';
const DEFAULT_API_BASE = 'https://api.yogasmart.cn';

function trimTrailingSlash(url = '') {
  if (!url) return '';
  return url.endsWith('/') ? url.slice(0, -1) : url;
}

const API_BASE = trimTrailingSlash(RUNTIME.API_BASE_URL) || DEFAULT_API_BASE;
const COS_BASE = trimTrailingSlash(RUNTIME.COS_BASE_URL) || DEFAULT_COS_BASE;
const FUNCTION_GATEWAY_BASE = trimTrailingSlash(RUNTIME.FUNCTION_GATEWAY_BASE) || 'https://fn.yogasmart.cn';
const GATEWAY_HOSTS = ['fn.yogasmart.cn', 'api.yogasmart.cn'];

export const ENDPOINTS = {
  DETECT_POSE:      `${API_BASE}/api/feedback`,
  DETECT_POSE_FILE: `${API_BASE}/api/feedback/file`,   // 主通道：multipart（保留兼容）
  GUIDE_TTS:        `${API_BASE}/api/tts/guide`,
  MEDI_TTS:         `${API_BASE}/api/tts/meditation`,
  MEDI_GEN:         `${API_BASE}/api/meditation/generate`,
  MAP_RECOMMEND:    `${API_BASE}/api/map/recommend`,
  HEALTH:           `${API_BASE}/api/feedback/health`
};

export const FN = RUNTIME.CLOUD_FUNCTIONS;

export const DEFAULT_POSE_IMAGE = `${COS_BASE}/images/poses/default_pose.png`;
export const GUIDE_TTS_URL = ENDPOINTS.GUIDE_TTS;
export const MEDI_TTS_URL = ENDPOINTS.MEDI_TTS;
export const MEDI_GEN_URL = ENDPOINTS.MEDI_GEN;

export const FUNCTION_GATEWAY_ENDPOINTS = {
  FEEDBACK: `${FUNCTION_GATEWAY_BASE}/api/feedback`,
  MAP: `${FUNCTION_GATEWAY_BASE}/api/map`,
  MEDITATION: `${FUNCTION_GATEWAY_BASE}/api/meditation`,
  GUIDE: `${FUNCTION_GATEWAY_BASE}/api/pose/guide`
};

export function expandGatewayVariants(endpoint) {
  if (!endpoint) return [];
  const variants = new Set();
  try {
    const url = new URL(endpoint);
    const baseHosts = GATEWAY_HOSTS.includes(url.hostname)
      ? GATEWAY_HOSTS
      : [url.hostname, ...GATEWAY_HOSTS];
    baseHosts.forEach(host => {
      const clone = new URL(endpoint);
      clone.hostname = host;
      variants.add(clone.toString());
    });
  } catch (err) {
    variants.add(endpoint);
  }
  return Array.from(variants);
}

export function normalizeFeedbackPayload(raw) {
  try {
    const r = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
    const score = Number(r.score ?? r.data?.score ?? 0);
    const ok    = Boolean(r.ok || r.code === 0 || r.success === true);
    return {
      ok,
      score,
      advice:      r.advice       || r.data?.advice       || '',
      summary:     r.summary      || r.data?.summary      || '',
      skeletonUrl: r.skeletonUrl  || r.data?.skeletonUrl  || '',
      audioUrl:    r.audioUrl     || r.data?.audioUrl     || ''
    };
  } catch {
    return { ok:false, score:0, advice:'', summary:'', skeletonUrl:'', audioUrl:'' };
  }
}

export function handleApiError(error, fallbackMessage = '服务暂时不可用，请稍后重试') {
  const message = error?.message || fallbackMessage;
  console.error('[API] 调用失败:', { error, fallbackMessage });
  if (typeof wx !== 'undefined' && wx.showToast) {
    wx.showToast({ title: message, icon: 'none' });
  }
  return message;
}

async function requestFunctionGateway(endpoint, data = {}, { method = 'POST', timeout = 20000 } = {}) {
  const variants = expandGatewayVariants(endpoint);
  let lastError = null;

  for (const url of variants) {
    try {
      const res = await new Promise((resolve, reject) => {
        wx.request({
          url,
          method,
          data,
          timeout,
          header: { 'content-type': 'application/json' },
          success: ({ statusCode, data: resData }) => {
            if (statusCode >= 200 && statusCode < 300) {
              resolve(resData);
            } else {
              reject(Object.assign(new Error(`网关调用失败(${statusCode})`), { statusCode, data: resData }));
            }
          },
          fail: reject
        });
      });
      return res;
    } catch (error) {
      lastError = error;
      console.warn('[API] 网关调用失败，尝试下一个地址', url, error);
    }
  }

  throw lastError || new Error('网关调用失败');
}

export async function requestMapRecommend({
  lng,
  lat,
  bizType = 'yoga',
  radius = 3000,
  userIntent = '',
  enableReasons = true,
  limit = 20
} = {}) {
  if (lng == null || lat == null) {
    throw new Error('缺少有效的经纬度用于地点推荐');
  }

  const payload = {
    type: 'recommend',
    lng: Number(lng),
    lat: Number(lat),
    bizType,
    radius,
    userIntent,
    enableReasons,
    limit
  };

  try {
    const data = await call(FN.MAP_RECOMMEND, payload);

    if (!data) return [];
    if (Array.isArray(data)) return data;
    if (Array.isArray(data.items)) return data.items;
    if (Array.isArray(data.pois)) return data.pois;

    return [];
  } catch (error) {
    console.warn('[API] map-recommend 云函数失败，尝试网关降级', error);
    try {
      const gatewayData = await requestFunctionGateway(FUNCTION_GATEWAY_ENDPOINTS.MAP, payload);
      if (!gatewayData) return [];
      if (Array.isArray(gatewayData)) return gatewayData;
      if (Array.isArray(gatewayData.items)) return gatewayData.items;
      if (Array.isArray(gatewayData.pois)) return gatewayData.pois;
      return [];
    } catch (gatewayError) {
      handleApiError(gatewayError, '获取附近推荐失败');
      throw gatewayError;
    }
  }
}

export async function resolveCloudFileUrl(fileIdOrUrl) {
  if (!fileIdOrUrl || typeof fileIdOrUrl !== 'string') {
    return fileIdOrUrl || '';
  }

  if (!fileIdOrUrl.startsWith('cloud://')) {
    return fileIdOrUrl;
  }

  try {
    const { fileList } = await wx.cloud.getTempFileURL({ fileList: [fileIdOrUrl] });
    const tempUrl = fileList?.[0]?.tempFileURL;
    return tempUrl || fileIdOrUrl;
  } catch (err) {
    console.warn('[API] 获取临时链接失败:', err);
    return fileIdOrUrl;
  }
}

export async function uploadFrameForScoring({
  frameBase64,
  poseId,
  frameIndex,
  skipAudio = true,
  meta = {}
} = {}) {
  if (!frameBase64) {
    throw new Error('frameBase64 is required for scoring');
  }

  try {
    const data = await call(FN.FEEDBACK, {
      type: 'poseFrame',
      frameBase64,
      poseId,
      frameIndex,
      skipAudio,
      ...meta
    });

    const payload = normalizeFeedbackPayload(data);
    return {
      ...payload,
      poseId,
      frameIndex
    };
  } catch (error) {
    handleApiError(error, '帧评分失败');
    throw error;
  }
}

export function processFrameScores(frameResults = []) {
  if (!Array.isArray(frameResults) || frameResults.length === 0) {
    return {
      averageScore: 0,
      bestFrame: null,
      topThreeFrames: [],
      maxScore: 0,
      minScore: 0,
      medianScore: 0
    };
  }

  const scoredFrames = frameResults
    .filter(item => item && typeof item.score === 'number')
    .map(item => ({ ...item, score: Number(item.score) }))
    .sort((a, b) => b.score - a.score);

  if (!scoredFrames.length) {
    return {
      averageScore: 0,
      bestFrame: null,
      topThreeFrames: [],
      maxScore: 0,
      minScore: 0,
      medianScore: 0
    };
  }

  const totalScore = scoredFrames.reduce((sum, item) => sum + item.score, 0);
  const averageScore = Number((totalScore / scoredFrames.length).toFixed(2));
  const topThreeFrames = scoredFrames.slice(0, 3);
  const bestFrame = topThreeFrames[0] || null;
  const maxScore = scoredFrames[0].score;
  const minScore = scoredFrames[scoredFrames.length - 1].score;
  const medianScore = scoredFrames[Math.floor(scoredFrames.length / 2)].score;

  return {
    averageScore,
    bestFrame,
    topThreeFrames,
    maxScore,
    minScore,
    medianScore
  };
}

export function mapApiErrorToMessage(error) {
  if (!error) return '服务暂时不可用';
  const code = error.code ?? error.errCode;
  switch (code) {
    case ApiErrorCodes.TIMEOUT:
      return '服务响应超时，请稍后重试';
    case ApiErrorCodes.NETWORK_ERROR:
      return '网络异常，请检查网络后重试';
    case ApiErrorCodes.FUNCTION_NOT_FOUND:
      return '云函数未部署，请联系管理员';
    case ApiErrorCodes.UNAUTHORIZED:
    case ApiErrorCodes.FORBIDDEN:
      return '权限不足，无法完成操作';
    default:
      return error.message || '服务暂时不可用';
  }
}
