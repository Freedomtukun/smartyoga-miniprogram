import { FN, FUNCTION_GATEWAY_ENDPOINTS } from './yoga-api';
import { truncateByBytes } from './text';
import { ensurePlayableAudio } from './audio';

const GUIDE_MAX_BYTES = 768;

function sanitizeGuidePayload(data) {
  const payload = { ...data };
  if (payload.prompt) {
    payload.prompt = truncateByBytes(payload.prompt, GUIDE_MAX_BYTES);
  }
  if (payload.text) {
    payload.text = truncateByBytes(payload.text, GUIDE_MAX_BYTES);
  }
  if (payload.poseId && typeof payload.poseId === 'string') {
    payload.poseId = truncateByBytes(payload.poseId, 128);
  }
  if (payload.voice && typeof payload.voice === 'string') {
    payload.voice = truncateByBytes(payload.voice, 128);
  }
  if (payload.voiceFileID && typeof payload.voiceFileID === 'string') {
    payload.voiceFileID = truncateByBytes(payload.voiceFileID, 256);
  }
  return payload;
}

function extractResult(res) {
  const raw = res?.result || {};
  const body = typeof raw.body === 'string' ? raw.body : null;
  if (body) {
    try {
      return JSON.parse(body);
    } catch (err) {
      console.warn('[guide] failed to parse body JSON', err);
    }
  }
  return raw.result || raw;
}

async function normalizeGuideResult(result) {
  const text = result?.text || '';
  const audioCandidate = result?.audioUrl || result?.voiceUrl || result?.audio || result?.audio_base64 || '';
  const audioUrl = await ensurePlayableAudio(audioCandidate, { prefix: 'guide' });
  return { text, audioUrl };
}

function requestGuideViaGateway(data) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.GUIDE,
      method: 'POST',
      data,
      success: ({ statusCode, data: resData }) => {
        if (statusCode >= 200 && statusCode < 300) {
          normalizeGuideResult({
            text: resData?.text || resData?.data?.text || '',
            audioUrl: resData?.audioUrl || resData?.data?.audioUrl || resData?.voiceUrl || resData?.audio || resData?.audio_base64 || ''
          }).then(resolve).catch(reject);
        } else {
          reject(Object.assign(new Error(`guide gateway failed (${statusCode})`), { statusCode, data: resData }));
        }
      },
      fail: reject
    });
  });
}

async function callGuide(data) {
  try {
    const sanitized = sanitizeGuidePayload(data);
    const res = await wx.cloud.callFunction({ name: FN.GUIDE_TTS, data: sanitized });
    const result = extractResult(res);
    if (result && (result.ok || result.text || result.audioUrl)) {
      return normalizeGuideResult(result);
    }
    throw new Error('EMPTY_GUIDE_RESULT');
  } catch (err) {
    console.warn('[guide] 云函数失败，使用网关降级', err);
    const sanitized = sanitizeGuidePayload(data);
    return requestGuideViaGateway(sanitized);
  }
}

export async function fetchGuideByPose({ poseId, step }) {
  if (!poseId && step == null) return { text: '', audioUrl: '' };
  return callGuide({ action: 'guide', poseId, step });
}

export async function fetchGuideByPrompt(prompt) {
  const content = (prompt || '').trim();
  if (!content) return { text: '', audioUrl: '' };
  return callGuide({ action: 'prompt', prompt: content });
}

export async function fetchGuideByVoice({ voiceFileID, audioBase64, format = 'mp3' } = {}) {
  if (voiceFileID) {
    return callGuide({ action: 'voice', voiceFileID, format });
  }
  if (audioBase64) {
    return callGuide({ action: 'voice', audioBase64, format });
  }
  return { text: '', audioUrl: '' };
}
