import { FN, FUNCTION_GATEWAY_ENDPOINTS, extractNestedString, resolveAudioSource } from './yoga-api';
import { truncateByBytes } from './text';
import { safeParseJSON } from './json';

const GUIDE_MAX_BYTES = 768;

function sanitizeGuidePayload(data) {
  const payload = { ...data };
  if (payload.prompt) {
    payload.prompt = truncateByBytes(payload.prompt, GUIDE_MAX_BYTES);
  }
  if (payload.text) {
    payload.text = truncateByBytes(payload.text, GUIDE_MAX_BYTES);
  }
  if (payload.poseId && typeof payload.poseId === 'string') {
    payload.poseId = truncateByBytes(payload.poseId, 128);
  }
  if (payload.voice && typeof payload.voice === 'string') {
    payload.voice = truncateByBytes(payload.voice, 128);
  }
  if (payload.voiceFileID && typeof payload.voiceFileID === 'string') {
    payload.voiceFileID = truncateByBytes(payload.voiceFileID, 256);
  }
  return payload;
}

function extractResult(res) {
  if (!res) return {};
  const raw = res?.result ?? res;

  if (raw && typeof raw.body === 'string') {
    const parsedBody = safeParseJSON(raw.body, null);
    if (parsedBody) {
      return parsedBody;
    }
  }

  if (raw && typeof raw.data === 'string') {
    const parsedData = safeParseJSON(raw.data, null);
    if (parsedData) {
      return parsedData;
    }
  }

  if (raw && typeof raw.result === 'string') {
    const parsedResult = safeParseJSON(raw.result, null);
    if (parsedResult) {
      return parsedResult;
    }
  }

  if (typeof raw === 'string') {
    const parsedRaw = safeParseJSON(raw, null);
    if (parsedRaw) {
      return parsedRaw;
    }
  }

  return raw?.result || raw?.data || raw || {};
}

async function normalizeGuideResult(result) {
  if (!result) return { text: '', audioUrl: '' };

  if (typeof result === 'string') {
    const parsed = safeParseJSON(result, null);
    if (parsed) {
      return normalizeGuideResult(parsed);
    }
  }

  if (result && typeof result.data === 'string') {
    const nested = safeParseJSON(result.data, null);
    if (nested) {
      return normalizeGuideResult({ ...result, data: nested });
    }
  }

  const text = extractNestedString(
    ['text', 'content', 'reply', 'message'],
    result,
    result?.data,
    result?.body,
    result?.result
  );
  const audioCandidate = extractNestedString(
    ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
    result,
    result?.data,
    result?.body,
    result?.result
  );
  const audioUrl = await resolveAudioSource(audioCandidate, { prefix: 'guide' });
  if (!text && !audioUrl) {
    console.warn('[guide] normalize result empty', result);
  }
  return { text, audioUrl };
}

async function buildFallbackGuide(data = {}, errorResult = {}) {
  const baseText = data.prompt || data.text || data.content || '';
  let text = baseText;
  if (!text) {
    const poseHint = data.poseId ? `体式 ${data.poseId}` : '当前体式';
    text = `${poseHint}暂时无法获取智能引导，请保持稳定呼吸并注意身体对齐。`;
  }

  let audioUrl = '';
  try {
    const ttsRes = await wx.cloud.callFunction({
      name: FN.GUIDE_TTS,
      data: { action: 'tts_feedback', text }
    });
    const raw = ttsRes?.result || ttsRes || {};
    const candidate = extractNestedString(
      ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice'],
      raw,
      raw?.data,
      raw?.result,
      raw?.body
    );
    audioUrl = await resolveAudioSource(candidate, { prefix: 'guide-fallback' });
  } catch (err) {
    console.warn('[guide] fallback TTS failed', err);
  }

  return { text, audioUrl };
}

async function requestGuideViaGateway(data) {
  const response = await new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.GUIDE,
      method: 'POST',
      data,
      success: ({ statusCode, data: resData }) => {
        if (statusCode >= 200 && statusCode < 300) {
          resolve(resData);
        } else {
          reject(Object.assign(new Error(`guide gateway failed (${statusCode})`), { statusCode, data: resData }));
        }
      },
      fail: reject
    });
  });

  let body = response;
  if (typeof response === 'string') {
    const parsed = safeParseJSON(response, null);
    if (parsed) body = parsed;
  }

  if (body && typeof body.data === 'string') {
    const nested = safeParseJSON(body.data, null);
    if (nested) {
      body = { ...body, data: nested };
    }
  }

  const normalized = await normalizeGuideResult(body);
  if (normalized.text || normalized.audioUrl) {
    return normalized;
  }

  return buildFallbackGuide(data, body);
}

async function callGuide(data) {
  try {
    const sanitized = sanitizeGuidePayload(data);
    const res = await wx.cloud.callFunction({ name: FN.GUIDE_TTS, data: sanitized });
    const result = extractResult(res);
    if (result && (result.ok || result.text || result.audioUrl)) {
      return normalizeGuideResult(result);
    }
    console.warn('[guide] unexpected guide result shape', result);
    const fallback = await buildFallbackGuide(sanitized, result);
    if (fallback?.text) {
      return fallback;
    }
    throw new Error('EMPTY_GUIDE_RESULT');
  } catch (err) {
    console.warn('[guide] 云函数失败，使用网关降级', err);
    const sanitized = sanitizeGuidePayload(data);
    try {
      return await requestGuideViaGateway(sanitized);
    } catch (gatewayError) {
      console.warn('[guide] gateway fallback failed', gatewayError);
      const fallback = await buildFallbackGuide(sanitized, gatewayError);
      if (fallback?.text) {
        return fallback;
      }
      throw gatewayError;
    }
  }
}

export async function fetchGuideByPose({ poseId, step }) {
  if (!poseId && step == null) return { text: '', audioUrl: '' };
  return callGuide({ action: 'guide', poseId, step });
}

export async function fetchGuideByPrompt(prompt) {
  const content = (prompt || '').trim();
  if (!content) return { text: '', audioUrl: '' };
  return callGuide({ action: 'prompt', prompt: content });
}

export async function fetchGuideByVoice({ voiceFileID, audioBase64, format = 'mp3' } = {}) {
  if (voiceFileID) {
    return callGuide({ action: 'voice', voiceFileID, format });
  }
  if (audioBase64) {
    return callGuide({ action: 'voice', audioBase64, format });
  }
  return { text: '', audioUrl: '' };
}
