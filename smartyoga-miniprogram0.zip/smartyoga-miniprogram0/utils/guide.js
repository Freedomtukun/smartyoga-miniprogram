import { FUNCTION_GATEWAY_ENDPOINTS, FN, extractNestedString, resolveAudioSource } from './yoga-api';
import { safeParseJSON } from './json';
import { truncateByBytes } from './text';

const GUIDE_MAX_BYTES = 768;
const REQUEST_TIMEOUT = 15000;

// 轻量 alias：常见自由文本 -> 体式名称
export const POSE_ALIASES = {
  '下犬': '下犬式',
  '向下犬式': '下犬式',
  'down dog': 'Downward Dog',
  'adho mukha': 'Adho Mukha Svanasana'
};

function sanitizeGuidePayload(data = {}) {
  const payload = {};

  if (data.action) payload.action = String(data.action).trim();
  if (data.pose) payload.pose = truncateByBytes(String(data.pose).trim(), GUIDE_MAX_BYTES);
  if (data.poseId) payload.poseId = truncateByBytes(String(data.poseId).trim(), 160);
  if (data.prompt) payload.prompt = truncateByBytes(String(data.prompt).trim(), GUIDE_MAX_BYTES);
  if (data.text) payload.text = truncateByBytes(String(data.text).trim(), GUIDE_MAX_BYTES);
  if (data.voice) payload.voice = truncateByBytes(String(data.voice).trim(), 96);
  if (data.lang) payload.lang = truncateByBytes(String(data.lang).trim(), 32);
  if (data.format) payload.format = String(data.format).trim();

  if (data.voiceFileID) payload.voiceFileID = truncateByBytes(String(data.voiceFileID).trim(), 256);
  if (data.audioBase64) payload.audioBase64 = data.audioBase64;

  if (data.ttsEnable != null) payload.ttsEnable = Boolean(data.ttsEnable);
  if (data.fast != null) payload.fast = Boolean(data.fast);

  return payload;
}

export function normalizePoseInput(input) {
  if (input == null) return null;

  if (typeof input === 'string') {
    const trimmed = input.trim();
    if (!trimmed) return null;
    const lower = trimmed.toLowerCase();
    for (const [alias, target] of Object.entries(POSE_ALIASES)) {
      if (lower.includes(alias.toLowerCase())) {
        return { pose: target };
      }
    }
    return { pose: trimmed };
  }

  if (typeof input === 'object') {
    if (input.poseId) {
      return { poseId: String(input.poseId).trim() };
    }
    if (input.pose) {
      return { pose: String(input.pose).trim() };
    }
  }

  return null;
}

function unwrapGuidePayload(raw) {
  if (raw == null) return {};
  let current = raw;
  const visited = new Set();

  while (true) {
    if (visited.has(current)) break;
    visited.add(current);

    if (typeof current === 'string') {
      const parsed = safeParseJSON(current, null);
      if (parsed) {
        current = parsed;
        continue;
      }
      break;
    }

    if (!current || typeof current !== 'object') {
      break;
    }

    if (current.body != null) {
      current = current.body;
      continue;
    }
    if (current.data != null) {
      current = current.data;
      continue;
    }
    if (current.result != null) {
      current = current.result;
      continue;
    }

    break;
  }

  return typeof current === 'object' && current !== null ? current : {};
}

function ensurePrompts(value) {
  if (!value) return [];
  if (Array.isArray(value)) {
    return value
      .map((item) => {
        if (!item) return null;
        if (typeof item === 'string') {
          const text = item.trim();
          return text ? { text } : null;
        }
        if (typeof item === 'object') {
          if (item.text) {
            return { ...item, text: String(item.text) };
          }
          if (item.content) {
            return { ...item, text: String(item.content) };
          }
          return item;
        }
        return null;
      })
      .filter(Boolean);
  }
  if (typeof value === 'string') {
    const text = value.trim();
    return text ? [{ text }] : [];
  }
  return [];
}

function combinePromptText(prompts) {
  if (!Array.isArray(prompts) || !prompts.length) return '';
  return prompts
    .map((item) => {
      if (!item) return '';
      if (typeof item === 'string') return item;
      if (typeof item.text === 'string') return item.text;
      if (typeof item.content === 'string') return item.content;
      return '';
    })
    .filter(Boolean)
    .join('\n');
}

async function withPlayableAudio(body, options = {}) {
  const audioCandidate = extractNestedString(
    ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
    body,
    body?.data,
    body?.result
  );

  let audioUrl = '';
  let audioBase64 = '';

  if (audioCandidate) {
    audioUrl = await resolveAudioSource(audioCandidate, { prefix: options.audioPrefix || 'guide' });
    if (!audioUrl && typeof audioCandidate === 'string') {
      const match = /^data:audio\/\w+;base64,(.+)$/i.exec(audioCandidate);
      audioBase64 = match ? match[1] : audioCandidate;
    }
  }

  if (!audioBase64 && typeof body?.audio_base64 === 'string') {
    audioBase64 = body.audio_base64;
  }

  return { audioUrl, audio_base64: audioBase64 };
}

function buildGuideError(body, fallback = 'GUIDE_FAILED') {
  const message = body?.error || fallback;
  const error = new Error(message);
  if (body?.error) error.code = body.error;
  if (body?.hint) error.hint = body.hint;
  error.response = body;
  return error;
}

function requestGuideThroughGateway(payload) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.GUIDE,
      method: 'POST',
      data: payload,
      header: { 'Content-Type': 'application/json' },
      timeout: REQUEST_TIMEOUT,
      success: ({ statusCode, data }) => {
        const body = unwrapGuidePayload(data);
        if (statusCode >= 200 && statusCode < 300) {
          if (body?.ok === false) {
            reject(buildGuideError(body));
            return;
          }
          resolve(body);
        } else {
          const error = new Error(`GUIDE_HTTP_${statusCode || 'ERROR'}`);
          error.statusCode = statusCode;
          error.response = body;
          reject(error);
        }
      },
      fail: reject
    });
  });
}

async function normalizeGuideResponse(raw, options = {}) {
  const body = unwrapGuidePayload(raw);
  const prompts = ensurePrompts(body.prompts || body.steps || body.guide || body?.data?.prompts);
  const text = body.text || body.content || body.reply || body.message || combinePromptText(prompts);
  const { audioUrl, audio_base64 } = await withPlayableAudio(body, options);

  return {
    ok: body.ok !== false,
    pose: body.pose || body.poseName || body.poseId || '',
    hint: body.hint,
    prompts,
    text: text || '',
    audioUrl,
    audio_base64,
    raw: body
  };
}

async function callLegacyGuide(data) {
  const sanitized = sanitizeGuidePayload({ ...data, action: data.action || 'guide' });
  const res = await wx.cloud.callFunction({ name: FN.GUIDE_TTS, data: sanitized });
  const raw = res?.result ?? res ?? {};
  const body = unwrapGuidePayload(raw);
  if (body?.ok === false) {
    throw buildGuideError(body);
  }
  return normalizeGuideResponse(body, { audioPrefix: 'guide' });
}

export async function guideByPose(poseOrId, opts = {}) {
  const normalized = normalizePoseInput(poseOrId);
  if (!normalized) {
    const error = new Error('NO_POSE_INPUT');
    error.code = 'NO_POSE_INPUT';
    throw error;
  }

  const payload = sanitizeGuidePayload({
    ...normalized,
    ttsEnable: opts.ttsEnable !== undefined ? opts.ttsEnable : true,
    lang: opts.lang,
    voice: opts.voice,
    fast: opts.fast
  });

  try {
    const gatewayBody = await requestGuideThroughGateway(payload);
    return normalizeGuideResponse(gatewayBody, { audioPrefix: 'guide' });
  } catch (err) {
    if (err && (err.code === 'POSE_NOT_FOUND' || err.message === 'POSE_NOT_FOUND')) {
      const error = new Error('POSE_NOT_FOUND');
      error.hint = err.hint || '请尝试使用体式中文、英文或别名';
      throw error;
    }

    try {
      return await callLegacyGuide({
        ...payload,
        prompt: payload.pose || payload.poseId,
        action: 'guide'
      });
    } catch (fallbackError) {
      throw fallbackError;
    }
  }
}

export async function fetchGuideByPose({ poseId, pose, ...opts } = {}) {
  if (poseId) {
    return guideByPose({ poseId }, opts);
  }
  if (pose) {
    return guideByPose(pose, opts);
  }
  return guideByPose(poseId || pose, opts);
}

export async function fetchGuideByPrompt(prompt, opts = {}) {
  if (!prompt) {
    return {
      ok: false,
      prompts: [],
      text: '',
      audioUrl: '',
      audio_base64: ''
    };
  }
  return guideByPose(prompt, opts);
}

export async function fetchGuideByVoice({ voiceFileID, audioBase64, format = 'mp3', ...opts } = {}) {
  if (!voiceFileID && !audioBase64) {
    return {
      ok: false,
      prompts: [],
      text: '',
      audioUrl: '',
      audio_base64: ''
    };
  }

  try {
    return await callLegacyGuide({
      action: 'voice',
      voiceFileID,
      audioBase64,
      format,
      ttsEnable: opts.ttsEnable !== undefined ? opts.ttsEnable : true,
      lang: opts.lang,
      voice: opts.voice,
      fast: opts.fast
    });
  } catch (error) {
    throw error;
  }
}
