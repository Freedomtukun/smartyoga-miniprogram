import { call } from './api';
import {
  FN,
  normalizeFeedbackPayload,
  resolveCloudFileUrl,
  mapApiErrorToMessage,
  extractNestedString,
  resolveAudioSource
} from './yoga-api';
import { safeParseJSON } from './json';
import { base64ToTempFile } from './upload';

async function ttsFallback(text) {
  if (!text) return '';
  const res = await wx.cloud.callFunction({
    name: FN.GUIDE_TTS,
    data: { action: 'tts_feedback', text }
  });
  return res?.result?.audioUrl || '';
}

function buildCloudPath(filePath = '') {
  const extMatch = /\.([a-zA-Z0-9]+)$/.exec(filePath);
  const ext = (extMatch && extMatch[1]) ? extMatch[1] : 'jpg';
  const timestamp = Date.now();
  const random = Math.random().toString(36).slice(2, 8);
  return `pose-uploads/${timestamp}-${random}.${ext}`;
}

export async function uploadAndScore(filePath, options = {}) {
  if (!filePath) {
    throw new Error('请先选择需要评分的图片');
  }

  const {
    skipAudio = false,
    poseId = '',
    keepRemoteFile = false,
    ...rest
  } = options;

  let fileID;
  let cloudPath;

  try {
    cloudPath = buildCloudPath(filePath);
    const uploadRes = await wx.cloud.uploadFile({
      cloudPath,
      filePath
    });

    fileID = uploadRes?.fileID;
    if (!fileID) {
      throw new Error('图片上传失败，请稍后重试');
    }

    const responseData = await call(FN.FEEDBACK, {
      type: 'poseDetect',
      imageKey: fileID,
      skipAudio,
      poseId,
      ...rest
    });

    let parsedData = null;
    if (responseData && typeof responseData.body === 'string') {
      parsedData = safeParseJSON(responseData.body, null);
    }
    if (!parsedData && typeof responseData === 'string') {
      parsedData = safeParseJSON(responseData, null);
    }
    if (!parsedData && responseData && typeof responseData.result === 'string') {
      parsedData = safeParseJSON(responseData.result, null);
    }
    if (!parsedData) {
      parsedData = responseData;
    }

    if (parsedData && typeof parsedData.data === 'string') {
      const nested = safeParseJSON(parsedData.data, null);
      if (nested) {
        parsedData = { ...parsedData, data: nested };
      }
    }

    const payload = normalizeFeedbackPayload(parsedData);
    if (!payload.skeletonUrl) {
      payload.skeletonUrl = extractNestedString(
        ['skeletonUrl', 'skeleton', 'maskUrl', 'poseImage'],
        parsedData,
        parsedData?.data
      );
    }
    if (!payload.audioUrl && !payload.audio_base64) {
      const audioCandidate = extractNestedString(
        ['audioUrl', 'audio', 'voiceUrl', 'audio_base64', 'voice', 'ttsUrl'],
        parsedData,
        parsedData?.data
      );
      if (audioCandidate) {
        payload.audioUrl = audioCandidate;
      }
    }
    if (!payload.ok) {
      throw new Error(parsedData?.message || '评分失败');
    }

    if (payload.skeletonUrl) {
      payload.skeletonUrl = await resolveCloudFileUrl(payload.skeletonUrl);
      if (payload.skeletonUrl && typeof payload.skeletonUrl === 'string') {
        try {
          if (payload.skeletonUrl.startsWith('data:image')) {
            payload.skeletonUrl = await base64ToTempFile(payload.skeletonUrl, 'png');
          } else if (!payload.skeletonUrl.startsWith('http') && !payload.skeletonUrl.startsWith('cloud://')) {
            const maybeBase64 = payload.skeletonUrl.replace(/\s+/g, '');
            if (/^[A-Za-z0-9+/=_-]+$/.test(maybeBase64) && maybeBase64.length > 200) {
              payload.skeletonUrl = await base64ToTempFile(maybeBase64, 'png');
            }
          }
        } catch (err) {
          console.warn('[score-upload] skeleton base64 convert failed', err);
        }
      }
    }

    if (payload.audioUrl) {
      payload.audioUrl = await resolveCloudFileUrl(payload.audioUrl);
    } else if (!skipAudio) {
      try {
        payload.audioUrl = await ttsFallback(payload.advice || payload.summary || '请根据建议微调体式');
      } catch (err) {
        console.warn('[score-upload] TTS fallback failed', err);
      }
    }

    if (payload.audioUrl || payload.audio) {
      const candidate = payload.audioUrl || payload.audio || payload.audio_base64;
      const playable = await resolveAudioSource(candidate, { prefix: 'feedback' });
      if (playable) {
        payload.audioUrl = playable;
        payload.audio = playable;
        payload.audio_base64 = '';
      }
    }

    payload.sourceFileId = fileID;
    payload.cloudPath = cloudPath;

    if (!keepRemoteFile) {
      setTimeout(() => {
        wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
          console.warn('[score-upload] deleteFile failed', err);
        });
      }, 30_000);
    }

    return payload; // { ok, score, advice, summary?, skeletonUrl?, audioUrl? }
  } catch (error) {
    if (fileID && !keepRemoteFile) {
      wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
        console.warn('[score-upload] cleanup deleteFile failed', err);
      });
    }
    const errMsg = error?.errMsg || error?.message || '';
    if (!error.code && /413|Payload Too Large|data exceed max size/i.test(errMsg)) {
      error.code = 'PAYLOAD_TOO_LARGE';
    }
    console.warn('[score-upload] 云函数通道失败', error);
    if (error.code === 'PAYLOAD_TOO_LARGE') {
      throw error;
    }
    const message = mapApiErrorToMessage(error);
    const wrappedError = new Error(message);
    wrappedError.cause = error;
    throw wrappedError;
  }
}
