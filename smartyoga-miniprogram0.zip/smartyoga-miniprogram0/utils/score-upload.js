import { call } from './api';
import {
  FN,
  FUNCTION_GATEWAY_ENDPOINTS,
  normalizeFeedbackPayload,
  resolveCloudFileUrl,
  mapApiErrorToMessage,
  extractNestedString,
  resolveAudioSource
} from './yoga-api';
import { safeParseJSON } from './json';
import { base64ToTempFile } from './upload';

const fs = wx.getFileSystemManager();

/* ---------- 工具 ---------- */

function buildCloudPath(filePath = '') {
  const match = /\.([a-z0-9]+)$/i.exec(filePath || '');
  const ext = match ? match[1].toLowerCase() : 'jpg';
  return `pose-uploads/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
}

function getImageExt(path = '') {
  const match = /\.([a-z0-9]+)$/i.exec(path || '');
  return match ? match[1].toLowerCase() : 'jpg';
}

function readFileAsBase64(path) {
  return new Promise((resolve, reject) => {
    fs.readFile({
      filePath: path,
      encoding: 'base64',
      success: ({ data }) => resolve(data),
      fail: reject
    });
  });
}

/* ---------- HTTP 直连评分 ---------- */

async function requestHttpScore(path, { skipAudio = false, poseId = '', imageBase64 = '', imageExt = '', ...rest } = {}) {
  const ext = (imageExt || getImageExt(path) || 'jpg').toLowerCase();
  let payloadBase64 = (imageBase64 || '').replace(/\s+/g, '');

  if (!payloadBase64) {
    if (!path) throw new Error('IMAGE_PATH_MISSING');
    payloadBase64 = await readFileAsBase64(path);
  }

  if (!payloadBase64) throw new Error('IMAGE_BASE64_EMPTY');

  return new Promise((resolve, reject) => {
    wx.request({
      url: FUNCTION_GATEWAY_ENDPOINTS.FEEDBACK,
      method: 'POST',
      data: {
        action: 'score',
        imageBase64: payloadBase64,
        imageExt: ext,
        skipAudio,
        poseId,
        ...rest
      },
      header: { 'Content-Type': 'application/json' },
      timeout: 30_000,
      success: ({ statusCode, data }) => {
        if (statusCode >= 200 && statusCode < 300) {
          resolve(data?.data || data || {});
        } else {
          const err = Object.assign(new Error(`HTTP_${statusCode}`), { statusCode, data });
          if (statusCode === 413) {
            err.code = 'PAYLOAD_TOO_LARGE';
          }
          reject(err);
        }
      },
      fail: reject
    });
  });
}


async function ttsFallback(text) {
  if (!text || !text.trim()) return '';
  const cleaned = text.trim();
  const attempts = [
    { url: FUNCTION_GATEWAY_ENDPOINTS.FEEDBACK && `${FUNCTION_GATEWAY_ENDPOINTS.FEEDBACK}/tts`, payload: { text: cleaned } },
    { url: FUNCTION_GATEWAY_ENDPOINTS.GUIDE && `${FUNCTION_GATEWAY_ENDPOINTS.GUIDE}/tts`, payload: { text: cleaned } },
    { url: FUNCTION_GATEWAY_ENDPOINTS.FEEDBACK, payload: { action: 'tts', text: cleaned } }
  ];

  const request = ({ url, payload }) => new Promise((resolve) => {
    if (!url) return resolve({ ok: false });
    wx.request({
      url,
      method: 'POST',
      data: payload,
      header: { 'Content-Type': 'application/json' },
      timeout: 15000,
      success: ({ statusCode, data }) => {
        if (statusCode >= 200 && statusCode < 300) {
          resolve(data?.data || data || {});
        } else {
          resolve({ ok: false, statusCode });
        }
      },
      fail: (err) => resolve({ ok: false, error: err })
    });
  });

  for (const attempt of attempts) {
    const result = await request(attempt);
    if (!result) continue;
    const body = result.data || result.body || result;
    const success = body.ok !== false && body.success !== false;
    if (!success) continue;
    const candidate =
      body.audioUrl ||
      body.audio ||
      body.audio_base64 ||
      (body.voice && (body.voice.audioUrl || body.voice.audio || body.voice.audio_base64)) ||
      body.voiceUrl;
    if (candidate) return candidate;
  }

  return '';
}

/* ---------- 结果补全（骨架/语音/TTS/清理） ---------- */

async function finalizePayload(rawPayload = {}, { skipAudio = false, fileID = '', cloudPath = '', keepRemoteFile = false } = {}) {
  const payload = { ...rawPayload };

  if (payload.skeletonUrl) {
    try {
      payload.skeletonUrl = await resolveCloudFileUrl(payload.skeletonUrl);
      if (payload.skeletonUrl && typeof payload.skeletonUrl === 'string') {
        if (payload.skeletonUrl.startsWith('data:image')) {
          payload.skeletonUrl = await base64ToTempFile(payload.skeletonUrl, 'png');
        } else if (!payload.skeletonUrl.startsWith('http') && !payload.skeletonUrl.startsWith('cloud://')) {
          const maybe = payload.skeletonUrl.replace(/\s+/g, '');
          if (/^[a-z0-9+/=_-]+$/i.test(maybe) && maybe.length > 200) {
            payload.skeletonUrl = await base64ToTempFile(maybe, 'png');
          }
        }
      }
    } catch (err) {
      console.warn('[score-upload] skeleton resolve failed', err);
    }
  }

  const ensureAudio = async (candidate) => {
    if (!candidate) return '';
    try {
      return await resolveAudioSource(candidate, { prefix: 'feedback' });
    } catch (err) {
      console.warn('[score-upload] resolve audio failed', err);
      return '';
    }
  };

  let audioCandidate = payload.audioUrl || payload.audio || payload.audio_base64;
  if (!audioCandidate && payload.voice && typeof payload.voice === 'object') {
    audioCandidate = payload.voice.audioUrl || payload.voice.audio || payload.voice.audio_base64;
  }

  if (!audioCandidate && !skipAudio) {
    try {
      audioCandidate = await ttsFallback(payload.advice || payload.summary || '请根据建议微调体式');
    } catch (err) {
      console.warn('[score-upload] TTS fallback failed', err);
    }
  }

  if (audioCandidate) {
    const playable = await ensureAudio(audioCandidate);
    if (playable) {
      payload.audioUrl = playable;
      payload.audio = playable;
      payload.audio_base64 = '';
    }
  }

  if (fileID) payload.sourceFileId = fileID;
  if (cloudPath) payload.cloudPath = cloudPath;

  if (!keepRemoteFile && fileID) {
    setTimeout(() => {
      wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
        console.warn('[score-upload] deleteFile failed', err);
      });
    }, 30_000);
  }

  return payload;
}

/* ---------- 主入口 ---------- */

export async function uploadAndScore(filePath, options = {}) {
  const hasLocalPath = Boolean(filePath);
  const hasBase64 = Boolean(options?.imageBase64);
  const hasProvidedFileId = Boolean(options?.fileID);

  if (!hasLocalPath && !hasBase64 && !hasProvidedFileId) {
    throw new Error('请先选择需要评分的图片');
  }

  const {
    skipAudio = false,
    poseId = '',
    keepRemoteFile = false,
    imageBase64 = '',
    imageExt = '',
    fileSize = 0,
    fileID: providedFileID = '',
    cloudPath: providedCloudPath = '',
    preferGateway = false,
    ...rest
  } = options;

  const ext = (imageExt || (hasLocalPath ? getImageExt(filePath) : '') || 'jpg').toLowerCase();
  let fileID = providedFileID;
  let cloudPath = providedCloudPath;

  try {
    // 1) HTTP 网关：仅在明确提供 base64 或显式要求时触发
    if (imageBase64 || (preferGateway && hasLocalPath)) {
      try {
        const basePayload = imageBase64 || (hasLocalPath ? await readFileAsBase64(filePath) : '');
        if (!basePayload) throw new Error('IMAGE_BASE64_EMPTY');
        const httpRaw = await requestHttpScore(hasLocalPath ? filePath : undefined, {
          skipAudio,
          poseId,
          imageBase64: basePayload,
          imageExt: ext,
          fileSize,
          ...rest
        });
        const httpPayload = normalizeFeedbackPayload(httpRaw);
        console.log('[score-upload] http score payload', httpPayload);
        if (httpPayload && httpPayload.ok) {
          return await finalizePayload(httpPayload, { skipAudio });
        }
        console.warn('[score-upload] http score invalid payload', httpPayload);
      } catch (err) {
        console.warn('[score-upload] http score failed', err);
        if (err?.code === 'PAYLOAD_TOO_LARGE') {
          throw err;
        }
      }
    }

    // 2) 若未提供 fileID，则上传至 COS
    if (!fileID) {
      if (!hasLocalPath) throw new Error('IMAGE_PATH_MISSING');
      cloudPath = providedCloudPath || buildCloudPath(filePath);
      const uploadRes = await wx.cloud.uploadFile({ cloudPath, filePath });
      fileID = uploadRes?.fileID;
      if (!fileID) throw new Error('图片上传失败，请稍后重试');
      console.log('[score-upload] uploaded to cloud', { cloudPath, fileID, fileSize });
    }

    let tempFileUrl = '';
    try {
      const tempRes = await wx.cloud.getTempFileURL({ fileList: [fileID] });
      const candidate = tempRes?.fileList?.[0];
      if (candidate && candidate.tempFileURL) {
        tempFileUrl = candidate.tempFileURL;
        console.log('[score-upload] temp url resolved', { fileID, tempFileUrl: tempFileUrl.slice(0, 60) });
      }
    } catch (tempErr) {
      console.warn('[score-upload] temp url resolve failed', tempErr);
    }

    // 3) 调用云函数（v1 方案）
    const responseData = await call(FN.FEEDBACK, {
      type: 'poseDetect',
      imageKey: fileID,
      imageUrl: tempFileUrl,
      skipAudio,
      poseId,
      ...rest
    });

    let parsed = null;
    if (responseData && typeof responseData.body === 'string') parsed = safeParseJSON(responseData.body, null);
    if (!parsed && typeof responseData === 'string') parsed = safeParseJSON(responseData, null);
    if (!parsed && responseData && typeof responseData.result === 'string') parsed = safeParseJSON(responseData.result, null);
    if (!parsed) parsed = responseData;
    if (parsed && typeof parsed.data === 'string') {
      const nested = safeParseJSON(parsed.data, null);
      if (nested) parsed = { ...parsed, data: nested };
    }

    const payload = normalizeFeedbackPayload(parsed);
    console.log('[score-upload] normalize payload', payload);
    if (!payload.ok) throw new Error(parsed?.message || '评分失败');

    return await finalizePayload(payload, { skipAudio, fileID, cloudPath, keepRemoteFile });
  } catch (error) {
    if (fileID && !keepRemoteFile && !providedFileID) {
      wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
        console.warn('[score-upload] cleanup deleteFile failed', err);
      });
    }
    const errMsg = error?.errMsg || error?.message || '';
    if (!error.code && /413|Payload Too Large|data exceed max size/i.test(errMsg)) {
      error.code = 'PAYLOAD_TOO_LARGE';
    }
    console.warn('[score-upload] 上传或评分失败', error);
    if (error.code === 'PAYLOAD_TOO_LARGE') throw error;
    const message = mapApiErrorToMessage(error);
    throw Object.assign(new Error(message), { cause: error });
  }
}
