import { call } from './api';
import {
  FN,
  normalizeFeedbackPayload,
  resolveCloudFileUrl,
  mapApiErrorToMessage,
  ENDPOINTS,
  expandGatewayVariants
} from './yoga-api';
import { ensurePlayableAudio } from './audio';

async function ttsFallback(text) {
  if (!text) return '';
  const res = await wx.cloud.callFunction({
    name: FN.GUIDE_TTS,
    data: { action: 'tts_feedback', text }
  });
  return res?.result?.audioUrl || '';
}

function buildCloudPath(filePath = '') {
  const extMatch = /\.([a-zA-Z0-9]+)$/.exec(filePath);
  const ext = (extMatch && extMatch[1]) ? extMatch[1] : 'jpg';
  const timestamp = Date.now();
  const random = Math.random().toString(36).slice(2, 8);
  return `pose-uploads/${timestamp}-${random}.${ext}`;
}

function createPayloadTooLargeError(baseError) {
  const error = baseError instanceof Error ? baseError : new Error('PAYLOAD_TOO_LARGE');
  error.code = 'PAYLOAD_TOO_LARGE';
  if (!error.message || error.message === 'Error') {
    error.message = '图片过大';
  }
  return error;
}

async function uploadViaGateway(filePath, formData = {}, { skipAudio = false } = {}) {
  const candidates = expandGatewayVariants(ENDPOINTS.DETECT_POSE_FILE);
  let lastError = null;

  for (const url of candidates) {
    try {
      const res = await wx.uploadFile({
        url,
        name: 'file',
        filePath,
        formData,
        timeout: 20000
      });

      if (res.statusCode === 413) {
        throw createPayloadTooLargeError(new Error('PAYLOAD_TOO_LARGE'));
      }

      const payload = normalizeFeedbackPayload(res.data);
      if (!payload.ok) {
        throw new Error('评分失败');
      }

      if (!payload.audioUrl && !skipAudio) {
        try {
          payload.audioUrl = await ttsFallback(payload.advice || payload.summary || '请根据建议微调体式');
        } catch (err) {
          console.warn('[score-upload] 网关评分音频生成失败', err);
        }
      }

      if (payload.audioUrl || payload.audio) {
        const candidate = payload.audioUrl || payload.audio || payload.audio_base64;
        const playable = await ensurePlayableAudio(candidate, { prefix: 'feedback' });
        if (playable) {
          payload.audioUrl = playable;
          payload.audio = playable;
        }
      }

      return payload;
    } catch (err) {
      lastError = err.statusCode === 413 ? createPayloadTooLargeError(err) : err;
      console.warn('[score-upload] 网关上传失败，尝试下一个地址', url, err);
    }
  }

  throw lastError || new Error('评分失败');
}

export async function uploadAndScore(filePath, options = {}) {
  if (!filePath) {
    throw new Error('请先选择需要评分的图片');
  }

  const {
    skipAudio = false,
    poseId = '',
    keepRemoteFile = false,
    ...rest
  } = options;

  let fileID;
  let cloudPath;

  try {
    cloudPath = buildCloudPath(filePath);
    const uploadRes = await wx.cloud.uploadFile({
      cloudPath,
      filePath
    });

    fileID = uploadRes?.fileID;
    if (!fileID) {
      throw new Error('图片上传失败，请稍后重试');
    }

    const responseData = await call(FN.FEEDBACK, {
      type: 'poseDetect',
      imageKey: fileID,
      skipAudio,
      poseId,
      ...rest
    });

    const payload = normalizeFeedbackPayload(responseData);
    if (!payload.ok) {
      throw new Error(responseData?.message || '评分失败');
    }

    if (payload.skeletonUrl) {
      payload.skeletonUrl = await resolveCloudFileUrl(payload.skeletonUrl);
    }

    if (payload.audioUrl) {
      payload.audioUrl = await resolveCloudFileUrl(payload.audioUrl);
    } else if (!skipAudio) {
      try {
        payload.audioUrl = await ttsFallback(payload.advice || payload.summary || '请根据建议微调体式');
      } catch (err) {
        console.warn('[score-upload] TTS fallback failed', err);
      }
    }

    if (payload.audioUrl || payload.audio) {
      const candidate = payload.audioUrl || payload.audio || payload.audio_base64;
      const playable = await ensurePlayableAudio(candidate, { prefix: 'feedback' });
      if (playable) {
        payload.audioUrl = playable;
        payload.audio = playable;
      }
    }

    payload.sourceFileId = fileID;
    payload.cloudPath = cloudPath;

    if (!keepRemoteFile) {
      setTimeout(() => {
        wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
          console.warn('[score-upload] deleteFile failed', err);
        });
      }, 30_000);
    }

    return payload; // { ok, score, advice, summary?, skeletonUrl?, audioUrl? }
  } catch (error) {
    if (fileID && !keepRemoteFile) {
      wx.cloud.deleteFile({ fileList: [fileID] }).catch(err => {
        console.warn('[score-upload] cleanup deleteFile failed', err);
      });
    }
    console.warn('[score-upload] 云函数通道失败，尝试走网关', error);
    try {
      const gatewayPayload = await uploadViaGateway(filePath, {
        skipAudio,
        poseId,
        ...rest
      }, { skipAudio });
      return gatewayPayload;
    } catch (gatewayError) {
      if (gatewayError.code === 'PAYLOAD_TOO_LARGE') {
        throw gatewayError;
      }
      const message = mapApiErrorToMessage(gatewayError);
      const wrappedError = new Error(message);
      wrappedError.cause = gatewayError;
      throw wrappedError;
    }
  }
}
