const fs = wx.getFileSystemManager();
const DATA_URI_REGEX = /^data:audio\/(?:[a-z0-9.+-]+);base64,/i;
const BASE64_REGEX = /^[A-Za-z0-9+/=\s]+$/;

function createTempFilePath(prefix = 'audio', ext = 'mp3') {
  const random = Math.random().toString(36).slice(2);
  return `${wx.env.USER_DATA_PATH}/${prefix}-${Date.now()}-${random}.${ext}`;
}

function stripDataUri(dataUri = '') {
  if (DATA_URI_REGEX.test(dataUri)) {
    return dataUri.replace(DATA_URI_REGEX, '');
  }
  return dataUri;
}

export function isBase64Audio(input) {
  if (!input || typeof input !== 'string') return false;
  if (DATA_URI_REGEX.test(input)) return true;
  if (input.startsWith('http://') || input.startsWith('https://') || input.startsWith('cloud://')) {
    return false;
  }
  return BASE64_REGEX.test(input) && input.length > 100;
}

export function saveBase64Audio(base64, { prefix = 'audio', ext = 'mp3' } = {}) {
  const pure = stripDataUri(base64);
  return new Promise((resolve, reject) => {
    const filePath = createTempFilePath(prefix, ext);
    fs.writeFile({
      filePath,
      data: pure,
      encoding: 'base64',
      success: () => resolve(filePath),
      fail: reject
    });
  });
}

export async function ensurePlayableAudio(source, options = {}) {
  if (!source) return '';
  if (!isBase64Audio(source)) {
    return source;
  }
  try {
    return await saveBase64Audio(source, options);
  } catch (error) {
    console.warn('[audio] Failed to save base64 audio', error);
    return '';
  }
}

export default {
  ensurePlayableAudio,
  saveBase64Audio,
  isBase64Audio
};
