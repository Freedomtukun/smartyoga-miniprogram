import { base64ToTempFile } from './upload';

const DATA_URI_REGEX = /^data:audio\/(?:[a-z0-9.+-]+);base64,/i;
const BASE64_REGEX = /^[A-Za-z0-9+/=_-\s]+$/;

export function isBase64Audio(input) {
  if (!input || typeof input !== 'string') return false;
  if (DATA_URI_REGEX.test(input)) return true;
  if (input.startsWith('http://') || input.startsWith('https://') || input.startsWith('cloud://')) {
    return false;
  }
  return BASE64_REGEX.test(input) && input.replace(/\s+/g, '').length > 100;
}

export async function ensurePlayableAudio(source, { prefix = 'audio', ext = 'mp3' } = {}) {
  if (!source) return '';
  if (!isBase64Audio(source)) {
    return source;
  }
  try {
    return await base64ToTempFile(source, ext || 'mp3');
  } catch (error) {
    console.warn('[audio] Failed to convert base64 audio', error);
    return '';
  }
}

export default {
  ensurePlayableAudio,
  isBase64Audio
};
