// utils/pose-normalizer.js
// 姿势检测响应归一化处理

/**
 * 归一化姿势检测响应
 * @param {Object} raw - 原始响应数据
 * @returns {Object} 归一化后的数据
 */
export function normalizePoseResponse(raw) {
    // 判断是新版还是旧版响应格式
    const isNew = typeof raw?.code === 'number';
    const data = isNew ? (raw.data || {}) : raw || {};
    
    // 提取骨架图URL（兼容多种字段名）
    const skeletonUrl = data.skeletonImageUrl || 
                        data.skeletonUrl || 
                        data.skeleton_url || 
                        '';
    
    // 提取建议文本（兼容多种字段名）
    const advice = data.advice || 
                   data.suggestions || 
                   data.recommendation || 
                   '';
    
    // 提取关键点数据
    const keypoints = Array.isArray(data.keypoints) ? data.keypoints : 
                      Array.isArray(data.key_points) ? data.key_points : 
                      [];
    
    // 提取标签数据
    const labels = Array.isArray(data.labels) ? data.labels :
                   Array.isArray(data.tags) ? data.tags :
                   [];
    
    return {
      ok: isNew ? raw.code === 200 : raw.code === 'OK',
      poseName: data.poseName || data.poseNameZh || data.pose_name || '',
      poseNameEn: data.poseNameEn || data.pose_name_en || '',
      score: Number(data.score || data.confidence || 0),
      advice: String(advice || '').trim(),
      skeletonUrl,
      keypoints,
      labels,
      // 额外的原始数据保留
      raw: data
    };
  }
  
  /**
   * 格式化关键点数据
   * @param {Array} keypoints - 原始关键点数组
   * @returns {Object} 格式化后的关键点映射
   */
  export function formatKeypoints(keypoints) {
    const formatted = {};
    
    keypoints.forEach(kp => {
      if (kp?.name) {
        formatted[kp.name] = {
          x: kp.x || 0,
          y: kp.y || 0,
          score: kp.score || kp.confidence || 0,
          visible: kp.score > 0.3
        };
      }
    });
    
    return formatted;
  }
  
  /**
   * 计算姿势相似度（简单版本）
   * @param {Array} keypoints1 - 第一组关键点
   * @param {Array} keypoints2 - 第二组关键点
   * @returns {number} 相似度分数 (0-100)
   */
  export function calculateSimilarity(keypoints1, keypoints2) {
    if (!keypoints1?.length || !keypoints2?.length) {
      return 0;
    }
    
    const kp1Map = formatKeypoints(keypoints1);
    const kp2Map = formatKeypoints(keypoints2);
    
    let totalDistance = 0;
    let validPoints = 0;
    
    Object.keys(kp1Map).forEach(name => {
      if (kp2Map[name] && kp1Map[name].visible && kp2Map[name].visible) {
        const dx = kp1Map[name].x - kp2Map[name].x;
        const dy = kp1Map[name].y - kp2Map[name].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        totalDistance += distance;
        validPoints++;
      }
    });
    
    if (validPoints === 0) return 0;
    
    // 归一化距离到0-100分数
    const avgDistance = totalDistance / validPoints;
    const maxDistance = Math.sqrt(640 * 640 + 640 * 640); // 假设图像尺寸640x640
    const similarity = Math.max(0, 100 - (avgDistance / maxDistance) * 100);
    
    return Math.round(similarity);
  }
  
  /**
   * 生成评分等级
   * @param {number} score - 分数
   * @returns {Object} 等级信息
   */
  export function getScoreLevel(score) {
    if (score >= 90) {
      return {
        level: 'S',
        text: '完美',
        color: '#52c41a',
        stars: 5
      };
    } else if (score >= 80) {
      return {
        level: 'A',
        text: '优秀',
        color: '#1890ff',
        stars: 4
      };
    } else if (score >= 70) {
      return {
        level: 'B',
        text: '良好',
        color: '#faad14',
        stars: 3
      };
    } else if (score >= 60) {
      return {
        level: 'C',
        text: '及格',
        color: '#fa8c16',
        stars: 2
      };
    } else {
      return {
        level: 'D',
        text: '需要改进',
        color: '#f5222d',
        stars: 1
      };
    }
  }