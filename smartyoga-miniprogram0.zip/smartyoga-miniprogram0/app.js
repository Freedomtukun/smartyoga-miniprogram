// app.js
App({
  onLaunch() {
    if (!wx.cloud) {
      console.error('请使用包含云能力的基础库版本');
    } else {
      wx.cloud.init({
        env: 'smartyoga-3gh3muyt510ddd2d',
        traceUser: true,
      });
      console.log('Cloud Env Initialized with ID: smartyoga-3gh3muyt510ddd2d');
    }

    try {
      wx.setInnerAudioOption({ obeyMuteSwitch: false, speakerOn: true });
    } catch (err) {
      console.warn('[app] setInnerAudioOption failed', err);
    }
  },
  globalData: {}
});
