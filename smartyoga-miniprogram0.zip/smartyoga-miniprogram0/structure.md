.
|-- advanced.json
|-- app.js
|-- app.json
|-- app.wxss
|-- assets
|   |-- \ poses
|   |-- images
|   |-- images.js
|   |-- meditation_sessions.js
|   `-- poses.js
|-- beginner.json
|-- calls.txt
|-- components
|   |-- \ RecommendCard
|   `-- PoseScore
|-- intermediate.json
|-- package.json
|-- pages
|   |-- index
|   |-- invite
|   |-- meditation
|   |-- nearby
|   |-- photo-detect
|   |-- result
|   `-- sequence
|-- project.config.json
|-- project.private.config.json
|-- sitemap.json
|-- structure.md
`-- utils
    |-- api.js
    |-- cloud-sequence-service.js
    |-- config
    |-- guide.js
    |-- map-recommend.js
    |-- meditation.js
    |-- poi.js
    |-- pose-normalizer.js
    |-- retry.js
    |-- score-upload.js
    |-- sequence-service.js
    |-- services.js
    |-- tts-player.js
    |-- upload-manager.js
    `-- yoga-api.js

17 directories, 29 files
