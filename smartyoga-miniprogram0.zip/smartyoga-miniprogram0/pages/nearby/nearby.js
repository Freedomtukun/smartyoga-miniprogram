import { fetchNearbyPOIs } from '../../utils/map-recommend';

Page({
  data: {
    items: [],
    loading: false,
    error: '',
    tips: [
      '开启定位权限后可推荐附近的瑜伽馆、健身房与康养空间',
      '可点击卡片查看详细位置并一键导航前往',
      '体验结束后欢迎收藏或分享喜欢的场馆'
    ]
  },

  async locate() {
    if (this.data.loading) return;
    try {
      this.setData({ loading: true, error: '' });
      const pois = await fetchNearbyPOIs({
        bizType: 'yoga',
        radius: 3000,
        userIntent: '附近推荐',
        enableReasons: true
      });
      const poiList = Array.isArray(pois) ? pois : [];
      const meta = poiList.meta || {};

      if (meta.reason === 'OUT_OF_COVERAGE') {
        wx.showToast({ title: '当前区域暂不支持精准定位，已显示默认推荐', icon: 'none' });
      } else if (!poiList.length) {
        wx.showToast({ title: '暂无更多推荐', icon: 'none' });
      }

      this.setData({ items: poiList });
    } catch (err) {
      console.error('[nearby] locate failed', err);
      const msg = err?.errMsg?.includes('auth deny') ? '请允许定位权限' : '定位或获取失败';
      this.setData({ error: msg });
      wx.showToast({ title: msg, icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  openMap(e) {
    const index = Number(e.currentTarget.dataset.index);
    const item = this.data.items?.[index];
    if (!item || item.latitude == null || item.longitude == null) {
      wx.showToast({ title: '暂无位置信息', icon: 'none' });
      return;
    }
    wx.openLocation({
      latitude: Number(item.latitude),
      longitude: Number(item.longitude),
      name: item.name || '推荐场馆',
      address: item.address || ''
    });
  }
});
