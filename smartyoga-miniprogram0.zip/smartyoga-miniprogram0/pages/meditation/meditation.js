import { fetchMeditation } from '../../utils/meditation.js';

const THEMES = [
  { id: 'breath', name: '呼吸放松', desc: '平稳呼吸，释放身体紧张' },
  { id: 'focus', name: '专注觉察', desc: '收回注意力，提升专注力' },
  { id: 'sleep', name: '睡前松弛', desc: '温柔引导，帮助安眠' },
  { id: 'gratitude', name: '感恩冥想', desc: '培养积极心态，拥抱当下' }
];

const DURATIONS = [
  { seconds: 300, label: '5 分钟' },
  { seconds: 600, label: '10 分钟' },
  { seconds: 900, label: '15 分钟' }
];

let audioCtx;

Page({
  data: {
    themes: THEMES,
    themeIndex: 0,
    durations: DURATIONS,
    durationIndex: 0,
    text: '',
    audio: '',
    loading: false,
    playing: false
  },

  onUnload() {
    this.destroyAudio();
  },

  selectTheme(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (!Number.isNaN(index)) {
      this.setData({ themeIndex: index });
    }
  },

  selectDuration(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (!Number.isNaN(index)) {
      this.setData({ durationIndex: index });
    }
  },

  async generate() {
    if (this.data.loading) return;
    this.stopAudio();
    const theme = this.data.themes[this.data.themeIndex] || THEMES[0];
    const duration = this.data.durations[this.data.durationIndex] || DURATIONS[0];
    this.setData({ loading: true });
    try {
      const result = await fetchMeditation({ theme: theme.id, duration: duration.seconds });
      const text = result.text || '';
      const audio = result.audioUrl || '';
      this.setData({ text, audio, playing: false });
      if (audio) {
        this.ensureAudioCtx();
        audioCtx.src = audio;
        audioCtx.play();
      } else {
        wx.showToast({ title: '已生成文字引导', icon: 'success' });
      }
    } catch (err) {
      console.error('[meditation] fetch failed', err);
      wx.showToast({ title: '生成失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  toggleAudio() {
    if (!this.data.audio) {
      wx.showToast({ title: '暂无音频', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audio) {
        audioCtx.src = this.data.audio;
      }
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[meditation] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  stopAudio() {
    if (!audioCtx) return;
    audioCtx.stop();
    this.setData({ playing: false });
  },

  destroyAudio() {
    if (audioCtx) {
      audioCtx.stop();
      audioCtx.destroy?.();
      audioCtx = null;
    }
  }
});
