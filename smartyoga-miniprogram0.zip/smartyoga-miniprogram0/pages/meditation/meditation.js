import { fetchMeditation } from '../../utils/meditation.js';

const CACHE_PREFIX = 'meditation_cache_v1';
const CACHE_TTL = 15 * 60 * 1000; // 15 分钟

function buildCacheKey(themeId, durationSeconds) {
  return `${CACHE_PREFIX}_${themeId}_${durationSeconds}`;
}

const THEMES = [
  { id: 'breath', name: '呼吸放松', desc: '平稳呼吸，释放身体紧张' },
  { id: 'focus', name: '专注觉察', desc: '收回注意力，提升专注力' },
  { id: 'sleep', name: '睡前松弛', desc: '温柔引导，帮助安眠' },
  { id: 'gratitude', name: '感恩冥想', desc: '培养积极心态，拥抱当下' }
];

const DURATIONS = [
  { seconds: 300, label: '5 分钟' },
  { seconds: 600, label: '10 分钟' },
  { seconds: 900, label: '15 分钟' }
];

let audioCtx;

Page({
  data: {
    themes: THEMES,
    themeIndex: 0,
    durations: DURATIONS,
    durationIndex: 0,
    text: '',
    audio: '',
    loading: false,
    playing: false,
    usingCache: false
  },

  onUnload() {
    this.destroyAudio();
  },

  selectTheme(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (!Number.isNaN(index)) {
      this.setData({ themeIndex: index });
    }
  },

  selectDuration(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (!Number.isNaN(index)) {
      this.setData({ durationIndex: index });
    }
  },

  async generate() {
    if (this.data.loading) return;
    if (!this._requestSeq) {
      this._requestSeq = 0;
    }
    const requestId = ++this._requestSeq;
    this._activeRequestId = requestId;
    this.stopAudio();
    const theme = this.data.themes[this.data.themeIndex] || THEMES[0];
    const duration = this.data.durations[this.data.durationIndex] || DURATIONS[0];
    const cacheKey = buildCacheKey(theme.id, duration.seconds);
    let cached = null;
    try {
      const stored = wx.getStorageSync(cacheKey);
      if (stored && stored.text && (!stored.timestamp || Date.now() - stored.timestamp < CACHE_TTL)) {
        cached = stored;
      }
    } catch (err) {
      console.warn('[meditation-page] read cache failed', err);
    }

    if (cached && requestId === this._activeRequestId) {
      this.setData({
        text: cached.text,
        audio: cached.audioUrl || '',
        playing: false,
        usingCache: true
      });
    }

    this.setData({ loading: true });
    try {
      const result = await fetchMeditation({ theme: theme.id, duration: duration.seconds, voice: 'gentle_female' });
      if (requestId !== this._activeRequestId) {
        return; // 被新的请求覆盖
      }
      const text = (result?.text || '').trim();
      const audio = (result?.audioUrl || '').trim();
      this.setData({ text, audio, playing: false, usingCache: false });
      if (text) {
        console.log('[meditation-page] text length', text.length);
      }
      if (audio) {
        this.ensureAudioCtx();
        try {
          audioCtx.src = audio;
          audioCtx.play();
        } catch (err) {
          console.warn('[meditation-page] audio play error, fallback toast', err);
          wx.showToast({ title: '音频播放失败', icon: 'none' });
        }
      } else {
        const message = text ? '已生成文字引导' : '暂无内容，请稍后重试';
        wx.showToast({ title: message, icon: text ? 'success' : 'none' });
      }

      if (text) {
        try {
          wx.setStorage({
            key: cacheKey,
            data: { text, audioUrl: audio || '', timestamp: Date.now() }
          });
        } catch (err) {
          console.warn('[meditation-page] set cache failed', err);
        }
      }
    } catch (err) {
      if (requestId !== this._activeRequestId) {
        return;
      }
      console.error('[meditation] fetch failed', err);
      if (cached && cached.text) {
        wx.showToast({ title: '网络慢，已展示缓存内容', icon: 'none' });
      } else {
        wx.showToast({ title: '生成失败，请检查网络', icon: 'none' });
      }
    } finally {
      if (requestId === this._activeRequestId) {
        this.setData({ loading: false });
      }
    }
  },

  toggleAudio() {
    if (!this.data.audio) {
      wx.showToast({ title: '暂无音频', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audio) {
        audioCtx.src = this.data.audio;
      }
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.autoplay = false;
    audioCtx.obeyMuteSwitch = false;
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[meditation] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  stopAudio() {
    if (!audioCtx) return;
    audioCtx.stop();
    this.setData({ playing: false });
  },

  destroyAudio() {
    if (audioCtx) {
      audioCtx.stop();
      audioCtx.destroy?.();
      audioCtx = null;
    }
  }
});
