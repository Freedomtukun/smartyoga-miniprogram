import { GUIDEPLUS_GROUPS, fetchGuideplusSuggest } from '../../utils/guideplus';

const CACHE_PREFIX = 'guideplus_cache_v1';
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 小时

let audioCtx;

function buildCacheKey({ groupType, topic, lang, tts }) {
  return `${CACHE_PREFIX}_${groupType}_${topic}_${lang}_${tts ? '1' : '0'}`;
}

function readCache(key) {
  try {
    const stored = wx.getStorageSync(key);
    if (!stored || typeof stored !== 'object') return null;
    if (stored.timestamp && Date.now() - stored.timestamp > CACHE_TTL) return null;
    return stored.payload || null;
  } catch (err) {
    console.warn('[guideplus] read cache failed', err);
    return null;
  }
}

function writeCache(key, payload) {
  try {
    wx.setStorageSync(key, { timestamp: Date.now(), payload });
  } catch (err) {
    console.warn('[guideplus] set cache failed', err);
  }
}

function sanitizeAdvice(list = []) {
  return list
    .map((item) => {
      if (item == null) return '';
      if (typeof item === 'string') return item.trim();
      return String(item).trim();
    })
    .filter(Boolean);
}

function normalizePoses(list = []) {
  return list
    .map((pose, index) => {
      if (!pose || typeof pose !== 'object') return null;
      const name = typeof pose.name === 'string'
        ? { zh: pose.name, en: pose.name }
        : (pose.name || {});
      const reason = typeof pose.reason === 'string'
        ? { zh: pose.reason, en: pose.reason }
        : (pose.reason || {});
      const displayName = name.zh || name.en || pose.poseId || pose.id || `推荐体式${index + 1}`;
      const reasonText = reason.zh || reason.en || '';
      return {
        ...pose,
        poseId: pose.poseId || pose.id || '',
        name,
        reason,
        displayName,
        reasonText,
        tags: Array.isArray(pose.tags) ? pose.tags : []
      };
    })
    .filter(Boolean);
}

function defaultState() {
  const defaultGroup = GUIDEPLUS_GROUPS[0];
  const defaultTopic = defaultGroup.topics[0];
  return {
    groups: GUIDEPLUS_GROUPS,
    groupIndex: 0,
    topics: defaultGroup.topics,
    topicIndex: 0,
    currentGroup: defaultGroup,
    currentTopic: defaultTopic,
    langLabel: '中文',
    ttsEnabled: true,
    loading: false,
    playing: false,
    usingCache: false,
    summary: '',
    advice: [],
    oneline: '',
    audioUrl: '',
    audioReady: false,
    recommendedPoses: [],
    metadata: null,
    lastUpdated: null,
    requestError: ''
  };
}

Page({
  data: defaultState(),

  onLoad() {
    wx.setNavigationBarTitle({ title: 'Guide+ 科普建议' });
  },

  onHide() {
    this.stopAudio();
  },

  onUnload() {
    this.destroyAudio();
  },

  selectGroup(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isNaN(index) || index === this.data.groupIndex) return;
    const group = this.data.groups[index] || this.data.groups[0];
    const topics = group.topics || [];
    const topic = topics[0] || this.data.currentTopic;
    this.resetResult();
    this.setData({
      groupIndex: index,
      topics,
      topicIndex: 0,
      currentGroup: group,
      currentTopic: topic
    });
  },

  selectTopic(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isNaN(index) || index === this.data.topicIndex) return;
    const topic = this.data.topics[index] || this.data.currentTopic;
    this.resetResult();
    this.setData({
      topicIndex: index,
      currentTopic: topic
    });
  },

  onToggleTts(event) {
    this.setData({ ttsEnabled: Boolean(event.detail?.value) });
  },

  async onGenerate() {
    if (this.data.loading) return;

    const group = this.data.currentGroup || this.data.groups[0];
    const topic = this.data.currentTopic || group.topics[0];
    const lang = 'zh';
    const params = {
      groupType: group.id,
      topic: topic.id,
      lang,
      tts: this.data.ttsEnabled
    };

    if (!this._requestSeq) {
      this._requestSeq = 0;
    }
    const requestId = ++this._requestSeq;
    this._activeRequestId = requestId;

    const cacheKey = buildCacheKey(params);
    const cached = readCache(cacheKey);
    if (cached) {
      this.applyResult(cached, true);
    } else {
      this.resetResult();
    }

    this.setData({ loading: true, requestError: '' });

    try {
      const result = await fetchGuideplusSuggest(params);
      if (requestId !== this._activeRequestId) return;
      const payload = {
        ...result,
        groupType: group.id,
        topic: topic.id,
        lang
      };
      this.applyResult(payload, false);
      writeCache(cacheKey, payload);
    } catch (err) {
      if (requestId !== this._activeRequestId) return;
      console.error('[guideplus] fetch failed', err);
      const message = err?.message || '生成失败，请稍后重试';
      if (!cached) {
        wx.showToast({ title: '生成失败，请稍后重试', icon: 'none' });
      } else {
        wx.showToast({ title: '网络慢，已展示缓存内容', icon: 'none' });
      }
      this.setData({ requestError: message });
    } finally {
      if (requestId === this._activeRequestId) {
        this.setData({ loading: false });
      }
    }
  },

  applyResult(result, fromCache = false) {
    this.stopAudio();
    const advice = sanitizeAdvice(result?.advice);
    const recommendedPoses = normalizePoses(result?.recommendedPoses);
    this.setData({
      summary: result?.summary || '',
      advice,
      oneline: result?.oneline || '',
      audioUrl: result?.audioUrl || '',
      audioReady: Boolean(result?.audioUrl),
      recommendedPoses,
      metadata: result?.metadata || null,
      playing: false,
      usingCache: fromCache,
      lastUpdated: Date.now(),
      requestError: ''
    });
  },

  resetResult() {
    this.stopAudio();
    this.setData({
      summary: '',
      advice: [],
      oneline: '',
      audioUrl: '',
      audioReady: false,
      recommendedPoses: [],
      metadata: null,
      playing: false,
      usingCache: false,
      requestError: ''
    });
  },

  toggleAudio() {
    if (!this.data.audioReady) {
      wx.showToast({ title: '暂无语音内容', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audioUrl) {
        audioCtx.stop();
        audioCtx.src = this.data.audioUrl;
      }
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.autoplay = false;
    audioCtx.obeyMuteSwitch = false;
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[guideplus] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  stopAudio() {
    if (!audioCtx) return;
    try {
      audioCtx.stop();
    } catch (err) {
      console.warn('[guideplus] stop audio failed', err);
    }
    this.setData({ playing: false });
  },

  destroyAudio() {
    if (!audioCtx) return;
    try {
      audioCtx.stop();
      audioCtx.destroy?.();
    } catch (err) {
      console.warn('[guideplus] destroy audio failed', err);
    }
    audioCtx = null;
  },

  handlePoseTap(event) {
    const pose = event.currentTarget.dataset.pose || {};
    const poseId = pose.poseId || pose.id || '';
    const poseName = pose.displayName || pose.name?.zh || pose.name?.en || '';
    const params = [];
    if (poseId) params.push(`poseId=${encodeURIComponent(poseId)}`);
    if (poseName) params.push(`poseName=${encodeURIComponent(poseName)}`);
    const url = params.length ? `/pages/sequence/sequence?${params.join('&')}` : '/pages/sequence/sequence';
    wx.navigateTo({ url });
  },

  handleSequenceTap() {
    wx.navigateTo({ url: '/pages/sequence/sequence' });
  },

  handleScoreTap() {
    wx.navigateTo({ url: '/pages/photo-detect/photo-detect' });
  },

  handleNearbyTap() {
    wx.navigateTo({ url: '/pages/nearby/nearby' });
  }
});
