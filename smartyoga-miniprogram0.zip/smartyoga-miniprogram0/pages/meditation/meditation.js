import { GUIDEPLUS_GROUPS, fetchGuideplusSuggest } from '../../utils/guideplus';

const CACHE_PREFIX = 'guideplus_cache_v2';
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 小时

let audioCtx;

function buildCacheKey({ groupType, topic, lang, tts }) {
  return `${CACHE_PREFIX}_${groupType}_${topic}_${lang}_${tts ? '1' : '0'}`;
}

function readCache(key) {
  try {
    const stored = wx.getStorageSync(key);
    if (!stored || typeof stored !== 'object') return null;
    if (stored.timestamp && Date.now() - stored.timestamp > CACHE_TTL) return null;
    return stored.payload || null;
  } catch (err) {
    console.warn('[guideplus] read cache failed', err);
    return null;
  }
}

function writeCache(key, payload) {
  try {
    wx.setStorageSync(key, { timestamp: Date.now(), payload });
  } catch (err) {
    console.warn('[guideplus] set cache failed', err);
  }
}

function mergeMetadata(baseMeta, incomingMeta) {
  if (!baseMeta) return incomingMeta || null;
  if (!incomingMeta) return baseMeta;
  return { ...baseMeta, ...incomingMeta };
}

function friendlyErrorMessage(err, fallback) {
  if (!err) return fallback || '生成失败，请稍后重试';
  const statusCode = typeof err.statusCode === 'number' ? err.statusCode : null;
  if (statusCode && statusCode >= 500) {
    return '服务繁忙，稍后再试';
  }

  const rawMessage = err.errMsg || err.message || '';
  if (typeof rawMessage === 'string') {
    const msg = rawMessage.toLowerCase();
    if (msg.includes('timeout')) {
      return '网络较慢，请稍后再试';
    }
    if (msg.includes('abort')) {
      return '请求已取消';
    }
    if (msg.includes('fail system error')) {
      return '服务暂时不可用，请稍后再试';
    }
  }

  return fallback || '生成失败，请稍后重试';
}

function sanitizeAdvice(list = []) {
  return list
    .map((item) => {
      if (item == null) return '';
      if (typeof item === 'string') return item.trim();
      return String(item).trim();
    })
    .filter(Boolean);
}

function normalizePoses(list = []) {
  return list
    .map((pose, index) => {
      if (!pose || typeof pose !== 'object') return null;
      const name = typeof pose.name === 'string'
        ? { zh: pose.name, en: pose.name }
        : (pose.name || {});
      const reason = typeof pose.reason === 'string'
        ? { zh: pose.reason, en: pose.reason }
        : (pose.reason || {});
      const displayName = name.zh || name.en || pose.poseId || pose.id || `推荐体式${index + 1}`;
      const reasonText = reason.zh || reason.en || '';
      return {
        ...pose,
        poseId: pose.poseId || pose.id || '',
        name,
        reason,
        displayName,
        reasonText,
        tags: Array.isArray(pose.tags) ? pose.tags : []
      };
    })
    .filter(Boolean);
}

function defaultState() {
  const defaultGroup = GUIDEPLUS_GROUPS[0];
  const defaultTopic = defaultGroup.topics[0];
  return {
    groups: GUIDEPLUS_GROUPS,
    groupIndex: 0,
    topics: defaultGroup.topics,
    topicIndex: 0,
    currentGroup: defaultGroup,
    currentTopic: defaultTopic,
    langLabel: '中文',
    ttsEnabled: true,
    loading: false,
    playing: false,
    usingCache: false,
    summary: '',
    advice: [],
    oneline: '',
    audioUrl: '',
    audioReady: false,
    audioLoading: false,
    recommendedPoses: [],
    metadata: null,
    lastUpdated: null,
    requestError: '',
    statusHint: ''
  };
}

Page({
  data: defaultState(),

  onLoad() {
    wx.setNavigationBarTitle({ title: 'Guide+ 科普建议' });
  },

  onHide() {
    this.stopAudio();
  },

  onUnload() {
    this.destroyAudio();
  },

  selectGroup(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isNaN(index) || index === this.data.groupIndex) return;
    const group = this.data.groups[index] || this.data.groups[0];
    const topics = group.topics || [];
    const topic = topics[0] || this.data.currentTopic;
    this.resetResult();
    this.setData({
      groupIndex: index,
      topics,
      topicIndex: 0,
      currentGroup: group,
      currentTopic: topic
    });
  },

  selectTopic(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isNaN(index) || index === this.data.topicIndex) return;
    const topic = this.data.topics[index] || this.data.currentTopic;
    this.resetResult();
    this.setData({
      topicIndex: index,
      currentTopic: topic
    });
  },

  onToggleTts(event) {
    const enabled = Boolean(event.detail?.value);
    if (enabled === this.data.ttsEnabled) return;
    this.setData({ ttsEnabled: enabled });

    if (!enabled) {
      this.stopAudio();
      this.setData({ audioUrl: '', audioReady: false, audioLoading: false, statusHint: '' });
      return;
    }

    if (!this.data.summary) return;

    const group = this.data.currentGroup || this.data.groups[0];
    const topic = this.data.currentTopic || group.topics[0];
    const lang = 'zh';
    const params = {
      groupType: group.id,
      topic: topic.id,
      lang,
      tts: true
    };
    const cacheKey = buildCacheKey(params);
    const cachedAudio = readCache(cacheKey);
    if (cachedAudio && cachedAudio.audioUrl) {
      this.applyAudioResult(cachedAudio, true);
    } else {
      this.loadAudio({ params, cacheKey, requestId: this._activeRequestId || 0, force: true });
    }
  },

  async onGenerate() {
    if (this.data.loading) return;

    const group = this.data.currentGroup || this.data.groups[0];
    const topic = this.data.currentTopic || group.topics[0];
    const lang = 'zh';

    const textParams = {
      groupType: group.id,
      topic: topic.id,
      lang,
      tts: false
    };
    const audioParams = { ...textParams, tts: true };

    const textCacheKey = buildCacheKey(textParams);
    const audioCacheKey = buildCacheKey(audioParams);

    const cachedText = readCache(textCacheKey);
    const cachedAudio = this.data.ttsEnabled ? readCache(audioCacheKey) : null;

    if (cachedText) {
      this.applyTextResult(cachedText, { fromCache: true, preserveAudio: Boolean(cachedAudio && cachedAudio.audioUrl && !cachedText.audioUrl) });
    } else {
      this.resetResult();
    }

    if (this.data.ttsEnabled) {
      if (cachedAudio && cachedAudio.audioUrl) {
        this.applyAudioResult(cachedAudio, true);
      } else {
        this.clearAudio();
      }
    } else {
      this.clearAudio();
    }

    this.setData({ loading: true, requestError: '', statusHint: '' });

    const requestId = (this._activeRequestId || 0) + 1;
    this._activeRequestId = requestId;

    try {
      const result = await fetchGuideplusSuggest(textParams, { retries: 1 });
      if (requestId !== this._activeRequestId) return;
      const payload = {
        ...result,
        groupType: group.id,
        topic: topic.id,
        lang
      };
      this.applyTextResult(payload, { preserveAudio: Boolean(this.data.audioReady) && !payload.audioUrl });
      writeCache(textCacheKey, payload);

      if (this.data.ttsEnabled) {
        this.loadAudio({ params: audioParams, cacheKey: audioCacheKey, requestId, force: true });
      }
    } catch (err) {
      if (requestId !== this._activeRequestId) return;
      console.error('[guideplus] fetch failed', err);
      const useCache = Boolean(cachedText);
      const message = friendlyErrorMessage(err, useCache ? '网络较慢，已展示缓存内容' : '生成失败，请稍后再试');
      if (!useCache) {
        wx.showToast({ title: message, icon: 'none' });
      } else {
        wx.showToast({ title: '网络较慢，已展示缓存内容', icon: 'none' });
      }
      this.setData({ requestError: message, statusHint: message, usingCache: useCache });
    } finally {
      if (requestId === this._activeRequestId) {
        this.setData({ loading: false });
      }
    }
  },

  applyTextResult(result, { fromCache = false, preserveAudio = false } = {}) {
    this.stopAudio();
    const advice = sanitizeAdvice(result?.advice);
    const recommendedPoses = normalizePoses(result?.recommendedPoses);
    const nextState = {
      summary: result?.summary || '',
      advice,
      oneline: result?.oneline || '',
      recommendedPoses,
      metadata: result?.metadata || null,
      playing: false,
      usingCache: fromCache,
      lastUpdated: Date.now(),
      requestError: '',
      statusHint: ''
    };

    if (!preserveAudio || result?.audioUrl) {
      nextState.audioUrl = result?.audioUrl || '';
      nextState.audioReady = Boolean(result?.audioUrl);
    } else {
      nextState.audioUrl = this.data.audioUrl;
      nextState.audioReady = this.data.audioReady;
    }

    this.setData(nextState);
  },

  applyAudioResult(result, fromCache = false) {
    const audioUrl = result?.audioUrl || '';
    const metadata = mergeMetadata(this.data.metadata, result?.metadata || {});
    const updates = {
      metadata,
      audioLoading: false,
      playing: false
    };

    if (audioUrl) {
      updates.audioUrl = audioUrl;
      updates.audioReady = true;
      updates.statusHint = fromCache ? this.data.statusHint : '';
    } else if (!fromCache) {
      updates.audioUrl = '';
      updates.audioReady = false;
    }

    this.setData(updates);
  },

  clearAudio() {
    this.stopAudio();
    this.setData({ audioUrl: '', audioReady: false, audioLoading: false, playing: false });
  },

  async loadAudio({ params, cacheKey, requestId, force = false }) {
    if (!this.data.ttsEnabled) return;

    const cachedAudio = readCache(cacheKey);
    const hasCachedAudio = cachedAudio && cachedAudio.audioUrl;
    if (hasCachedAudio) {
      this.applyAudioResult(cachedAudio, true);
      if (!force) {
        return;
      }
    }

    const audioRequestId = `${requestId}_${Date.now()}`;
    this._audioRequestId = audioRequestId;
    this.setData({ audioLoading: true, statusHint: '' });

    try {
      const result = await fetchGuideplusSuggest(params, { retries: 1 });
      if (requestId !== this._activeRequestId || this._audioRequestId !== audioRequestId) return;
      const payload = {
        ...result,
        groupType: params.groupType,
        topic: params.topic,
        lang: params.lang
      };
      this.applyAudioResult(payload, false);
      writeCache(cacheKey, payload);
    } catch (err) {
      if (requestId !== this._activeRequestId || this._audioRequestId !== audioRequestId) return;
      console.error('[guideplus] audio error', err);
      const message = friendlyErrorMessage(err, '语音生成失败，可稍后再试');
      this.setData({ audioLoading: false, statusHint: message });
      if (!this.data.audioReady) {
        wx.showToast({ title: message, icon: 'none' });
      }
    }
  },

  resetResult() {
    this.stopAudio();
    this.setData({
      summary: '',
      advice: [],
      oneline: '',
      audioUrl: '',
      audioReady: false,
      audioLoading: false,
      recommendedPoses: [],
      metadata: null,
      playing: false,
      usingCache: false,
      requestError: '',
      statusHint: ''
    });
  },

  toggleAudio() {
    if (this.data.audioLoading) {
      wx.showToast({ title: '语音生成中，请稍候', icon: 'none' });
      return;
    }
    if (!this.data.audioReady) {
      wx.showToast({ title: '暂无语音内容', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audioUrl) {
        audioCtx.stop();
        audioCtx.src = this.data.audioUrl;
      }
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.autoplay = false;
    audioCtx.obeyMuteSwitch = false;
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[guideplus] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  stopAudio() {
    if (!audioCtx) return;
    try {
      audioCtx.stop();
    } catch (err) {
      console.warn('[guideplus] stop audio failed', err);
    }
    this.setData({ playing: false });
  },

  destroyAudio() {
    if (!audioCtx) return;
    try {
      audioCtx.stop();
      audioCtx.destroy?.();
    } catch (err) {
      console.warn('[guideplus] destroy audio failed', err);
    }
    audioCtx = null;
  },

  handlePoseTap(event) {
    const pose = event.currentTarget.dataset.pose || {};
    const poseId = pose.poseId || pose.id || '';
    const poseName = pose.displayName || pose.name?.zh || pose.name?.en || '';
    const params = [];
    if (poseId) params.push(`poseId=${encodeURIComponent(poseId)}`);
    if (poseName) params.push(`poseName=${encodeURIComponent(poseName)}`);
    const url = params.length ? `/pages/sequence/sequence?${params.join('&')}` : '/pages/sequence/sequence';
    wx.navigateTo({ url });
  },

  handleSequenceTap() {
    wx.navigateTo({ url: '/pages/sequence/sequence' });
  },

  handleScoreTap() {
    wx.navigateTo({ url: '/pages/photo-detect/photo-detect' });
  },

  handleNearbyTap() {
    wx.navigateTo({ url: '/pages/nearby/nearby' });
  }
});
