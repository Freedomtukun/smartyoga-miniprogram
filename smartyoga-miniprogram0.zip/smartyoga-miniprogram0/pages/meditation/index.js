// pages/meditation/index.js
// 冥想页面 - 增强版（含语音合成、地图推荐）

import { MEDI_TTS_URL, MEDI_GEN_URL, FUNCTION_GATEWAY_ENDPOINTS } from '../../utils/yoga-api';
import { truncateByBytes } from '../../utils/text';
import { ensurePlayableAudio } from '../../utils/audio';
import { playTTS, stopTTS, pauseTTS, resumeTTS, onTTSEnd } from '../../utils/tts-player';
import { fetchNearbyPOIs, navigateToPOI } from '../../utils/map-recommend';

const meditationSessions = require('../../assets/meditation_sessions.js');

Page({
  data: {
    // 原有音频播放状态
    isPlaying: false,
    meditationList: [],
    currentIndex: 0,
    currentMeditation: {},
    
    // 新增：AI生成内容
    generatedText: '',
    isGenerating: false,
    
    // 新增：TTS状态
    audioUrl: '',
    isTTSPlaying: false,
    
    // 新增：地图推荐
    nearbyPOIs: [],
    isLoadingPOI: false,
    showPOISection: false
  },

  /**
   * 页面加载时初始化
   */
  onLoad: function () {
    this.initMeditationData();
    this.initAudioContext();
    
    // 监听TTS播放结束
    onTTSEnd(() => {
      this.setData({ isTTSPlaying: false });
    });
  },
  
  /**
   * 页面显示时加载附近推荐
   */
  onShow: function() {
    this.loadNearby();
  },

  /**
   * 初始化冥想数据
   */
  initMeditationData: function () {
    const meditationList = meditationSessions || [];
    const currentMeditation = meditationList[0] || {};
    
    this.setData({
      meditationList: meditationList,
      currentMeditation: currentMeditation,
      currentIndex: 0
    });
    
    console.log('冥想数据加载完成:', meditationList);
  },

  /**
   * 初始化音频上下文（原有音频）
   */
  initAudioContext: function () {
    if (this.innerAudioContext) {
      this.innerAudioContext.destroy();
    }

    this.innerAudioContext = wx.createInnerAudioContext({
      useWebAudioImplement: false
    });

    if (this.data.currentMeditation.audioUrl) {
      this.innerAudioContext.src = this.data.currentMeditation.audioUrl;
    }

    this.bindAudioEvents();
  },

  /**
   * 绑定音频事件监听
   */
  bindAudioEvents: function () {
    this.innerAudioContext.onPlay(() => {
      console.log('音频开始播放');
      this.setData({ isPlaying: true });
    });

    this.innerAudioContext.onPause(() => {
      console.log('音频暂停');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onStop(() => {
      console.log('音频停止');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onEnded(() => {
      console.log('音频播放结束');
      this.setData({ isPlaying: false });
    });

    this.innerAudioContext.onError((res) => {
      console.error('音频播放错误:', res.errMsg, '错误代码:', res.errCode);
      wx.showToast({
        title: '音频播放失败',
        icon: 'none',
        duration: 2000
      });
      this.setData({ isPlaying: false });
    });
  },

  /**
   * === 新增：生成冥想文本 ===
   */
  async generateMeditationText() {
    if (this.data.isGenerating) return;
    
    this.setData({ isGenerating: true });
    wx.showLoading({ title: '生成中...' });
    
    const themes = ['呼吸', '正念', '身体扫描', '慈悲', '放松'];
    const theme = themes[Math.floor(Math.random() * themes.length)];
    try {
      const result = await this.requestMeditationText({
        theme: theme,
        duration: this.data.currentMeditation.duration || 60,
        style: 'gentle'
      });

      wx.hideLoading();
      if (result.text) {
        this.setData({ 
          generatedText: result.text,
          audioUrl: result.audioUrl || '',
          isGenerating: false 
        });
        this.playGeneratedVoice();
      } else {
        this.setData({ isGenerating: false });
        wx.showToast({ title: '生成失败', icon: 'none' });
      }
    } catch (err) {
      wx.hideLoading();
      console.error('[meditation] 文本生成失败', err);
      this.setData({ isGenerating: false });
      wx.showToast({ title: '生成失败', icon: 'none' });
    }
  },

  /**
   * === 新增：播放生成的语音 ===
   */
  async playGeneratedVoice() {
    const text = this.data.generatedText || this.data.currentMeditation.desc;
    
    if (!text) {
      wx.showToast({ title: '请先生成冥想文本', icon: 'none' });
      return;
    }
    
    // 如果正在播放原音频，先停止
    if (this.data.isPlaying) {
      this.innerAudioContext.pause();
    }
    
    // 如果正在播放TTS，则暂停/继续
    if (this.data.isTTSPlaying) {
      pauseTTS();
      this.setData({ isTTSPlaying: false });
      return;
    }
    
    wx.showLoading({ title: '合成语音...' });

    const limitedText = truncateByBytes(text, 1200);

    const payload = {
      text: limitedText,
      voice: 'gentle_female',
      speed: 0.9
    };

    const primary = () => new Promise((resolve, reject) => {
      wx.request({
        url: MEDI_TTS_URL,
        method: 'POST',
        data: payload,
        success: ({ data }) => {
          const url = data?.data?.url || data?.url;
          if (url) {
            resolve(url);
          } else {
            reject(new Error('TTS url missing'));
          }
        },
        fail: reject
      });
    });

    const fallback = () => new Promise((resolve, reject) => {
      wx.request({
        url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
        method: 'POST',
        data: { action: 'tts', ...payload },
        success: ({ statusCode, data }) => {
          if (statusCode >= 200 && statusCode < 300) {
            const url = data?.audioUrl || data?.data?.audioUrl || data?.url;
            if (url) {
              resolve(url);
            } else {
              reject(new Error('Gateway TTS url missing'));
            }
          } else {
            reject(new Error(`meditation TTS gateway failed (${statusCode})`));
          }
        },
        fail: reject
      });
    });

    try {
      const audioUrlRaw = await primary().catch(err => {
        console.warn('[meditation] TTS主通道失败', err);
        return fallback();
      });
      const audioUrl = await ensurePlayableAudio(audioUrlRaw, { prefix: 'meditation-tts' });
      wx.hideLoading();
      if (!audioUrl) {
        wx.showToast({ title: '暂未生成音频', icon: 'none' });
        return;
      }

      this.setData({ 
        audioUrl,
        isTTSPlaying: true 
      });

      playTTS({ 
        url: audioUrl, 
        title: this.data.currentMeditation.name || '冥想语音',
        coverImgUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
      });
    } catch (err) {
      wx.hideLoading();
      console.error('[meditation] TTS 失败', err);
      wx.showToast({ title: '语音合成失败', icon: 'none' });
    }
  },

  requestMeditationText(payload) {
    const safePayload = {
      ...payload,
      theme: truncateByBytes(payload.theme, 64),
      style: payload.style ? truncateByBytes(payload.style, 128) : undefined
    };

    const primary = () => new Promise((resolve, reject) => {
      wx.request({
        url: MEDI_GEN_URL,
        method: 'POST',
        data: safePayload,
        success: ({ data }) => {
          const text = data?.data?.text || data?.text;
          const audioUrl = data?.data?.audioUrl || data?.audioUrl || '';
          if (text) {
            ensurePlayableAudio(audioUrl, { prefix: 'meditation' }).then(playable => {
              resolve({ text, audioUrl: playable });
            }).catch(reject);
          } else {
            reject(new Error('EMPTY_MEDITATION_TEXT'));
          }
        },
        fail: reject
      });
    });

    const fallback = () => new Promise((resolve, reject) => {
      wx.request({
        url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
        method: 'POST',
        data: { action: 'generate', ...safePayload },
        success: ({ statusCode, data }) => {
          if (statusCode >= 200 && statusCode < 300) {
            const body = data?.data || data || {};
            if (body.text) {
              ensurePlayableAudio(body.audioUrl || body.voiceUrl || body.audio || body.audio_base64 || '', { prefix: 'meditation' })
                .then(playable => resolve({ text: body.text, audioUrl: playable }))
                .catch(reject);
            } else {
              reject(new Error('EMPTY_MEDITATION_TEXT_GATEWAY'));
            }
          } else {
            reject(new Error(`meditation gateway failed (${statusCode})`));
          }
        },
        fail: reject
      });
    });

    return primary().catch(err => {
      console.warn('[meditation] 文本生成主通道失败', err);
      return fallback();
    });
  },

  /**
   * === 新增：加载附近冥想/瑜伽空间 ===
   */
  loadNearby() {
    this.setData({ isLoadingPOI: true });
    
    fetchNearbyPOIs({
      bizType: 'meditation',
      userIntent: '冥想静修',
      radius: 5000,
      enableReasons: true
    }).then(pois => {
      const poiList = Array.isArray(pois) ? pois : [];
      const meta = poiList.meta || {};

      if (meta.reason === 'OUT_OF_COVERAGE') {
        wx.showToast({ title: '所在区域暂未开通冥想推荐，已展示默认列表', icon: 'none' });
      }

      this.setData({ 
        nearbyPOIs: poiList.slice(0, 5),
        isLoadingPOI: false,
        showPOISection: false
      });
    }).catch(err => {
      console.error('[POI] 获取推荐失败:', err);
      this.setData({ isLoadingPOI: false });
    });
  },
  
  // 打开POI详情
  openPOI(e) {
    const poi = e.currentTarget.dataset.poi;
    if (poi) {
      navigateToPOI(poi);
    }
  },
  
  // 切换POI区域显示
  togglePOISection() {
    this.setData({ 
      showPOISection: !this.data.showPOISection 
    });
  },

  /**
   * 切换冥想类型
   */
  switchMeditation: function (e) {
    const index = e.currentTarget.dataset.index;
    const newMeditation = this.data.meditationList[index];
    
    if (!newMeditation || index === this.data.currentIndex) {
      return;
    }

    console.log('切换冥想类型:', newMeditation.name);

    // 停止所有播放
    if (this.innerAudioContext && this.data.isPlaying) {
      this.innerAudioContext.stop();
    }
    if (this.data.isTTSPlaying) {
      stopTTS();
    }

    // 更新数据
    this.setData({
      currentIndex: index,
      currentMeditation: newMeditation,
      isPlaying: false,
      isTTSPlaying: false,
      generatedText: '' // 清空生成的文本
    });

    // 切换音频源
    if (this.innerAudioContext) {
      this.innerAudioContext.src = newMeditation.audioUrl;
    }

    wx.showToast({
      title: `已切换到${newMeditation.name}`,
      icon: 'none',
      duration: 1500
    });
  },

  /**
   * 播放/暂停原始冥想音频
   */
  toggleMeditation: function () {
    if (!this.innerAudioContext) {
      console.error('音频上下文未初始化');
      return;
    }

    if (!this.data.currentMeditation.audioUrl) {
      wx.showToast({
        title: '音频链接无效',
        icon: 'none'
      });
      return;
    }
    
    // 如果正在播放TTS，先停止
    if (this.data.isTTSPlaying) {
      stopTTS();
      this.setData({ isTTSPlaying: false });
    }

    try {
      if (this.data.isPlaying) {
        this.innerAudioContext.pause();
        console.log('暂停冥想音频');
      } else {
        this.innerAudioContext.play();
        console.log('开始播放冥想音频');
      }
    } catch (error) {
      console.error('音频播放控制出错:', error);
      wx.showToast({
        title: '音频控制失败',
        icon: 'none'
      });
    }
  },

  /**
   * 返回上一页
   */
  handleBack: function () {
    // 停止所有音频
    if (this.innerAudioContext) {
      this.innerAudioContext.stop();
    }
    stopTTS();
    wx.navigateBack();
  },

  /**
   * 格式化时长显示
   */
  formatDuration: function (duration) {
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}分${seconds}秒`;
  },

  /**
   * 页面卸载时清理资源
   */
  onUnload: function () {
    if (this.innerAudioContext) {
      this.innerAudioContext.destroy();
      console.log('音频上下文已销毁');
    }
    stopTTS();
  },

  /**
   * 页面隐藏时暂停音频
   */
  onHide: function () {
    if (this.innerAudioContext && this.data.isPlaying) {
      this.innerAudioContext.pause();
    }
    if (this.data.isTTSPlaying) {
      pauseTTS();
    }
  },
  
  /**
   * 分享配置
   */
  onShareAppMessage() {
    return {
      title: '1分钟冥想放松 | 附近静修空间推荐',
      path: '/pages/meditation/index',
      imageUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
    };
  }
});
