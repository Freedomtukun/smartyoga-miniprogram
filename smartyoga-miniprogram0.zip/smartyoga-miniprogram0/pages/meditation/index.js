// pages/meditation/index.js
// 冥想页面 - 增强版（含语音合成、地图推荐）

import { MEDI_TTS_URL, MEDI_GEN_URL, FUNCTION_GATEWAY_ENDPOINTS, resolveAudioSource } from '../../utils/yoga-api';
import { truncateByBytes } from '../../utils/text';
import { playTTS, stopTTS, pauseTTS, resumeTTS, onTTSEnd } from '../../utils/tts-player';
import { fetchNearbyPOIs, navigateToPOI } from '../../utils/map-recommend';
import { safeParseJSON } from '../../utils/json';

const meditationSessions = require('../../assets/meditation_sessions.js');

Page({
  data: {
    // 原有音频播放状态
    isPlaying: false,
    meditationList: [],
    currentIndex: 0,
    currentMeditation: {},
    
    // 新增：AI生成内容
    generatedText: '',
    isGenerating: false,
    
    // 新增：TTS状态
    audioUrl: '',
    isTTSPlaying: false,
    
    // 新增：地图推荐
    nearbyPOIs: [],
    isLoadingPOI: false,
    showPOISection: false
  },

  /**
   * 页面加载时初始化
   */
  onLoad: function () {
    this.initMeditationData();
    this.initBackgroundAudioManager();

    // 监听TTS播放结束
    this.detachTtsEndListener = onTTSEnd(() => {
      this.setData({ isTTSPlaying: false });
      if (this.currentAudioSource === 'tts') {
        this.currentAudioSource = '';
      }
    });
  },
  
  /**
   * 页面显示时加载附近推荐
   */
  onShow: function() {
    this.loadNearby();
  },

  /**
   * 初始化冥想数据
   */
  initMeditationData: function () {
    const meditationList = meditationSessions || [];
    const currentMeditation = meditationList[0] || {};
    
    this.setData({
      meditationList: meditationList,
      currentMeditation: currentMeditation,
      currentIndex: 0
    });

    if (this.backgroundAudioManager) {
      this.updateBackgroundAudioMetadata();
    }
    
    console.log('冥想数据加载完成:', meditationList);
  },

  /**
   * 初始化背景音频管理器，确保锁屏后仍可播放
   */
  initBackgroundAudioManager() {
    if (this.backgroundAudioManager) {
      this.updateBackgroundAudioMetadata();
      return;
    }

    try {
      this.backgroundAudioManager = wx.getBackgroundAudioManager();
    } catch (error) {
      console.error('获取背景音频管理器失败', error);
      wx.showToast({ title: '设备不支持后台播放', icon: 'none' });
      return;
    }

    this.currentAudioSource = '';
    this.backgroundAudioManager.obeyMuteSwitch = false;
    this.attachBackgroundAudioEvents();
    this.updateBackgroundAudioMetadata();
  },

  attachBackgroundAudioEvents() {
    if (!this.backgroundAudioManager || this.backgroundAudioHandlersAttached) {
      return;
    }

    const manager = this.backgroundAudioManager;

    this.handleBgmPlay = () => {
      if (this.currentAudioSource === 'meditation') {
        this.setData({ isPlaying: true, isTTSPlaying: false });
      } else if (this.currentAudioSource === 'tts') {
        this.setData({ isTTSPlaying: true, isPlaying: false });
      }
    };

    this.handleBgmPause = () => {
      if (this.currentAudioSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.currentAudioSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
    };

    this.handleBgmStop = () => {
      if (this.currentAudioSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.currentAudioSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
      this.currentAudioSource = '';
    };

    this.handleBgmEnded = () => {
      if (this.currentAudioSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.currentAudioSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
      this.currentAudioSource = '';
    };

    this.handleBgmError = (res) => {
      console.error('背景音频播放错误:', res);
      wx.showToast({ title: '音频播放失败', icon: 'none' });
      const fallbackSource = this.currentAudioSource || this.lastBackgroundAudioSource || 'meditation';
      let fallbackUrl = this.lastBackgroundAudioUrl;
      if (!fallbackUrl) {
        fallbackUrl = fallbackSource === 'tts'
          ? (this.data.audioUrl || '')
          : (this.data.currentMeditation?.audioUrl || '');
      }
      if (this.currentAudioSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.currentAudioSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
      this.currentAudioSource = '';

      if (fallbackUrl) {
        console.warn('[meditation] 尝试使用备用播放器播放音频');
        this.playFallbackAudio(fallbackUrl, fallbackSource || 'meditation');
      }
    };

    manager.onPlay(this.handleBgmPlay);
    manager.onPause(this.handleBgmPause);
    manager.onStop(this.handleBgmStop);
    manager.onEnded(this.handleBgmEnded);
    manager.onError(this.handleBgmError);

    this.backgroundAudioHandlersAttached = true;
  },

  detachBackgroundAudioEvents() {
    if (!this.backgroundAudioManager || !this.backgroundAudioHandlersAttached) {
      return;
    }
    const manager = this.backgroundAudioManager;
    if (typeof manager.offPlay === 'function' && this.handleBgmPlay) {
      manager.offPlay(this.handleBgmPlay);
    }
    if (typeof manager.offPause === 'function' && this.handleBgmPause) {
      manager.offPause(this.handleBgmPause);
    }
    if (typeof manager.offStop === 'function' && this.handleBgmStop) {
      manager.offStop(this.handleBgmStop);
    }
    if (typeof manager.offEnded === 'function' && this.handleBgmEnded) {
      manager.offEnded(this.handleBgmEnded);
    }
    if (typeof manager.offError === 'function' && this.handleBgmError) {
      manager.offError(this.handleBgmError);
    }
    this.backgroundAudioHandlersAttached = false;
  },

  updateBackgroundAudioMetadata() {
    if (!this.backgroundAudioManager) return;
    const meditation = this.data.currentMeditation || {};
    const title = meditation.name || '冥想音乐';
    this.backgroundAudioManager.title = title;
    this.backgroundAudioManager.epname = title;
    this.backgroundAudioManager.singer = meditation.author || 'SmartYoga';
    this.backgroundAudioManager.coverImgUrl = meditation.coverImgUrl || 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png';
  },

  initFallbackAudioContext() {
    if (this.innerFallbackAudio) {
      return;
    }
    this.innerFallbackAudio = wx.createInnerAudioContext({ useWebAudioImplement: false });
    this.innerFallbackAudio.obeyMuteSwitch = false;
    this.innerFallbackAudio.onPlay(() => {
      if (this.fallbackSource === 'meditation') {
        this.setData({ isPlaying: true });
      } else if (this.fallbackSource === 'tts') {
        this.setData({ isTTSPlaying: true });
      }
    });
    this.innerFallbackAudio.onPause(() => {
      if (this.fallbackSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.fallbackSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
    });
    this.innerFallbackAudio.onStop(() => {
      if (this.fallbackSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.fallbackSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
    });
    this.innerFallbackAudio.onEnded(() => {
      if (this.fallbackSource === 'meditation') {
        this.setData({ isPlaying: false });
      } else if (this.fallbackSource === 'tts') {
        this.setData({ isTTSPlaying: false });
      }
      if (this.currentAudioSource === this.fallbackSource) {
        this.currentAudioSource = '';
      }
    });
    this.innerFallbackAudio.onError((err) => {
      console.error('[meditation] 备用音频播放失败', err);
      wx.showToast({ title: '设备暂不支持后台播放', icon: 'none' });
    });
  },

  playFallbackAudio(url, source = 'meditation') {
    if (!url) return;
    this.initFallbackAudioContext();
    try {
      if (this.backgroundAudioManager) {
        this.backgroundAudioManager.stop();
      }
    } catch (err) {
      console.warn('[meditation] 停止背景音频失败', err);
    }
    this.fallbackSource = source;
    this.currentAudioSource = source;
    this.lastBackgroundAudioUrl = url;
    this.lastBackgroundAudioSource = source;
    this.innerFallbackAudio.src = url;
    this.innerFallbackAudio.play();
  },

  stopFallbackAudio(source) {
    if (!this.innerFallbackAudio) return;
    if (source && this.fallbackSource && this.fallbackSource !== source) {
      return;
    }
    try {
      this.innerFallbackAudio.stop();
    } catch (err) {
      console.warn('[meditation] 停止备用音频失败', err);
    }
  },

  /**
   * === 新增：生成冥想文本 ===
   */
  async generateMeditationText() {
    if (this.data.isGenerating) return;
    
    this.setData({ isGenerating: true });
    wx.showLoading({ title: '生成中...' });
    
    const themes = ['呼吸', '正念', '身体扫描', '慈悲', '放松'];
    const theme = themes[Math.floor(Math.random() * themes.length)];
    try {
      const result = await this.requestMeditationText({
        theme: theme,
        duration: this.data.currentMeditation.duration || 60,
        style: 'gentle'
      });

      wx.hideLoading();
      if (result.text) {
        this.setData({ 
          generatedText: result.text,
          audioUrl: result.audioUrl || '',
          isGenerating: false 
        });
        this.playGeneratedVoice();
      } else {
        this.setData({ isGenerating: false });
        wx.showToast({ title: '生成失败', icon: 'none' });
      }
    } catch (err) {
      wx.hideLoading();
      console.error('[meditation] 文本生成失败', err);
      this.setData({ isGenerating: false });
      wx.showToast({ title: '生成失败', icon: 'none' });
    }
  },

  /**
   * === 新增：播放生成的语音 ===
   */
  async playGeneratedVoice() {
    const text = this.data.generatedText || this.data.currentMeditation.desc;
    
    if (!text) {
      wx.showToast({ title: '请先生成冥想文本', icon: 'none' });
      return;
    }
    
    // 如果正在播放原音频，先停止
    if (this.currentAudioSource === 'meditation') {
      this.pauseMeditation();
    }

    this.initBackgroundAudioManager();
    const manager = this.backgroundAudioManager;
    const isTtsSource = this.currentAudioSource === 'tts';

    if (isTtsSource && manager) {
      if (!manager.paused) {
        pauseTTS();
        this.setData({ isTTSPlaying: false });
        return;
      }
      if (manager.paused) {
        resumeTTS();
        this.setData({ isTTSPlaying: true });
        return;
      }
    }
    
    wx.showLoading({ title: '合成语音...' });

    const limitedText = truncateByBytes(text, 1200);

    const payload = {
      text: limitedText,
      voice: 'gentle_female',
      speed: 0.9
    };

    const primary = () => new Promise((resolve, reject) => {
      wx.request({
        url: MEDI_TTS_URL,
        method: 'POST',
        data: payload,
        success: ({ data }) => {
          let body = typeof data === 'string' ? safeParseJSON(data, null) : data;
          if (body && typeof body.data === 'string') {
            const nested = safeParseJSON(body.data, null);
            if (nested) {
              body = { ...body, data: nested };
            }
          }
          const url = body?.data?.url || body?.data?.audioUrl || body?.url || body?.audioUrl;
          if (url) {
            resolve(url);
          } else {
            reject(new Error('TTS url missing'));
          }
        },
        fail: reject
      });
    });

    const fallback = () => new Promise((resolve, reject) => {
      wx.request({
        url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
        method: 'POST',
        data: { action: 'tts', ...payload },
        success: ({ statusCode, data }) => {
          if (statusCode >= 200 && statusCode < 300) {
            let body = typeof data === 'string' ? safeParseJSON(data, null) : data;
            if (body && typeof body.data === 'string') {
              const nested = safeParseJSON(body.data, null);
              if (nested) {
                body = { ...body, data: nested };
              }
            }
            const url = body?.audioUrl || body?.data?.audioUrl || body?.url;
            if (url) {
              resolve(url);
            } else {
              reject(new Error('Gateway TTS url missing'));
            }
          } else {
            reject(new Error(`meditation TTS gateway failed (${statusCode})`));
          }
        },
        fail: reject
      });
    });

    try {
      const audioUrlRaw = await primary().catch(err => {
        console.warn('[meditation] TTS主通道失败', err);
        return fallback();
      });
      const audioUrl = await resolveAudioSource(audioUrlRaw, { prefix: 'meditation-tts' });
      wx.hideLoading();
      if (!audioUrl) {
        wx.showToast({ title: '暂未生成音频', icon: 'none' });
        return;
      }

      this.setData({ 
        audioUrl,
        isTTSPlaying: true 
      });

      this.currentAudioSource = 'tts';
      this.lastBackgroundAudioUrl = audioUrl;
      this.lastBackgroundAudioSource = 'tts';

      playTTS({ 
        url: audioUrl, 
        title: this.data.currentMeditation.name || '冥想语音',
        coverImgUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
      });
    } catch (err) {
      wx.hideLoading();
      console.error('[meditation] TTS 失败', err);
      wx.showToast({ title: '语音合成失败', icon: 'none' });
      if (this.currentAudioSource === 'tts' && !this.data.isTTSPlaying) {
        this.currentAudioSource = '';
      }
    }
  },

  requestMeditationText(payload) {
    const safePayload = {
      ...payload,
      theme: truncateByBytes(payload.theme, 64),
      style: payload.style ? truncateByBytes(payload.style, 128) : undefined
    };

    const primary = () => new Promise((resolve, reject) => {
      wx.request({
        url: MEDI_GEN_URL,
        method: 'POST',
        data: safePayload,
        success: ({ data }) => {
          let body = typeof data === 'string' ? safeParseJSON(data, null) : data;
          if (body && typeof body.data === 'string') {
            const nested = safeParseJSON(body.data, null);
            if (nested) {
              body = { ...body, data: nested };
            }
          }
          const payloadData = body?.data || body || {};
          const text = payloadData?.text;
          const audioSource = payloadData?.audioUrl || payloadData?.audio || payloadData?.audio_base64 || '';
          if (text) {
            resolveAudioSource(audioSource, { prefix: 'meditation' }).then(playable => {
              resolve({ text, audioUrl: playable });
            }).catch(reject);
          } else {
            reject(new Error('EMPTY_MEDITATION_TEXT'));
          }
        },
        fail: reject
      });
    });

    const fallback = () => new Promise((resolve, reject) => {
      wx.request({
        url: FUNCTION_GATEWAY_ENDPOINTS.MEDITATION,
        method: 'POST',
        data: { action: 'generate', ...safePayload },
        success: ({ statusCode, data }) => {
          if (statusCode >= 200 && statusCode < 300) {
            let body = typeof data === 'string' ? safeParseJSON(data, null) : data;
            if (body && typeof body.data === 'string') {
              const nested = safeParseJSON(body.data, null);
              if (nested) {
                body = { ...body, data: nested };
              }
            }
            const payloadData = body?.data || body || {};
            const text = payloadData?.text;
            if (text) {
              resolveAudioSource(payloadData.audioUrl || payloadData.voiceUrl || payloadData.audio || payloadData.audio_base64 || '', { prefix: 'meditation' })
                .then(playable => resolve({ text, audioUrl: playable }))
                .catch(reject);
            } else {
              reject(new Error('EMPTY_MEDITATION_TEXT_GATEWAY'));
            }
          } else {
            reject(new Error(`meditation gateway failed (${statusCode})`));
          }
        },
        fail: reject
      });
    });

    return primary().catch(err => {
      console.warn('[meditation] 文本生成主通道失败', err);
      return fallback();
    });
  },

  /**
   * === 新增：加载附近冥想/瑜伽空间 ===
   */
  loadNearby() {
    this.setData({ isLoadingPOI: true });
    
    fetchNearbyPOIs({
      bizType: 'meditation',
      userIntent: '冥想静修',
      radius: 5000,
      enableReasons: true
    }).then(pois => {
      const poiList = Array.isArray(pois) ? pois : [];
      const meta = poiList.meta || {};

      if (meta.reason === 'OUT_OF_COVERAGE') {
        wx.showToast({ title: '所在区域暂未开通冥想推荐，已展示默认列表', icon: 'none' });
      }

      this.setData({ 
        nearbyPOIs: poiList.slice(0, 5),
        isLoadingPOI: false,
        showPOISection: false
      });
    }).catch(err => {
      console.error('[POI] 获取推荐失败:', err);
      this.setData({ isLoadingPOI: false });
    });
  },
  
  // 打开POI详情
  openPOI(e) {
    const poi = e.currentTarget.dataset.poi;
    if (poi) {
      navigateToPOI(poi);
    }
  },
  
  // 切换POI区域显示
  togglePOISection() {
    this.setData({ 
      showPOISection: !this.data.showPOISection 
    });
  },

  /**
   * 切换冥想类型
   */
  switchMeditation: function (e) {
    const index = e.currentTarget.dataset.index;
    const newMeditation = this.data.meditationList[index];
    
    if (!newMeditation || index === this.data.currentIndex) {
      return;
    }

    console.log('切换冥想类型:', newMeditation.name);

    // 停止所有播放
    if (this.currentAudioSource === 'meditation') {
      this.stopMeditation();
    }
    if (this.data.isTTSPlaying || this.currentAudioSource === 'tts') {
      stopTTS();
      this.setData({ isTTSPlaying: false });
      this.currentAudioSource = '';
    }

    // 更新数据
    this.setData({
      currentIndex: index,
      currentMeditation: newMeditation,
      isPlaying: false,
      isTTSPlaying: false,
      generatedText: '' // 清空生成的文本
    });

    this.updateBackgroundAudioMetadata();

    wx.showToast({
      title: `已切换到${newMeditation.name}`,
      icon: 'none',
      duration: 1500
    });
  },

  /**
   * 播放/暂停原始冥想音频
   */
  toggleMeditation: function () {
    const audioUrl = this.data.currentMeditation.audioUrl;

    if (!audioUrl) {
      wx.showToast({
        title: '音频链接无效',
        icon: 'none'
      });
      return;
    }

    this.initBackgroundAudioManager();
    const manager = this.backgroundAudioManager;
    if (!manager) {
      wx.showToast({ title: '音频初始化失败', icon: 'none' });
      return;
    }

    // 如果正在播放TTS，先停止
    this.stopTTSIfNeeded();

    try {
      if (this.currentAudioSource === 'meditation' && !manager.paused) {
        if (typeof manager.seek === 'function') {
          manager.seek(0);
        }
        wx.showToast({ title: '已从头播放', icon: 'none' });
        return;
      }

      if (this.currentAudioSource === 'meditation' && manager.paused) {
        manager.play();
        console.log('继续播放冥想音频');
        return;
      }

      this.currentAudioSource = 'meditation';
      this.lastBackgroundAudioUrl = audioUrl;
      this.lastBackgroundAudioSource = 'meditation';
      this.updateBackgroundAudioMetadata();

      if (manager.src !== audioUrl) {
        manager.src = audioUrl;
      } else {
        manager.play();
      }
      console.log('开始播放冥想音频');
    } catch (error) {
      console.error('音频播放控制出错:', error);
      wx.showToast({
        title: '音频控制失败',
        icon: 'none'
      });
    }
  },

  pauseMeditation() {
    if (this.currentAudioSource !== 'meditation') {
      return;
    }
    let handled = false;
    if (this.backgroundAudioManager) {
      try {
        if (!this.backgroundAudioManager.paused) {
          this.backgroundAudioManager.pause();
          handled = true;
          console.log('暂停冥想音频');
        }
      } catch (error) {
        console.error('暂停冥想音频失败:', error);
      }
    }
    if (!handled && this.innerFallbackAudio) {
      try {
        this.innerFallbackAudio.pause();
        handled = true;
      } catch (error) {
        console.error('暂停备用冥想音频失败:', error);
      }
    }
    if (handled) {
      this.setData({ isPlaying: false });
    }
  },

  stopMeditation() {
    if (this.backgroundAudioManager && this.currentAudioSource === 'meditation') {
      try {
        this.backgroundAudioManager.stop();
      } catch (error) {
        console.warn('停止冥想音频时出错', error);
      }
      this.currentAudioSource = '';
    }
    this.stopFallbackAudio('meditation');
    this.setData({ isPlaying: false });
  },

  stopTTSIfNeeded() {
    if (this.data.isTTSPlaying || this.currentAudioSource === 'tts') {
      try {
        stopTTS();
      } catch (error) {
        console.warn('停止TTS时出错', error);
      }
      this.setData({ isTTSPlaying: false });
      this.currentAudioSource = '';
      this.stopFallbackAudio('tts');
    }
  },

  /**
   * 返回上一页
   */
  handleBack: function () {
    // 停止所有音频
    this.stopMeditation();
    this.stopTTSIfNeeded();
    wx.navigateBack();
  },

  /**
   * 格式化时长显示
   */
  formatDuration: function (duration) {
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}分${seconds}秒`;
  },

  /**
   * 页面卸载时清理资源
   */
  onUnload: function () {
    this.stopMeditation();
    this.stopTTSIfNeeded();
    this.detachBackgroundAudioEvents();
    if (typeof this.detachTtsEndListener === 'function') {
      this.detachTtsEndListener();
      this.detachTtsEndListener = null;
    }
    this.backgroundAudioManager = null;
    this.currentAudioSource = '';
    if (this.innerFallbackAudio) {
      try {
        this.innerFallbackAudio.destroy();
      } catch (err) {
        console.warn('[meditation] 销毁备用播放器失败', err);
      }
      this.innerFallbackAudio = null;
    }
  },

  /**
   * 页面隐藏时暂停音频
   */
  onHide: function () {
    // 允许后台播放，保持当前状态
  },
  
  /**
   * 分享配置
   */
  onShareAppMessage() {
    return {
      title: '1分钟冥想放松 | 附近静修空间推荐',
      path: '/pages/meditation/index',
      imageUrl: 'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/meditation_lotus.png'
    };
  }
});
