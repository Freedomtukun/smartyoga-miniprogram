import { uploadAndScore } from '../../utils/score-upload';
import { resolveAudioSource } from '../../utils/yoga-api';

const fs = wx.getFileSystemManager();

const MAX_UPLOAD_BYTES = 900 * 1024; // 约 900KB，用于限制上传体积
const RESIZE_WIDTHS = [1600, 1366, 1200, 1024, 896, 768, 640, 512, 400, 320, 240];
const COMPRESS_QUALITIES = [80, 70, 62, 56, 48, 40, 34, 28, 24, 20, 16, 12, 8, 5, 3, 2];

function normalizeLocalPath(path = '') {
  if (!path || typeof path !== 'string') return path;
  if (path.startsWith('http://tmp/')) return path.replace(/^http:\/\//, 'wxfile://');
  if (path.startsWith('tmp/')) return `wxfile://${path}`;
  return path;
}

function getExtension(path = '') {
  const match = /\.([a-z0-9]+)$/i.exec(path);
  return match ? match[1].toLowerCase() : 'jpg';
}

function fileExists(path) {
  return new Promise(resolve => {
    if (!path) return resolve(false);
    fs.stat({ path, success: () => resolve(true), fail: () => resolve(false) });
  });
}

function copyToUserPath(path) {
  return new Promise((resolve, reject) => {
    const normalized = normalizeLocalPath(path);
    const ext = getExtension(normalized);
    const target = `${wx.env.USER_DATA_PATH}/pose-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    fs.copyFile({
      srcPath: normalized,
      destPath: target,
      success: () => resolve(target),
      fail: reject
    });
  });
}

async function ensureStablePath(path, fallback) {
  const normalized = normalizeLocalPath(path);
  if (!normalized) return normalized;

  if (normalized.startsWith(wx.env.USER_DATA_PATH)) {
    if (await fileExists(normalized)) return normalized;
    if (fallback) return ensureStablePath(fallback);
    throw new Error('文件已丢失，请重新选择');
  }

  if (await fileExists(normalized)) {
    return copyToUserPath(normalized);
  }

  if (fallback) return ensureStablePath(fallback);
  throw new Error('图片不可用，请重新选择');
}

function compressOnce(path, quality) {
  return new Promise((resolve, reject) => {
    wx.compressImage({
      src: path,
      quality,
      success: res => resolve(res.tempFilePath || path),
      fail: reject
    });
  });
}

function getFileSize(path) {
  return new Promise((resolve, reject) => {
    fs.stat({
      path,
      success: (res) => {
        const size = res?.size ?? res?.stats?.size ?? 0;
        resolve(size);
      },
      fail: reject
    });
  });
}

async function resizeToWidth(path, width) {
  const stable = await ensureStablePath(path);
  if (!width || width <= 0) return stable;

  try {
    const info = await wx.getImageInfo({ src: stable });
    if (!info.width || info.width <= width) return stable;

    const targetWidth = width;
    const targetHeight = Math.max(1, Math.round((info.height / info.width) * targetWidth));
    console.log('[photo-detect] resize to', targetWidth, 'x', targetHeight);

    if (typeof wx.createOffscreenCanvas !== 'function') {
      const fallbackQuality = Math.max(10, Math.min(80, Math.floor((targetWidth / info.width) * 100)));
      const fallbackPath = await compressOnce(stable, fallbackQuality);
      return ensureStablePath(fallbackPath || stable, stable);
    }

    const canvas = wx.createOffscreenCanvas({ type: '2d', width: targetWidth, height: targetHeight });
    const ctx = canvas.getContext('2d');
    const img = canvas.createImage();

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = stable;
    });

    ctx.clearRect(0, 0, targetWidth, targetHeight);
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

    const { tempFilePath } = await new Promise((resolve, reject) => {
      canvas.toTempFilePath({
        destWidth: targetWidth,
        destHeight: targetHeight,
        fileType: 'jpg',
        quality: 0.8,
        success: resolve,
        fail: reject
      });
    });

    return ensureStablePath(tempFilePath, stable);
  } catch (err) {
    console.warn('[photo-detect] resize failed', err);
    return stable;
  }
}

async function optimizeAtWidth(basePath, widthLabel) {
  let currentPath = await ensureStablePath(basePath);
  const qualities = [null, ...COMPRESS_QUALITIES];

  for (const quality of qualities) {
    if (quality !== null) {
      try {
        const nextPath = await compressOnce(currentPath, quality);
        currentPath = await ensureStablePath(nextPath || currentPath, basePath);
      } catch (err) {
        console.warn('[photo-detect] compress failed', quality, err);
        continue;
      }
    }

    try {
      const size = await getFileSize(currentPath);
      console.log('[photo-detect] candidate width=', widthLabel, 'quality=', quality ?? 'orig', 'bytes=', size);
      if (size <= MAX_UPLOAD_BYTES) {
        return {
          path: currentPath,
          size,
          ext: getExtension(currentPath)
        };
      }
    } catch (statErr) {
      console.warn('[photo-detect] stat failed', statErr);
    }
  }

  return null;
}

async function prepareImageForUpload(originalPath) {
  const stableOriginal = await ensureStablePath(originalPath);
  const widths = [0, ...RESIZE_WIDTHS];

  for (const width of widths) {
    let candidatePath = stableOriginal;
    const label = width || 'orig';

    if (width > 0) {
      candidatePath = await resizeToWidth(stableOriginal, width);
    }

    const optimized = await optimizeAtWidth(candidatePath, label);
    if (optimized) return optimized;
  }

  const error = new Error('图片过大，请截取或换一张更小的照片');
  error.detail = { maxBytes: MAX_UPLOAD_BYTES };
  error.code = 'PAYLOAD_TOO_LARGE';
  throw error;
}

function isPayloadTooLarge(error) {
  if (!error) return false;
  if (error.code === 'PAYLOAD_TOO_LARGE') return true;
  const msg = error.errMsg || error.message || '';
  return msg.includes('413') || msg.includes('Payload Too Large');
}

Page({
  data: {
    uploading: false,
    error: '',
    preview: '',
    score: 0,
    advice: '',
    summary: '',
    skeletonUrl: '',
    audioSrc: '',
    playing: false,
    hasResult: false,
    tips: [
      '确保相机光线充足，身体轮廓清晰可见',
      '尽量让全身出现在画面中，保持单人拍摄',
      '建议选择正面或侧面角度，便于算法识别'
    ]
  },

  async chooseAndScore() {
    if (this.data.uploading) return;

    try {
      const pick = await wx.chooseImage({ count: 1, sizeType: ['compressed', 'original'] });
      const originalPath = normalizeLocalPath(pick.tempFilePaths?.[0]);
      if (!originalPath) throw new Error('未选择图片');

      this.setData({
        uploading: true,
        error: '',
        preview: '',
        score: 0,
        advice: '',
        summary: '',
        skeletonUrl: '',
        audioSrc: '',
        playing: false,
        hasResult: false
      });

      const prepared = await prepareImageForUpload(originalPath);
      this.setData({ preview: prepared.path });

      const result = await uploadAndScore(prepared.path, {
        fileSize: prepared.size,
        fileExt: prepared.ext
      });

      if (!result || !result.ok) throw new Error('评分失败');

      this.setData({
        score: Number(result.score || 0),
        advice: result.advice || '暂无建议',
        summary: result.summary || '',
        skeletonUrl: result.skeletonUrl || '',
        hasResult: true,
        audioSrc: '',
        playing: false
      });

      if (result.skeletonUrl) {
        this.setData({ preview: result.skeletonUrl });
      }

      const audioCandidate = result.audioUrl || result.audio || result.audio_base64;
      if (audioCandidate) {
        try {
          const playable = await resolveAudioSource(audioCandidate, { prefix: 'feedback' });
          if (playable) this.playAudio(playable);
        } catch (audioError) {
          console.warn('[photo-detect] audio resolve failed', audioError);
        }
      }
    } catch (err) {
      console.warn('[photo-detect] chooseAndScore failed', err);
      const msg = isPayloadTooLarge(err)
        ? '图片过大，请截取或换一张更小的照片'
        : err?.message || '上传或评分失败';
      this.setData({ error: msg });
      wx.showToast({ title: msg, icon: 'none' });
    } finally {
      this.setData({ uploading: false });
    }
  },

  onReplayAudio() {
    if (this.data.audioSrc) {
      this.playAudio(this.data.audioSrc);
    }
  },

  playAudio(src) {
    if (!src) return;

    if (/^https?:\/\//i.test(src)) {
      if (!this.bgm) {
        this.bgm = wx.getBackgroundAudioManager();
        this.bgm.onPlay(() => this.setData({ playing: true }));
        this.bgm.onStop(() => this.setData({ playing: false }));
        this.bgm.onEnded(() => this.setData({ playing: false }));
        this.bgm.onError((err) => {
          console.warn('[photo-detect] bgm error', err);
          this.setData({ playing: false });
        });
      }
      this.bgm.title = '姿势反馈';
      this.bgm.epname = 'SmartYoga';
      this.bgm.singer = 'SmartYoga';
      this.bgm.coverImgUrl =
        'https://yogasmart-static-1351554677.cos.ap-shanghai.myqcloud.com/images/poses/feedback_default.png';
      this.bgm.src = src;
      this.setData({ audioSrc: src, playing: true });
      return;
    }

    if (!this.iac) {
      this.iac = wx.createInnerAudioContext();
      this.iac.autoplay = true;
      this.iac.obeyMuteSwitch = false;
      this.iac.onPlay(() => this.setData({ playing: true }));
      this.iac.onStop(() => this.setData({ playing: false }));
      this.iac.onEnded(() => this.setData({ playing: false }));
      this.iac.onError((err) => {
        console.warn('[photo-detect] audio error', err);
        this.setData({ playing: false });
      });
    }

    try { this.iac.stop(); } catch (e) { console.warn('[photo-detect] stop audio failed', e); }
    this.iac.src = src;
    this.iac.play();
    this.setData({ audioSrc: src });
  },

  onUnload() {
    try {
      if (this.bgm) {
        this.bgm.stop();
      }
    } catch (_) {}
    if (this.iac) {
      try { this.iac.stop(); } catch (_) {}
      this.iac.destroy();
      this.iac = null;
    }
    this.setData({ playing: false });
  }
});
