import { uploadAndScore } from '../../utils/score-upload';

const MAX_UPLOAD_BYTES = 900 * 1024; // 900KB target to stay below gateway limit
const INITIAL_COMPRESS_QUALITIES = [80, 60, 45, 35];
const RETRY_COMPRESS_QUALITIES = [40, 30, 25];
const fs = wx.getFileSystemManager();

function getFileSize(path) {
  return new Promise((resolve, reject) => {
    fs.stat({
      path,
      success: res => resolve(res.size),
      fail: reject
    });
  });
}

function compressOnce(path, quality) {
  return new Promise((resolve, reject) => {
    wx.compressImage({
      src: path,
      quality,
      success: res => resolve(res.tempFilePath || path),
      fail: reject
    });
  });
}

async function compressImageToLimit(originalPath) {
  let currentPath = originalPath;
  for (let i = 0; i < INITIAL_COMPRESS_QUALITIES.length; i++) {
    const size = await getFileSize(currentPath).catch(() => MAX_UPLOAD_BYTES + 1);
    if (size <= MAX_UPLOAD_BYTES) {
      return currentPath;
    }
    try {
      const nextPath = await compressOnce(currentPath, INITIAL_COMPRESS_QUALITIES[i]);
      currentPath = nextPath || currentPath;
    } catch (error) {
      console.warn('[photo-detect] compressImage failed', error);
      break;
    }
  }
  return currentPath;
}

function isPayloadTooLarge(error) {
  if (!error) return false;
  if (error.code === 'PAYLOAD_TOO_LARGE') return true;
  const msg = error.errMsg || error.message || '';
  return msg.includes('413') || msg.includes('Payload Too Large');
}

Page({
  data: {
    uploading: false,
    error: '',
    preview: '',
    tips: [
      '确保相机光线充足，身体轮廓清晰可见',
      '尽量让全身出现在画面中，保持单人拍摄',
      '建议选择正面或侧面角度，便于算法识别'
    ]
  },

  async chooseAndScore() {
    if (this.data.uploading) return;
    try {
      const pick = await wx.chooseImage({ count: 1, sizeType: ['compressed'] });
      const originalPath = pick.tempFilePaths?.[0];
      if (!originalPath) throw new Error('未选择图片');
      this.setData({ uploading: true, error: '', preview: originalPath });

      let currentPath = await compressImageToLimit(originalPath);
      if (currentPath !== originalPath) {
        this.setData({ preview: currentPath });
      }

      let result;
      let attempt = 0;
      while (attempt < RETRY_COMPRESS_QUALITIES.length + 1) {
        try {
          result = await uploadAndScore(currentPath);
          break;
        } catch (err) {
          if (!isPayloadTooLarge(err) || attempt === RETRY_COMPRESS_QUALITIES.length) {
            throw err;
          }
          wx.showToast({ title: '图片较大，正在压缩后重试', icon: 'none' });
          currentPath = await compressOnce(currentPath, RETRY_COMPRESS_QUALITIES[attempt]);
          this.setData({ preview: currentPath });
          attempt += 1;
        }
      }

      if (!result) {
        throw new Error('评分失败');
      }

      const r = result;
      wx.navigateTo({
        url:
          `/pages/result/result?` +
          `score=${r.score}` +
          `&advice=${encodeURIComponent(r.advice || '')}` +
          `&summary=${encodeURIComponent(r.summary || '')}` +
          `&img=${encodeURIComponent(currentPath)}` +
          `&skeleton=${encodeURIComponent(r.skeletonUrl || '')}` +
          `&audio=${encodeURIComponent(r.audioUrl || '')}`
      });
    } catch (e) {
      const msg = e?.message || '上传或评分失败';
      this.setData({ error: msg });
      wx.showToast({ title: msg, icon: 'none' });
    } finally {
      this.setData({ uploading: false });
    }
  }
});
