import { ensurePlayableAudio } from '../../utils/audio';

let audioCtx;
Page({
  data:{ score:0, advice:'', summary:'', img:'', skeleton:'', audio:'', playing:false, showMore:false },
  async onLoad(q){
    const decodedAudio = decodeURIComponent(q.audio||'');
    let playableAudio = decodedAudio;
    try {
      const converted = await ensurePlayableAudio(decodedAudio, { prefix: 'feedback' });
      if (converted) {
        playableAudio = converted;
      }
    } catch (err) {
      console.warn('[result] ensure audio failed', err);
    }

    this.setData({
      score: Number(q.score||0),
      advice: decodeURIComponent(q.advice||''),
      summary: decodeURIComponent(q.summary||''),
      img: decodeURIComponent(q.img||''),
      skeleton: decodeURIComponent(q.skeleton||''),
      audio: playableAudio
    });
    if(!audioCtx){
      audioCtx = wx.createInnerAudioContext();
      audioCtx.onPlay(()=>this.setData({playing:true}));
      audioCtx.onPause(()=>this.setData({playing:false}));
      audioCtx.onStop(()=>this.setData({playing:false}));
      audioCtx.onEnded(()=>this.setData({playing:false}));
      audioCtx.onError(()=>this.setData({playing:false}));
    }
    if(this.data.audio) audioCtx.src = this.data.audio;
  },
  onUnload(){ if(audioCtx) audioCtx.stop(); },
  toggleMore(){ this.setData({ showMore: !this.data.showMore }); },
  togglePlay(){
    if(!this.data.audio) return wx.showToast({ title:'暂无音频', icon:'none' });
    this.data.playing ? audioCtx.pause() : audioCtx.play();
  }
});
