// pages/sequence/index.js
// 序列训练页面 - 增强版（含地图推荐、语音引导）

import { uploadFrameForScoring, DEFAULT_POSE_IMAGE, GUIDE_TTS_URL, FUNCTION_GATEWAY_ENDPOINTS } from '../../utils/yoga-api.js';
import { truncateByBytes } from '../../utils/text';
import { fetchNearbyPOIs, navigateToPOI } from '../../utils/map-recommend';
import { playTTS, stopTTS, pauseTTS, resumeTTS } from '../../utils/tts-player';
import poseImages from '../../assets/images.js';

const cloudSequenceService = require('../../utils/cloud-sequence-service.js');
const sequenceService = require('../../utils/sequence-service.js');
const getText = v => (typeof v === 'object' ? (v.zh || v.en || '') : v);

function normalizeKey(key) {
  if (!key) return '';
  return key.toLowerCase().replace(/[-\s]/g, '_');
}

Page({
  data: {
    // 原有数据
    level: '',
    currentSequence: null,
    currentPoseIndex: 0,
    isPlaying: false,
    timeRemaining: 0,
    loading: true,
    error: null,
    skeletonUrl: null,
    timerId: null,
    showScoreModal: false,
    poseScore: null,
    scoreSkeletonImageUrl: null,
    defaultPoseImage: DEFAULT_POSE_IMAGE,
    poseImages,
    normalizedPoseKey: '',
    
    // 新增：地图推荐
    nearbyPOIs: [],
    isLoadingPOI: false,
    showPOISection: false,
    
    // 新增：语音控制
    isVoiceEnabled: false,
    isVoicePlaying: false
  },

  updateNormalizedPoseKey() {
    const seq = this.data.currentSequence;
    const idx = this.data.currentPoseIndex;
    const key = seq && seq.poses && seq.poses[idx] ? seq.poses[idx].key : '';
    this.setData({ normalizedPoseKey: normalizeKey(key) });
  },

  // Page lifecycle: Load sequence data
  onLoad: function (options) {
    const level = options.level || 'beginner';
    this.setData({ level: level });
    this.loadSequenceData(level);
    
    // 获取语音设置
    const voiceEnabled = wx.getStorageSync('voiceEnabled');
    this.setData({ isVoiceEnabled: voiceEnabled });
  },
  
  onShow: function () {
    wx.setKeepScreenOn({ keepScreenOn: true });
    // 页面显示时加载附近推荐
    this.loadNearby();
  },

  // 加载序列数据
  async loadSequenceData(level) {
    console.log('[LOAD] Loading sequence for level:', level);
    this.setData({ loading: true, error: null });
    wx.showLoading({ title: '加载中...' });
    
    try {
      const sequenceData = await cloudSequenceService.getProcessedSequence(level);

      if (sequenceData && sequenceData.poses && sequenceData.poses.length > 0) {
        // Auto fill pose key using image_url filename if missing
        sequenceData.poses = sequenceData.poses.map(pose => {
          if (!pose.key && pose.image_url) {
            const file = pose.image_url.split('/').pop();
            pose.key = file.replace(/\.(png|jpg|jpeg)$/i, '');
          }
          return pose;
        });
        const initialState = sequenceService.setSequence(sequenceData);
        this.setData({
          ...initialState,
          loading: false
        });
        this.updateNormalizedPoseKey();
        wx.hideLoading();
        wx.setNavigationBarTitle({ 
          title: `${getText(initialState.currentSequence.name)} - ${initialState.currentPoseIndex + 1}/${initialState.currentSequence.poses.length}` 
        });
        
        // 如果启用语音，播放第一个体式的引导
        if (this.data.isVoiceEnabled) {
          this.playCurrentPoseGuide();
        }
      } else {
        console.error('[LOAD] Invalid sequence data:', sequenceData);
        throw new Error('加载的序列数据无效');
      }
    } catch (err) {
      console.error('[LOAD] Failed to load sequence:', err);
      let userErrorMessage = '无法加载序列数据，请稍后重试。';
      let toastMessage = '加载失败，请稍后重试';

      if (err && err.message === 'MISSING_SIGNED_URL') {
        userErrorMessage = '序列配置获取失败，请检查网络或稍后重试。';
        toastMessage = '序列配置获取失败';
      }
      
      this.setData({ 
        loading: false, 
        error: userErrorMessage, 
        currentSequence: null 
      });
      wx.hideLoading();
      wx.showToast({ title: toastMessage, icon: 'none' });
      wx.setNavigationBarTitle({ title: '加载错误' });
    }
  },

  // === 新增：地图推荐功能 ===
  async loadNearby() {
    this.setData({ isLoadingPOI: true });

    try {
      const pois = await fetchNearbyPOIs({
        bizType: 'yoga',
        userIntent: '瑜伽序列训练',
        radius: 5000
      });

      const poiList = Array.isArray(pois) ? pois : [];
      const meta = poiList.meta || {};

      if (meta.reason === 'OUT_OF_COVERAGE') {
        wx.showToast({ title: '定位区域暂不支持实时推荐，已展示默认列表', icon: 'none' });
      }

      this.setData({
        nearbyPOIs: poiList.slice(0, 5),
        isLoadingPOI: false,
        showPOISection: poiList.length > 0
      });
    } catch (err) {
      console.error('[POI] 获取推荐失败:', err);
      this.setData({ isLoadingPOI: false });
    }
  },
  
  // 打开POI详情
  openPOI(e) {
    const poi = e.currentTarget.dataset.poi;
    if (poi) {
      navigateToPOI(poi);
    }
  },
  
  // 切换POI区域显示
  togglePOISection() {
    this.setData({ 
      showPOISection: !this.data.showPOISection 
    });
  },

  // === 新增：语音引导功能 ===
  // 播放当前体式的语音引导
  async playCurrentPoseGuide() {
    const currentPose = this.data.currentSequence?.poses[this.data.currentPoseIndex];
    if (!currentPose) return;
    
    const guidanceText = truncateByBytes(`现在进入${getText(currentPose.name)}，${getText(currentPose.instructions)}`, 768);
    
    try {
      const res = await this.requestTTS(guidanceText);
      if (res?.url) {
        playTTS({ 
          url: res.url, 
          title: `${getText(currentPose.name)} - 语音引导` 
        });
        this.setData({ isVoicePlaying: true });
      }
    } catch (err) {
      console.error('[TTS] 播放引导失败:', err);
    }
  },
  
  // 请求TTS合成
  requestTTS(text) {
    const payload = {
      text: truncateByBytes(text, 768),
      voice: 'female_coach'
    };

    const primary = () => new Promise((resolve, reject) => {
      wx.request({
        url: GUIDE_TTS_URL,
        method: 'POST',
        data: payload,
        success: ({ data }) => {
          const url = data?.data?.url || data?.url;
          if (url) {
            resolve({ url });
          } else {
            reject(new Error('TTS URL not found'));
          }
        },
        fail: reject
      });
    });

    const fallback = () => new Promise((resolve, reject) => {
      wx.request({
        url: FUNCTION_GATEWAY_ENDPOINTS.GUIDE,
        method: 'POST',
        data: {
          action: 'tts_feedback',
          text,
          voice: 'female_coach'
        },
        success: ({ statusCode, data }) => {
          if (statusCode >= 200 && statusCode < 300) {
            const url = data?.audioUrl || data?.data?.audioUrl || data?.url;
            if (url) {
              resolve({ url });
            } else {
              reject(new Error('TTS gateway response missing url'));
            }
          } else {
            reject(new Error(`TTS gateway failed (${statusCode})`));
          }
        },
        fail: reject
      });
    });

    return primary().catch(err => {
      console.warn('[TTS] 主通道失败，尝试网关', err);
      return fallback();
    });
  },
  
  // 切换语音开关
  toggleVoice() {
    const newState = !this.data.isVoiceEnabled;
    this.setData({ isVoiceEnabled: newState });
    wx.setStorageSync('voiceEnabled', newState);
    
    if (!newState) {
      stopTTS();
      this.setData({ isVoicePlaying: false });
    } else {
      this.playCurrentPoseGuide();
    }
    
    wx.showToast({
      title: newState ? '语音已开启' : '语音已关闭',
      icon: 'none'
    });
  },

  // Timer management
  startTimer: function () {
    if (this.data.timerId) clearInterval(this.data.timerId);

    const timerId = setInterval(() => {
      if (this.data.timeRemaining > 0) {
        this.setData({ timeRemaining: this.data.timeRemaining - 1 });
      } else {
        clearInterval(this.data.timerId);
        this.setData({ timerId: null });
        if (this.data.isPlaying) {
          this.handleNext();
        }
      }
    }, 1000);
    this.setData({ timerId: timerId });
  },

  stopTimer: function () {
    if (this.data.timerId) {
      clearInterval(this.data.timerId);
      this.setData({ timerId: null });
    }
  },

  // Play audio guidance (原有功能保留)
  playAudioGuidance: function (src) {
    return new Promise((resolve, reject) => {
      if (!src) {
        console.warn('[AUDIO] No audio src provided');
        reject(new Error("No audio src provided"));
        return;
      }

      const audioCtx = wx.createInnerAudioContext({ useWebAudioImplement: false });
      audioCtx.src = src;
      audioCtx.onEnded(() => { 
        audioCtx.destroy(); 
        resolve(); 
      });
      audioCtx.onError((error) => {
        console.error('[AUDIO] Error playing:', src, error);
        wx.showToast({ title: '音频播放失败', icon: 'none' });
        audioCtx.destroy();
        reject(error);
      });
      audioCtx.play();
    });
  },

  // Navigation handlers
  handleBack: function () {
    this.stopTimer();
    stopTTS();
    wx.navigateBack();
  },

  handleNext: function () {
    this.stopTimer();
    stopTTS(); // 停止当前语音
    
    const { currentSequence, currentPoseIndex } = this.data;
    const nextState = sequenceService.nextPose(currentSequence, currentPoseIndex);

    if (nextState) {
      this.setData({
        currentPoseIndex: nextState.currentPoseIndex_new,
        timeRemaining: nextState.timeRemaining_new
      });
      this.updateNormalizedPoseKey();
      wx.setNavigationBarTitle({
        title: `${getText(currentSequence.name)} - ${nextState.currentPoseIndex_new + 1}/${currentSequence.poses.length}`
      });
      
      if (this.data.isPlaying) {
        const newCurrentPose = currentSequence.poses[nextState.currentPoseIndex_new];
        
        // 播放原音频或TTS
        if (this.data.isVoiceEnabled) {
          this.playCurrentPoseGuide();
        } else if (newCurrentPose.audioGuide) {
          this.playAudioGuidance(newCurrentPose.audioGuide)
            .catch(e => console.error("[AUDIO] Error in handleNext:", e));
        }
        
        this.startTimer();
      }
    } else {
      // 序列完成
      const randomScore = Math.floor(Math.random() * 30) + 70;
      this.setData({
        poseScore: { score: randomScore, feedback: '保持呼吸流畅，继续练习' },
        showScoreModal: true
      });
    }
  },

  closeScoreModal() {
    this.setData({ showScoreModal: false });
    wx.redirectTo({ url: '/pages/index/index' });
  },

  // Toggle play/pause
  togglePlayPause: function () {
    const { isPlaying_new } = sequenceService.togglePlayPause(this.data.isPlaying);
    this.setData({ isPlaying: isPlaying_new });

    if (isPlaying_new) {
      const currentPose = this.data.currentSequence.poses[this.data.currentPoseIndex];
      
      if (this.data.isVoiceEnabled) {
        if (this.data.isVoicePlaying) {
          resumeTTS();
        } else {
          this.playCurrentPoseGuide();
        }
      } else if (currentPose.audioGuide) {
        this.playAudioGuidance(currentPose.audioGuide)
          .catch(e => console.error("[AUDIO] Error in togglePlayPause:", e));
      }
      
      this.startTimer();
    } else {
      this.stopTimer();
      if (this.data.isVoiceEnabled) {
        pauseTTS();
      }
    }
  },

  // Image error handler
  onImageError: function(e) {
    const dataset = e.currentTarget.dataset;
    const imageType = dataset.type;
    const imageIndex = dataset.index;
    
    console.warn('[IMAGE_ERROR] Failed to load image:', e.detail.errMsg, 'Type:', imageType, 'Index:', imageIndex);
    
    if (imageType === 'skeleton' && imageIndex !== undefined) {
      const frameIndex = parseInt(imageIndex);
      if (!isNaN(frameIndex) && this.data.topThreeFrames[frameIndex]) {
        this.setData({
          [`topThreeFrames[${frameIndex}].skeletonUrl`]: DEFAULT_POSE_IMAGE
        });
      }
    }
  },

  // Lifecycle hooks
  onHide: function () {
    wx.setKeepScreenOn({ keepScreenOn: false });
    this.stopTimer();
    if (this.data.isVoiceEnabled) {
      pauseTTS();
    }
  },

  onUnload: function () {
    this.stopTimer();
    stopTTS();
    if (this.data.currentUploadTasks && this.data.currentUploadTasks.length > 0) {
      console.log('[UNLOAD] Cancelling', this.data.currentUploadTasks.length, 'ongoing uploads');
      this.data.currentUploadTasks.forEach(task => {
        if (task && typeof task.abort === 'function') {
          task.abort();
        }
      });
    }
  },

  // 分享配置
  onShareAppMessage() {
    const sequence = this.data.currentSequence;
    const level = this.data.level;
    
    return {
      title: `一起练瑜伽 | ${sequence ? getText(sequence.name) : '瑜伽序列'} + 附近瑜伽馆推荐`,
      path: `/pages/sequence/index?level=${level}`,
      imageUrl: this.data.poseImages[this.data.normalizedPoseKey] || DEFAULT_POSE_IMAGE
    };
  }
