import { guideByPose, normalizePoseInput } from '../../utils/guide';

let audioCtx;

Page({
  data: {
    userInput: '',
    normalizedPose: '',
    matchHint: '',
    prompts: [],
    audioSrc: '',
    playing: false,
    loading: false,
    hint: ''
  },

  onLoad(options = {}) {
    const { poseId, poseName } = options || {};
    let prefill = poseId || poseName || '';
    if (prefill) {
      try {
        prefill = decodeURIComponent(prefill);
      } catch (err) {
        console.warn('[sequence-guide] decode param failed', err);
      }
      this.setData({ userInput: prefill });
      wx.nextTick(() => {
        this.onSendGuide();
      });
    }
  },

  onUnload() {
    this.destroyAudio();
  },

  onHide() {
    this.stopAudio();
  },

  onInput(e) {
    this.setData({ userInput: e.detail.value });
  },

  async onSendGuide() {
    if (this.data.loading) return;

    const rawInput = (this.data.userInput || '').trim();
    if (!rawInput) {
      wx.showToast({ title: '请输入体式名称', icon: 'none' });
      return;
    }

    const normalized = normalizePoseInput(rawInput);
    if (!normalized) {
      wx.showToast({ title: '未识别体式名称', icon: 'none' });
      return;
    }

    const resolvedName = normalized.pose || normalized.poseId || rawInput;

    this.stopAudio();
    this.setData({
      loading: true,
      hint: '',
      normalizedPose: resolvedName,
      matchHint: '',
      prompts: [],
      audioSrc: '',
      playing: false
    });
    wx.showLoading({ title: '生成中…', mask: true });

    try {
      const result = await guideByPose(normalized, { ttsEnable: true });

      const prompts = Array.isArray(result?.prompts) && result.prompts.length
        ? result.prompts
        : (result?.text ? [{ text: result.text }] : []);

      let audioSrc = result?.audioUrl || '';
      if (!audioSrc && result?.audio_base64) {
        audioSrc = `data:audio/mpeg;base64,${result.audio_base64}`;
      }

      const matchedPose = result?.pose || result?.poseId || resolvedName;

      this.setData({
        prompts,
        audioSrc,
        playing: false,
        hint: result?.hint || '',
        normalizedPose: matchedPose,
        matchHint: ''
      });

      if (audioSrc) {
        this.playAudio(audioSrc);
      } else if (!prompts.length) {
        wx.showToast({ title: '暂无引导内容', icon: 'none' });
      }
    } catch (err) {
      if (err?.message === 'POSE_NOT_FOUND') {
        this.setData({
          hint: err.hint || '',
          normalizedPose: '',
          matchHint: err.hint || '未找到相关体式，请尝试中文、英文或常见别名'
        });
        wx.showModal({
          title: '未识别该体式',
          content: err.hint || '请更换体式中文/英文/别名（如：下犬式 / Downward Dog）',
          showCancel: false
        });
      } else if (err?.code === 'NO_POSE_INPUT') {
        wx.showToast({ title: '请输入体式名称', icon: 'none' });
      } else {
        wx.showToast({ title: '网络或服务异常', icon: 'none' });
        console.error('[sequence-guide] guide request failed', err);
      }
    } finally {
      wx.hideLoading();
      this.setData({ loading: false });
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.obeyMuteSwitch = false;
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[sequence-guide] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  playAudio(src) {
    if (!src) {
      wx.showToast({ title: '暂无可播放音频', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (audioCtx.src !== src) {
      audioCtx.stop();
      audioCtx.src = src;
    }
    audioCtx.play();
  },

  stopAudio() {
    if (audioCtx) {
      try {
        audioCtx.stop();
      } catch (err) {
        console.warn('[sequence-guide] stop audio failed', err);
      }
    }
    this.setData({ playing: false });
  },

  handlePlayTap() {
    if (!this.data.audioSrc) {
      wx.showToast({ title: '暂无语音内容', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audioSrc) {
        audioCtx.src = this.data.audioSrc;
      }
      audioCtx.play();
    }
  },

  destroyAudio() {
    if (audioCtx) {
      try {
        audioCtx.stop();
        audioCtx.destroy();
      } catch (err) {
        console.warn('[sequence-guide] destroy audio failed', err);
      }
      audioCtx = null;
    }
  }
});
