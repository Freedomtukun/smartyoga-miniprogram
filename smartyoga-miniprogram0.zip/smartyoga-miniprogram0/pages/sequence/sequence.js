import { fetchGuideByPrompt, fetchGuideByVoice } from '../../utils/guide.js';
import { truncateByBytes } from '../../utils/text';
import { uploadToCos } from '../../utils/upload';
import { ensurePlayableAudio } from '../../utils/audio';

let audioCtx;
const recorder = wx.getRecorderManager();
let isRecording = false;

Page({
  data: {
    inputText: '',
    guideText: '',
    audio: '',
    loading: false,
    playing: false,
    recording: false,
    recordHint: '按住说话'
  },

  onLoad() {
    this.initRecorder();
  },

  onUnload() {
    this.stopAudio();
    if (audioCtx && audioCtx.destroy) {
      audioCtx.destroy();
    }
    audioCtx = null;
    try {
      recorder.stop();
    } catch (_) {}
  },

  onInput(e) {
    this.setData({ inputText: e.detail.value });
  },

  async sendText() {
    const prompt = truncateByBytes((this.data.inputText || '').trim(), 768);
    if (!prompt) {
      wx.showToast({ title: '请先输入内容', icon: 'none' });
      return;
    }
    await this.requestGuide(() => fetchGuideByPrompt(prompt));
  },

  initRecorder() {
    this.recordCanceled = false;
    recorder.onStart(() => {
      isRecording = true;
      this.setData({ recording: true, recordHint: '松开即可发送' });
    });
    recorder.onStop(async (res) => {
      isRecording = false;
      this.setData({ recording: false, recordHint: '按住说话' });
      if (this.recordCanceled) {
        this.recordCanceled = false;
        return;
      }
      if (res?.tempFilePath) {
        await this.handleVoice(res.tempFilePath);
      }
    });
    recorder.onError((err) => {
      console.error('[sequence] record error', err);
      isRecording = false;
      this.setData({ recording: false, recordHint: '按住说话' });
      wx.showToast({ title: '录音失败，请重试', icon: 'none' });
    });
  },

  ensureRecordAuth() {
    return new Promise((resolve) => {
      wx.getSetting({
        success: ({ authSetting }) => {
          if (authSetting['scope.record']) {
            resolve(true);
          } else {
            wx.authorize({
              scope: 'scope.record',
              success: () => resolve(true),
              fail: () => {
                wx.showToast({ title: '请开启录音权限', icon: 'none' });
                resolve(false);
              }
            });
          }
        },
        fail: () => resolve(false)
      });
    });
  },

  async startRecord() {
    if (this.data.loading) return;
    const ok = await this.ensureRecordAuth();
    if (!ok) return;
    this.recordCanceled = false;
    if (isRecording) {
      try { recorder.stop(); } catch (err) { console.warn(err); }
    }
    recorder.start({
      duration: 15000,
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 32000,
      format: 'mp3'
    });
  },

  stopRecord() {
    if (!this.data.recording) return;
    isRecording = false;
    recorder.stop();
  },

  cancelRecord() {
    if (!this.data.recording) return;
    this.recordCanceled = true;
    isRecording = false;
    recorder.stop();
    wx.showToast({ title: '已取消', icon: 'none' });
  },

  async handleVoice(filePath) {
    await this.requestGuide(async () => {
      const cloudPath = `audio/guide/${Date.now()}-${Math.random().toString(36).slice(2)}.mp3`;
      const fileID = await uploadToCos(filePath, cloudPath);
      return fetchGuideByVoice({ voiceFileID: fileID, format: 'mp3' });
    });
  },

  async requestGuide(fetcher) {
    if (this.data.loading) return;
    this.stopAudio();
    this.setData({ loading: true });
    try {
      const result = await fetcher();
      await this.applyGuideResult(result);
    } catch (err) {
      console.error('[sequence] guide request failed', err);
      wx.showToast({ title: '获取引导失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  async applyGuideResult(result) {
    const text = result?.text || '';
    const audioCandidate = result?.audioUrl || result?.audio || '';
    let audio = audioCandidate;
    if (audioCandidate) {
      try {
        const playable = await ensurePlayableAudio(audioCandidate, { prefix: 'guide' });
        if (playable) {
          audio = playable;
        }
      } catch (err) {
        console.warn('[sequence] ensure playable audio failed', err);
      }
    }
    if (!text) {
      wx.showToast({ title: '暂无有效建议', icon: 'none' });
      return;
    }
    this.setData({ guideText: text, audio, playing: false });
    if (audio) {
      this.ensureAudioCtx();
      audioCtx.src = audio;
      audioCtx.play();
    }
  },

  ensureAudioCtx() {
    if (audioCtx) return;
    audioCtx = wx.createInnerAudioContext();
    audioCtx.onPlay(() => this.setData({ playing: true }));
    audioCtx.onPause(() => this.setData({ playing: false }));
    audioCtx.onStop(() => this.setData({ playing: false }));
    audioCtx.onEnded(() => this.setData({ playing: false }));
    audioCtx.onError((err) => {
      console.error('[sequence] audio error', err);
      this.setData({ playing: false });
      wx.showToast({ title: '音频播放失败', icon: 'none' });
    });
  },

  togglePlay() {
    if (!this.data.audio) {
      wx.showToast({ title: '暂无语音', icon: 'none' });
      return;
    }
    this.ensureAudioCtx();
    if (this.data.playing) {
      audioCtx.pause();
    } else {
      if (audioCtx.src !== this.data.audio) {
        audioCtx.src = this.data.audio;
      }
      audioCtx.play();
    }
  },

  stopAudio(pauseOnly = false) {
    if (!audioCtx) return;
    if (pauseOnly) {
      audioCtx.pause();
    } else {
      audioCtx.stop();
    }
    this.setData({ playing: false });
  }
});
