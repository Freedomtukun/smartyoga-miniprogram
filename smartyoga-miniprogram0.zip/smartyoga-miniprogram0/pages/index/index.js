Page({
  handleGuidePress() {
    wx.navigateTo({ url: '/pages/sequence/sequence' });
  },

  handleGuideplusPress() {
    wx.navigateTo({ url: '/pages/meditation/meditation' });
  },

  handleDetectPress() {
    wx.navigateTo({ url: '/pages/photo-detect/photo-detect' });
  },

  handleNearbyPress() {
    wx.navigateTo({ url: '/pages/nearby/nearby' });
  },

  handleSupportPress() {
    wx.navigateTo({ url: '/pages/support/support' });
  }
});
