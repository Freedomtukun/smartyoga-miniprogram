Page({
  data: {
    presetAmounts: ['0.99', '6.99', '9.99'],
    selectedAmount: '0.99',
    customAmount: ''
  },

  handlePresetAmountTap(event) {
    const { value } = event.currentTarget.dataset;
    this.setData({ selectedAmount: value, customAmount: '' });
  },

  handleCustomAmountTap() {
    this.setData({ selectedAmount: 'custom' });
  },

  handleCustomAmountInput(event) {
    const sanitized = event.detail.value.replace(/[^0-9.]/g, '');
    this.setData({ customAmount: sanitized });
  },

  handleSupportSubmit() {
    const { selectedAmount, customAmount } = this.data;
    let amountToPay = selectedAmount;

    if (selectedAmount === 'custom') {
      amountToPay = (customAmount || '').trim();
      if (!amountToPay) {
        wx.showToast({ title: '请输入自定义金额', icon: 'none' });
        return;
      }
    }

    const numericAmount = parseFloat(amountToPay);
    if (!numericAmount || numericAmount <= 0) {
      wx.showToast({ title: '金额需大于0', icon: 'none' });
      return;
    }

    wx.showModal({
      title: '支持提示',
      content: `当前为体验演示，建议支付金额 ¥${numericAmount.toFixed(2)}。正式收款请接入微信支付能力。`,
      showCancel: false,
      confirmText: '我知道了'
    });
  }
});
